package com.test.teacher;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
/**
 * 
 * @author shin
 *
 */
public class TeacherLogin {
	
	//public static Scanner scan = new Scanner(System.in);--이런식으로 쓰면 계속 죽지않고 남아있게된다!
	
	public static int teacherNumber;//로그인 선생 번호를 static 으로 올려버리자
	public static String teacherName;
	
	public TeacherLogin() {//생성자
		// TODO Auto-generated constructor stub
		
		teacherNumber = teacherLogins();
	}
	
	
	/**
	 * 
	 * @return 교사번호
	 */
	public int teacherLogins() {//교사 로그인
		
		Scanner scan = new Scanner(System.in);
		int returnVal = -1;//교사 번호를 뽑아줄것이다
		
		
		while(true) {
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t교사 로그인");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t아이디를 입력하세요 : ");
			String inputId = scan.nextLine();//아이디 입력
			System.out.print("\t\t\t\t비밀번호를  입력하세요 : ");
			String inputPw = scan.nextLine();//비밀번호 입력
			
			
			
			Connection conn = null;
			Statement stat = null;
			ResultSet rs = null;
			DBUtil util = new DBUtil();

			try {

				//conn = util.open("211.63.89.47","project","java1234");//실제 접속
				conn = util.open1();//테스트 서버 접속
				stat = conn.createStatement();

				String sql = "select * from tblTeacher";
						
				rs = stat.executeQuery(sql);
				
				while (rs.next()) {//커서탐색시작
					
					String seq = rs.getString(1);//교사번호
					String id = rs.getString(2);//교사 이름 
					String pw = rs.getString(3).substring(7);//교사 주민번호 뒷자리
					
					if (id.equals(inputId) && pw.equals(inputPw)) {
						
						returnVal = Integer.parseInt(seq);
						teacherNumber = returnVal;
						teacherName = id;
						break;
						
					}
					
				}

				rs.close();
				stat.close();
				conn.close();

			} catch (Exception e) {
				System.out.println("\t\t\t\t오류가 발생");
			}
			

			return returnVal;//선생번호를 출력해줄것이다
		}

		
		
	}//교사 로그인
	
	public static void main(String[] args) {//테스트 메인프로시저
		
		//TeacherLogin tr = new TeacherLogin();//생성자를 만들었기 때문에 시작하자마자 생성이된다.
		
		//System.out.println(tr.teacherNumber);
		
		
		
		//System.out.println(tr.teacherLogins());
		
		
	}

}

package com.test.teacher;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import oracle.jdbc.internal.OracleTypes;
/**
 * 
 * @author shin
 *
 */
public class DistributionScore {//공통메서드를 하나로 빼는 작업을 수행해보자!
	
	public List<String[]> infoList;//자신이 가르쳤던(과거) 과목에 대한 정보를 넣어줄것이다
	public List<String[]> examSubList;//자신이 가르쳤던 and 가르치고 있는 과목에 대한 정보를 넣어준것이다.
	//public int subNum;//과목번호
	//public String subName;//과목이름
	
	
	public void distribution() {//배점 입력하는 곳
		
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("\t\t\t\t================================");
		System.out.printf("\t\t\t\t%s 교사님 이 마친 과목 목록을 출력합니다.\n",TeacherLogin.teacherName);
		System.out.println("\t\t\t\t================================");
		
		ErrorPage ep = new ErrorPage();
		ep.pause();
		
		infoList = new ArrayList<String[]>();//자신이 가르쳤던(과거) 과목에 대한 정보를 넣어줄것이다
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc121print(?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			
			stat.setInt(1, TeacherLogin.teacherNumber);//실전용
			//stat.setInt(1, 1);//테스트용
			stat.registerOutParameter(2, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(2);
			
			System.out.println("[과목번호][담당교사 이름]\t[과목 시작일자]\t[과목 종료일자]\t[과목명]");
			System.out.println();
			
			while(rs.next()) {
				
				String[] strList = {rs.getString(1),
									rs.getString(2),
									rs.getString(3),
									rs.getString(4),
									rs.getString(5),
									rs.getString(6),
									rs.getString(7),
									rs.getString(8),
									rs.getString(9)};
				
				infoList.add(strList);//정보 넣어주기
				
				System.out.printf("%s\t%s\t\t%s\t%s\t%s\n",
						rs.getString(1),
						rs.getString(3),
						rs.getString(5).substring(0,10),
						rs.getString(6).substring(0,10),
						rs.getString(2));
			}
			
			stat.close();
			conn.close();
			
			distributionMenu();//상세적으로 메뉴로 들어간다
			

		} catch (Exception e) {

			System.out.println("오류가 발생");

		}
			
	}//distribution()
	
	/**
	 * 배점메뉴
	 */
	public void distributionMenu() {//배점 메뉴~
		Scanner scan = new Scanner(System.in);
		boolean flag = true;
		
		while(flag) {
			
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 과목별 배점 조회");
			System.out.println("\t\t\t\t2. 과목별 배점 입력");
			System.out.println("\t\t\t\t3. 시험날짜 조회 및 수정");
			System.out.println("\t\t\t\t4. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			
			System.out.print("\t\t\t\t선택(번호) : ");
			String input = scan.nextLine();
			
			
			switch(input) {
			
			case "1" :
				subjectSearch();//1.과목별 배점 조회
				break;
			case "2" :
				subjectScoreInput();//2.과목별 배점 입력
				break;
			case "3" :
				examDate();//3. 시험날짜 조회 및 수정
				break;
			case "4" ://4. 뒤로가기
				TeacherMainMenu tm = new TeacherMainMenu();
				tm.tMenu();
				//flag = false;
				//break;// 브레이크를 쓰면 뒤로가기가 안된다!
			default :
				System.out.println("\t\t\t\t잘못된 번호를 입력했습니다.");
			}
		}

		
		
	}
	/**
	 * 과목별 배점 조회
	 */
	public void subjectSearch() {//1.과목별 배점 조회
		
		Scanner scan = new Scanner(System.in);
		System.out.print("\t\t\t\t조회할 과목의 과목번호 선택(번호) : ");
		String input = scan.nextLine();
		
		int wantIndex = -1;//사용자가 입력한 과목번호가 존재하는 배열의 자리 -1 이 그대로 나오면 사용자가 과목번호를 잘못 입력헀다는 뜻이 된다!
		
		
		for (int i = 0; i < infoList.size(); i++) {// 자신이 가지고 있는 과목이 맞는지 검증해주는 작업이라고 볼 수 있다

			if (infoList.get(i)[0].equals(input)) {
				wantIndex = i;
			}	
		}
		
		
		if (wantIndex == -1) {//자신이 가르치지 않은 과목번호
			
			System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n",TeacherLogin.teacherName);
			subjectSearch();
			
		} else {//자신이 가르친 과목이 존재하는 경우
			
			System.out.println("[과목번호][담담교사 이름][출결배점][필기배점][실기배점]\t[과목명]");
			
			System.out.printf("%s\t%s\t\t%s\t%s\t%s\t%s\n",
						infoList.get(wantIndex)[0],
						infoList.get(wantIndex)[2],
						infoList.get(wantIndex)[6],
						infoList.get(wantIndex)[7],
						infoList.get(wantIndex)[8],
						infoList.get(wantIndex)[1]);
			
			
			ErrorPage ep = new ErrorPage();
			ep.pause();
			distributionMenu();
			
		}
	}//subjectSearch()
	
	/**
	 * 과목별 배점 입력
	 */
	public void subjectScoreInput() {//2. 과목별 배점 입력
		
		Scanner scan = new Scanner(System.in);
		System.out.print("\t\t\t\t조회후 배점을 수정/입력 할 과목번호 선택(번호) : ");
		String input = scan.nextLine();//사용자가 과목번호 입력
		
		int wantIndex = -1;//사용자가 입력한 과목번호가 존재하는 배열의 자리 -1 이 그대로 나오면 사용자가 과목번호를 잘못 입력헀다는 뜻이 된다!
		
		
		for (int i = 0; i < infoList.size(); i++) {// 자신이 가지고 있는 과목이 맞는지 검증해주는 작업이라고 볼 수 있다

			if (infoList.get(i)[0].equals(input)) {
				wantIndex = i;
			}	
		}
		
		
		if (wantIndex == -1) {//자신이 가르치지 않은 과목번호
			
			System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n",TeacherLogin.teacherName);
			subjectSearch();
			
		} else {
			
			System.out.println("[과목번호][담담교사 이름][출결배점][필기배점][실기배점]\t[과목명]");
			
			System.out.printf("%s\t%s\t\t%s\t%s\t%s\t%s\n",
						infoList.get(wantIndex)[0],
						infoList.get(wantIndex)[2],
						infoList.get(wantIndex)[6],
						infoList.get(wantIndex)[7],
						infoList.get(wantIndex)[8],
						infoList.get(wantIndex)[1]);
			
			//아래에서 이제 배점 입력을 해줘야 한다!
			ErrorPage ep = new ErrorPage();
			ep.pause("배점을 수정하려면 엔터를 눌러주세요");
			
			boolean flag = true;
			int attendense = -1;//출결배점
			int written = -1;//필기배점
			int practical = -1;//실기배점
			
			while(flag) {//여기서 사용자의 배점입력을 받는다
				
				
				System.out.print("\t\t\t\t출결배점을 입력해주세요 : ");
				attendense = Integer.parseInt(scan.nextLine());
				System.out.print("\t\t\t\t필기배점을 입력해주세요 : ");
				written = Integer.parseInt(scan.nextLine());
				System.out.print("\t\t\t\t실기배점을 입력해주세요 : ");
				practical = Integer.parseInt(scan.nextLine());
				
				if (attendense >= 20 && ((attendense + written + practical) == 100)) {
					flag = false;
				} else {
					System.out.println("\t\t\t\t출결 배점은 최소 20점 이어야하고 출결 + 필기 + 실기 = 100 점이어야 합니다");
				}
				
			}
			

			Connection conn = null;
			CallableStatement stat = null;
			ResultSet rs = null;
			DBUtil util = new DBUtil();

			try {

				String sql = "{call proc121input(?,?,?,?)}";//프로시저 불러오기
				
				//conn = util.open("211.63.89.47","project","java1234");//실제 접속
				conn = util.open1();//로컬 접속
				stat = conn.prepareCall(sql);
				
				stat.setInt(1, Integer.parseInt(input));
				stat.setInt(2, attendense);
				stat.setInt(3, written);
				stat.setInt(4, practical);
				

				int result = stat.executeUpdate();
				
				System.out.println("\t\t\t\t" + result + "개가 업데이트 되었습니다.");
				//stat.close();
				//conn.close();
				
				
				sql = "{call proc121print(?,?)}";
				stat = conn.prepareCall(sql);
				
				stat.setInt(1, TeacherLogin.teacherNumber);//실전용
				//stat.setInt(1, 1);//테스트용
				stat.registerOutParameter(2, OracleTypes.CURSOR);

				stat.executeQuery();
				
				rs = (ResultSet)stat.getObject(2);
				
				System.out.println("[과목번호][담담교사 이름][출결배점][필기배점][실기배점]	[과목명]");
				
				while(rs.next()) {
					
					
					if (rs.getString(1).equals(input)) {
						System.out.printf("%s\t%s\t\t%s\t%s\t%s\t%s\n",
								rs.getString(1),
								rs.getString(3),
								rs.getString(7),
								rs.getString(8),
								rs.getString(9),
								rs.getString(2));
					}

				}
				
				stat.close();
				conn.close();
				
				
				ep.pause();
				distributionMenu();//상세적으로 메뉴로 들어간다
				

			} catch (Exception e) {

				System.out.println("오류가 발생");

			}
			
			
		}
		
		
	}
	/**
	 * 시험날짜 조회 및 수정
	 */
	public void examDate() {//3. 시험날짜 조회 및 수정
		
		
		
		System.out.printf("\t\t\t\t%s 교사님의 과목 시험일자를 조회합니다.\n",TeacherLogin.teacherName);
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		examSubList = new ArrayList<String[]>();//가용과목번호 집어넣을것이다
		
		
		
		try {

			String sql = "{call proc122search(?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			
			stat.setInt(1, TeacherLogin.teacherNumber);//실전용
			//stat.setInt(1, 1);//테스트용
			stat.registerOutParameter(2, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(2);
			
			System.out.println("[과목번호][담당교사 이름]\t[과목 시험일자]\t[과목종료일자]\t[과목명]");
			
			while(rs.next()) {

				
				String[] data = {rs.getString(1),rs.getString(4).substring(0,10),rs.getString(5)};//과목번호,과목종료일자,과목명
				
				examSubList.add(data);//데이터 입력
				
				System.out.printf("%s\t%s\t\t%s\t%s\t%s\n",
						rs.getString(1),
						rs.getString(2),
						rs.getString(3).substring(0,10),
						rs.getString(4).substring(0,10),
						rs.getString(5));
			}
			
			stat.close();
			conn.close();
			//여기서 이제 시험 과목 입력이 들어가보자!
			System.out.println();
			ErrorPage ep = new ErrorPage();
			String answer = ep.exitOrGo("\t\t\t\t1. 시험날짜 수정/입력\n\t\t\t\t2. 뒤로가기");
			
			if (answer.equals("1")) {//시험날짜 수정
				examDateInput();//시험날짜 수정 입력 메서드
			} else {//뒤로가기
				distributionMenu();
			}
			
			

		} catch (Exception e) {

			e.printStackTrace();
			System.out.println("\t\t\t\t오류가 발생");

		}
		
		
		
	}
	/**
	 * 시험날짜 수정 입력
	 */
	public void examDateInput() {//시험날짜 수정 입력!
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("\t\t\t\t시험날짜 입력/수정할 과목번호를 입력 : ");
		String input = scan.nextLine();
		
		int answer = -1;
		
		for (int i = 0; i < examSubList.size(); i++) {//여기서 사용자가 자신이 가르친 과목을 입력했는지 검수가 가능하다.
			if (examSubList.get(i)[0].equals(input)) {
				answer = i;
			}
		}
		
		if (answer == -1 ) {//잘못입력한 경우
			System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n",TeacherLogin.teacherName);
			examDateInput();//다시 입력으로 고고
			
		} else {//잘 입력한 경우
			
			Connection conn = null;
			CallableStatement stat = null;
			//ResultSet rs = null;
			DBUtil util = new DBUtil();

			
			String subFinalDate = "";//과목 마지막날
			
			for (int i = 0; i < examSubList.size(); i++) {
				if (examSubList.get(i)[0].equals(input)) {
					subFinalDate = examSubList.get(i)[1];//부합하는 과목 종료일자를 넣어줌
				}
			}
			
			StringTokenizer stk = new StringTokenizer(subFinalDate,"-");
			
			int fyear = Integer.parseInt(stk.nextToken());//과목 년
			int fmonth = Integer.parseInt(stk.nextToken());//과목 월
			int fdate = Integer.parseInt(stk.nextToken());//과목 일
			
			//2019-11-26
			
			Calendar c1 = Calendar.getInstance();//과목 종료날짜를 받아올것이다.
			c1.set(fyear,fmonth - 1,fdate);
			
			long subFinalTick = c1.getTimeInMillis();//과목종료날짜 틱값
			
			Calendar c2 = Calendar.getInstance();//입력한 날짜를 받을것이다
			
			
			int pyear = -1;
			int pmonth = -1;//애는 집어넣기 위해 하나 빠져있다는걸 명심하자
			int pdate = -1;
			
			while(true) {
				System.out.print("\t\t\t\t시험날짜 입력(년) : ");
				pyear = Integer.parseInt(scan.nextLine());
				System.out.print("\t\t\t\t시험날짜 입력(월) : ");
				pmonth = Integer.parseInt(scan.nextLine()) - 1;
				System.out.print("\t\t\t\t시험날짜 입력(일) : ");
				pdate = Integer.parseInt(scan.nextLine());
				
				c2.set(pyear, pmonth, pdate);
				long inputTick = c2.getTimeInMillis();//시험지정날짜 틱값
				
				if (subFinalTick < inputTick) {
					System.out.println("\t\t\t\t시험지정 날짜는 과목종료 이후 날에는 지정할 수 없습니다.");
				} else {
					break;
				}
			}
				
			
			
			try {

				String sql = "{call proc122(?,?,?,?,?)}";//프로시저 불러오기
				
				//conn = util.open("211.63.89.47","project","java1234");//실제 접속
				conn = util.open1();//로컬 접속
				stat = conn.prepareCall(sql);
				
				stat.setInt(1, TeacherLogin.teacherNumber);//실전용
				//stat.setInt(1, 1);//테스트용-> 선생번호 입력
				
				String newMon = "" + (pmonth + 1);
				String newDate = "" + pdate;
				
				
				if (newMon.length() == 1) {
					newMon = "0" + newMon;
				}
				
				if (newDate.length() == 1) {
					newDate = "0" + newDate;
				}
				
				stat.setInt(2, Integer.parseInt(input));//열린과목번호 입력
				stat.setString(3, "" + pyear);
				stat.setString(4, newMon);
				stat.setString(5, newDate);
				//stat.registerOutParameter(2, OracleTypes.CURSOR);

				int result = stat.executeUpdate();
				System.out.println("\t\t\t\t================================");
				System.out.printf("\t\t\t\t%d개의 정보가 업데이트 되었습니다.",result);
				System.out.println("\t\t\t\t================================");
				String subSeq = "";
				String subName = "";
				
				
				for (int i = 0; i < examSubList.size(); i++) {

					if (examSubList.get(i)[0].equals(input)) {
						subSeq = examSubList.get(i)[0];
						subName = examSubList.get(i)[2];
					}

				}
				

				
				stat.close();
				conn.close();
				
				System.out.println();

				System.out.println("\t\t\t\t아래와 같이 시험일자가 변경/입력 되었습니다.");
				System.out.println("\t\t\t\t[과목번호][과목명]\t\t\t[시험일자]");
				System.out.printf("\t\t\t\t%s\t%s\t%tF",subSeq,subName,c2);
			
				System.out.println();
				
				

			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("오류가 발생");

			}
			
			
			
		}
		
		
	}//examDateInput()
	
	
	public static void main(String[] args) {
		
		DistributionScore ds = new DistributionScore();
		
		ds.examDate();
		
		
	}

}

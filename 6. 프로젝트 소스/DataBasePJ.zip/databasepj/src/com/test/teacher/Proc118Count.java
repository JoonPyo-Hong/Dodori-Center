package com.test.teacher;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

import oracle.jdbc.internal.OracleTypes;

public class Proc118Count {
		
	public static Scanner scan = new Scanner(System.in);
	

	public static void proc118s(int teacherNum) {//교사가 자신이 강의하는 특정 과목에 대한 수강인원을 알아보기 위함이다!
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		try {
			
			
			System.out.print("개설 과목 번호 입력: ");
			String subjectNum = scan.nextLine();//과목번호 입력

			String sql = "{call proc118Count(?,?,?)}";
			
			
			//conn = util.open("211.63.89.47","project","java1234");//이게 진짜 연결하는것이다
			conn = util.open1();//테스트 계정 접속
			stat = conn.prepareCall(sql);
			stat.setInt(1, teacherNum);
			stat.setInt(2, Integer.parseInt(subjectNum));
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
			
			int totalCount = 0;//수강인원
			
			while (rs.next()) {
				
				totalCount += rs.getInt(1);
				
				}
			
			
			//System.out.println(stat.getString(3));
			
			
			stat.close();
			conn.close();
			
			
			System.out.printf("해당 %s번 과목의 수강인원은 %d 명입니다.",subjectNum,totalCount);
			
			
//			if (totalCount == 0) {
//				System.out.printf("잘못된 과목번호를 눌렀거나 접근할 수 없는 영역으로 엑세스 했습니다.");
//				
//			} else {
//				System.out.printf("해당 %s번 과목의 수강인원은 %d 명입니다.",subjectNum,totalCount);
//				
//			}
			
			

		} catch (Exception e) {

			System.out.println("오류가 발생");

		}
	}
	
	
	
	public static void main(String[] args) {
		
		 proc118s(5);
		
		
	}

}

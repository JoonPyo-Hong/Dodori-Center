package com.test.teacher;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;

import oracle.jdbc.internal.OracleTypes;
/**
 * 
 * @author shin
 *
 */
public class StudentAttendanceCheck {
	
	public List<String[]> examSubList;//자신이 가르쳤던 and 가르치고 있는 과목에 대한 정보를 넣어준것이다.
	public List<String> stdNumList;//학생번호가 들어있음
	public List<String> courseNumList;//과정번호가 들어있음--> 교사가 가지고 있는 과정에 대한 과정 정보가 들어있다는 뜻이 된다!
	//public Map<Integer, String[]> courseStdListMap;//과정에 대한 학생 출결정보를 넣어주는 Map!
	public List<String[]> courseStdList;
	
	public void stdAtdCheckMenu() {// 교육생의 출결을 알아보기 위한 메인메뉴
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		examSubList = new ArrayList<String[]>();//가용과목번호 집어넣을것이다

		try {

			String sql = "{call proc122search(?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속************************************
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			
			stat.setInt(1, TeacherLogin.teacherNumber);//실전용************************************
			//stat.setInt(1, 1);//테스트용
			stat.registerOutParameter(2, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(2);
			
			//System.out.println("[과목번호][담당교사 이름]\t[과목 시험일자]\t[과목종료일자]\t[과목명]");
			
			examSubList = new ArrayList<String[]>();//생성자를 만들어줘야한다!
			
			while(rs.next()) {

				
				String[] data = {rs.getString(1),rs.getString(4).substring(0,10),rs.getString(5)};//과목번호,과목종료일자,과목명
				
				examSubList.add(data);//데이터 입력
				
//				System.out.printf("%s\t%s\t\t%s\t%s\t%s\n",
//						rs.getString(1),
//						rs.getString(2),
//						rs.getString(3).substring(0,10),
//						rs.getString(4).substring(0,10),
//						rs.getString(5));
			}
			
			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();
			System.out.println("오류가 발생");

		}
		
		
		
		Scanner scan = new Scanner(System.in);

		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t1. 과목별 학생 출결 조회");
		System.out.println("\t\t\t\t2. 과정별 학생 출결 조회");//과정별 -> 기간입력
		System.out.println("\t\t\t\t3. 이름별 학생 출결 조회");//무조건 이름으로?!
		System.out.println("\t\t\t\t4. 뒤로");
		System.out.println("\t\t\t\t================================");

		System.out.print("\t\t\t\t번호 입력 : ");
		String input = scan.nextLine();

		switch (input) {

		case "1":
			bySub();//1. 과목별 학생 출결 조회
			break;
		case "2"://2. 과정별 학생 출결 조회
			System.out.println("\t\t\t\t서비스준비중");
			stdAtdCheckMenu();
			//twoMenu();
			
			//System.out.println("서비스준비중");
			//stdAtdCheckMenu();
			break;
		case "3"://3. 이름별 학생 출결 조회
			System.out.println("\t\t\t\t서비스준비중");
			stdAtdCheckMenu();
			break;
		case "4":
			TeacherMainMenu tm = new TeacherMainMenu();
			tm.tMenu();//4. 뒤로
			break;
		default:

		}

	}//stdAtdCheckMenu()
	
	/**
	 * 과목별 학생 출결 조회
	 */
	public void bySub() {//1. 과목별 학생 출결 조회
		
		Scanner scan = new Scanner(System.in);

		String subNum = "";// 과목번호 입력받음

		while (true) {// 번호입력 유효성 검사! -> 자신의 과목을 쓰고 있는건지 유효성을 검사 해주는것이다!
			System.out.print("\t\t\t\t과목번호를 입력하세요 : ");
			subNum = scan.nextLine();// 번호 입력받는다.

			boolean flag = false;

			for (int i = 0; i < examSubList.size(); i++) {
				if (examSubList.get(i)[0].equals(subNum)) {
					flag = true;
				}
			}

			if (flag) {// 잘 입력했다면 while문을 중단할 것이다.
				break;
			} else {// 잘못 입력했을떄
				System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n", TeacherLogin.teacherName);
			}
		}// while()
		
			
		stdSubjectCheck(Integer.parseInt(subNum));//해당 과목을 듣고 있는 학생들 정보 조회!
		
		String inputStdNum = "";//학생번호 입력받기 위해서
		
		while (true) {// 학생 번호입력 유효성 검사! -> 자신의 과목을 쓰고 있는건지 유효성을 검사 해주는것이다!
			System.out.print("\t\t\t\t출결상황 확인하고 싶은 학생의 번호 입력 : ");
			inputStdNum = scan.nextLine();//학생번호 입력받는다

			boolean flag = false;

			for (int i = 0; i < stdNumList.size(); i++) {
				if (stdNumList.get(i).equals(inputStdNum)) {
					flag = true;
				}
			}

			if (flag) {// 잘 입력했다면 while문을 중단할 것이다.
				break;
			} else {// 잘못 입력했을떄
				System.out.println("\t\t\t\t해당 과목내에 존재하지 않는 학생입니다.");
			}
		}// while()
		
		stdSubjectCheckFunc(Integer.parseInt(subNum),Integer.parseInt(inputStdNum));
		
		
		ErrorPage ep = new ErrorPage();
		ep.pause();
		stdAtdCheckMenu();//상위메뉴로 돌아가기
		
		
		
	}
	/**
	 * 특정 과목번호에 해당하는 수강생의 출결점수 조회
	 * @param subNum 과목번호
	 */
	public void stdSubjectCheck(int subNum) {//해당 수강생의 출결점수 조회 -> 매개변수는 과목번호가 들어가면 된다!
		
		Scanner scan = new Scanner(System.in);
		
		stdNumList = new ArrayList<String>();//학생번호 입력받을것
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc119new(?,?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속************************************
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			
			stat.setInt(1, subNum);//-> 과목번호 입력
			stat.setInt(2, TeacherLogin.teacherNumber);//-> 선생번호 입력************************************
			//stat.setInt(2,1);//테스트용
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
			
			System.out.println("[과목번호]\t[과목이름]\t\t\t[학생번호]\t\t[학생이름]\n");
			System.out.println();
			
			stdNumList = new ArrayList<String>();
			
			while(rs.next()) {
				
				stdNumList.add(rs.getString(3));//학생번호 넣어주기!
				
				System.out.printf("%s\t%s\t%s\t\t%s\n",
							rs.getString(1),
							rs.getString(2),
							rs.getString(3),
							rs.getString(4));

			}
			
			stat.close();
			conn.close();
			
	} catch (Exception e) {
		e.printStackTrace();
		System.out.println("오류발생");
	}

}
	/**
	 * 특정과목의 특정학생의 출결현황 관리
	 * @param subNum 과목번호
	 * @param stdNum 학생번호
	 */
	public void stdSubjectCheckFunc(int subNum,int stdNum) {//과목번호, 학생번호 
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc137subject(?,?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속************************************
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			
			stat.setInt(1, subNum);//실전용 -> 과목번호 입력
			stat.setInt(2,stdNum);//실전용 -> 학생번호 입력
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
			
			System.out.println("[학생번호]\t[학생이름]\t[출석날짜]\t\t[도착시간]\t[나간시간]\t[출석상태]\t[과목이름]\n");
			System.out.println();
			
			while(rs.next()) {
				
				String inTime = "";
				String outTime = "";
				
				if (rs.getString(4) == null && rs.getString(5) == null ) {
					inTime = "-----";
					outTime = "-----";
				} else {
					inTime = rs.getString(4).substring(11,16);
					outTime = rs.getString(5).substring(11,16);
				}
				


				
				
				
				System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
							rs.getString(1),
							rs.getString(2),
							rs.getString(3).substring(0,10),
							inTime,
							outTime,
							rs.getString(6),
							rs.getString(7));

			}
			
			stat.close();
			conn.close();
			
	} catch (Exception e) {
		e.printStackTrace();
		System.out.println("오류발생");
	}
		
		
	}
	/**
	 * 과정별 학생 출결 조회
	 */
	public void twoMenu() {// 2. 과정별 학생 출결 조회

		Scanner scan = new Scanner(System.in);
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc135whatcourse(?,?)}";// 프로시저 불러오기

			//conn = util.open("211.63.89.47","project","java1234");//실제
			// 접속************************************
			conn = util.open1();// 로컬 접속
			stat = conn.prepareCall(sql);

			 stat.setInt(1,TeacherLogin.teacherNumber);//실전용 -> 선생번호
			// 입력************************************
			//stat.setInt(1, 1);//테스트용번호
			stat.registerOutParameter(2, OracleTypes.CURSOR);

			stat.executeQuery();

			rs = (ResultSet) stat.getObject(2);

			System.out.println("[과정번호][과정시작일]\t\t[과정종료일]\t[과정기간(일)]\t[과정명]");
			
			courseNumList = new ArrayList<String>();//생성자 생성
			
			while (rs.next()) {
				
				courseNumList.add(rs.getString(1));//교사가 조회 가능한 과정만 쓸 수 있도록 리스트에 넣어주기

				System.out.printf("%s\t%s\t%s\t%s\t\t%s\n", rs.getString(1), rs.getString(2),
						rs.getString(3).substring(0, 11), rs.getString(4), rs.getString(5));

			}

			stat.close();
			conn.close();
			
			
			//여기서 이제 과정번호를 입력 받을것이다~~
			
			String courseNum = "";//과정번호
			
			
			while (true) {
				System.out.print("\t\t\t\t조회할 과정번호를 입력해주세요 : ");
				courseNum = scan.nextLine();//과정번호 입력받는다

				boolean flag = false;

				for (int i = 0; i < courseNumList.size(); i++) {
					if (courseNumList.get(i).equals(courseNum)) {
						flag = true;
					}
				}

				if (flag) {// 잘 입력했다면 while문을 중단할 것이다.
					break;
				} else {// 잘못 입력했을떄
					System.out.printf("\t\t\t\t%s 교사님께서 담당하신 과정이 아닙니다.\n",TeacherLogin.teacherName);
				}
			}// while()
			
			//이제 시작년월과 끝년월을 받아주자!
			System.out.println("\t\t\t\t조회 시작 날짜 입력 예시 : 2019-12-12");
			System.out.print("\t\t\t\t조회 시작할 날짜 입력 :");
			String startDay = scan.nextLine();
			System.out.println("\t\t\t\t조회 종료 날짜 입력 예시 : 2019-01-03");
			System.out.print("\t\t\t\t조회 종료할 날짜 입력 :");
			String endDay = scan.nextLine();
			//여기서 이제 메서드를 새로 하나 만들자
			searchDetail(courseNum,startDay,endDay);
			

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("오류발생");
		}

	}//twoMenu();
	
	
	public void searchDetail(String cNum, String start, String end) {// 과정번호와 시작날짜와 종료날짜를 받아서 목록을 출력을 해주자!

		Scanner scan = new Scanner(System.in);
		
		StringTokenizer stk1 = new StringTokenizer(start,"-");
		String sYear = stk1.nextToken();//시작년
		String sMon = stk1.nextToken();//시작월
		String sDate = stk1.nextToken();//시작일
		
		StringTokenizer stk2 = new StringTokenizer(end,"-");
		String eYear = stk2.nextToken();//종료년
		String eMon = stk2.nextToken();//종료월
		String eDate = stk2.nextToken();//종료일
		
		
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc135course(?,?,?,?,?,?,?,?,?)}";// 프로시저 불러오기

			//conn = util.open("211.63.89.47","project","java1234");//실제접속************************************
			conn = util.open1();// 로컬 접속
			stat = conn.prepareCall(sql);

			stat.setInt(1, TeacherLogin.teacherNumber);// 선생번호 -> 실전용************************************
			//stat.setInt(1, 1);// 선생번호 -> 연습용
			stat.setInt(2,Integer.parseInt(cNum));//과정번호
			stat.setString(3,sYear);//시작년도
			stat.setString(4,sMon);//시작월
			stat.setString(5,sDate);//시작일
			stat.setString(6,eYear);//종료년도
			stat.setString(7,eMon);//종료월
			stat.setString(8,eDate);//종료일
			stat.registerOutParameter(9, OracleTypes.CURSOR);

			stat.executeQuery();

			rs = (ResultSet) stat.getObject(9);

			//System.out.println("[학생번호]\t[학생이름]\t[날짜]\t[온시간]\t[나간시간]\t[출석상태]\t[과정시작일]\t[과정종료일]\t[과정번호]\t[과정명]\n");
			System.out.println();

			while (rs.next()) {
				

				String inTime = "";
				String outTime = "";

				if (rs.getString(4) == null && rs.getString(5) == null) {
					inTime = "-----";
					outTime = "-----";
				} else {
					inTime = rs.getString(4).substring(11, 16);
					outTime = rs.getString(5).substring(11, 16);
				}
				
				
				String[] inputList = {	rs.getString(1),
										rs.getString(2),
										rs.getString(3).substring(0,10),
										inTime,
										outTime,
										rs.getString(6),
										rs.getString(7).substring(0,11),
										rs.getString(8).substring(0,11),
										rs.getString(9),
										rs.getString(10)};
				
				courseStdList.add(inputList);//정보들을 넣어주기
				

//				System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
//									rs.getString(1),
//									rs.getString(2),
//									rs.getString(3).substring(0,11),
//									inTime,
//									outTime,
//									rs.getString(6),
//									rs.getString(7).substring(0,11),
//									rs.getString(8).substring(0,11),
//									rs.getString(9),
//									rs.getString(10));
//				
				
				
			}//while()
			
			stat.close();
			conn.close();
			
			//System.out.println("[학생번호]\t[학생이름]\t[날짜]\t[온시간]\t[나간시간]\t[출석상태]\t[과정시작일]\t[과정종료일]\t[과정번호]\t[과정명]\n");
			
			
			
			
			
//			//boolean flag = true;
//			int courseStdListLength = courseStdList.size();//과정속에 속한 학생들의 출결 데이터의 길이
//			int inPaging = courseStdListLength - (courseStdListLength/10);// -> 128 개라면 8개가 나올것이다.--> 남는 개수 
//			
//			double paging = courseStdListLength/10.0; // -> 128 개라면 12.8 이 나올것
//			int pageCount = (int)Math.ceil(paging);//올림함수 -> 12.8 이므로 13 이 될것이다.
//			
//			//0 ~ 10 나오고 11 ~ 20 나오고??!/....
//			
//			int wcount = 1;
//			int fIndex = 10;
//			int sIndex = 0;
//			
//			while(true) {
//				
//				System.out.println("[학생번호]\t[학생이름]\t[날짜]\t[온시간]\t[나간시간]\t[출석상태]\t[과정시작일]\t[과정종료일]\t[과정번호]\t[과정명]\n"); 
//				
//				for (int i = sIndex; i < fIndex; i++) {
//					System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",
//							courseStdList.get(i)[0],
//							courseStdList.get(i)[1],
//							courseStdList.get(i)[2],
//							courseStdList.get(i)[3],
//							courseStdList.get(i)[4],
//							courseStdList.get(i)[5],
//							courseStdList.get(i)[6],
//							courseStdList.get(i)[7],
//							courseStdList.get(i)[8],
//							courseStdList.get(i)[9]);
//				}
//				
//				
//				if (wcount == 1) {
//					System.out.println("========");
//					System.out.println("1.다음");
//					System.out.println("2.나가기");
//					System.out.println("========");
//					System.out.print("입력 : ");
//					int numInput = Integer.parseInt(scan.nextLine());//입력받기
//					
//					if (numInput == 1) {
//						
//					}
//					
//					
//				} else if (wcount > 1 && wcount < pageCount) {
//					System.out.println("========");
//					System.out.println("1.다음");
//					System.out.println("2.이전");
//					System.out.println("3.나가기");
//					System.out.println("========");
//					System.out.print("입력 : ");
//					int numInput = Integer.parseInt(scan.nextLine());//입력받기
//					
//				} else {
//					
//					
//					
//				}
//				
//			}//while()
	
	

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("오류발생");
		}
	}
	
	
	
	public static void main(String[] args) {

		StudentAttendanceCheck sa = new StudentAttendanceCheck();
		sa.stdAtdCheckMenu();
		
	}
	
	

}

package com.test.teacher;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

import oracle.jdbc.internal.OracleTypes;

public class Proc116 {
	
	
	//static Scanner scan = new Scanner(System.in);
	
	public static void proc116s(int teacherNum) {//교사가 자신이 강의하는 강의 스케쥴 출력!
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		try {
			
//			System.out.print("개설 과목 번호 입력: ");
//			String num1 = scan.nextLine();
//			System.out.print("수강생 번호 입력: ");
//			String num2 = scan.nextLine();
//			
			String sql = "{call proc116(?,?)}";
			
			
			conn = util.open("211.63.89.47","project","java1234");
			stat = conn.prepareCall(sql);
			stat.setInt(1, teacherNum);
			stat.registerOutParameter(2, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(2);
			
			
			
			System.out.println("[담당강사]\t\t[과정명]\t\t\t\t\t\t[과정시작일]\t\t\t[과정종료일]\t\t[과목명]\t\t\t[책제목]\t\t\t\t[과목시작일]\t\t[과목종료일]\t\t[강의현황]");
			
			
			while (rs.next()) {
				
				
				System.out.printf("%-30s\t%-30s\t\t%-30s\t\t%-30s\t%-30s\t%-30s\t%-30s\t\t%-30s\t%s\n",
						rs.getString(1),
						rs.getString(2),
						rs.getString(3),
						rs.getString(4),
						rs.getString(5),
						rs.getString(6),
						rs.getString(7),
						rs.getString(8),
						rs.getString(9));
				
				}
			
			
			//System.out.println(stat.getString(3));
			
			
			stat.close();
			conn.close();
			
			
			

		} catch (Exception e) {

			System.out.println("오류가 발생");

		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 proc116s(2);
		
		
	}

}

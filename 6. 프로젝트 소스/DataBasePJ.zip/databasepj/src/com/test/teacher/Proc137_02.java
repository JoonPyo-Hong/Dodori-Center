package com.test.teacher;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

import oracle.jdbc.internal.OracleTypes;


public class Proc137_02 {//개설과목과 수강생 번호를 입력하면 해당 교육생의 출결점수를 출력해준다!
	public static Scanner scan = new Scanner(System.in);
	
	
	public void proc137_02s() {
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		try {
			
			System.out.print("개설 과목 번호 입력: ");
			String num1 = scan.nextLine();
			System.out.print("수강생 번호 입력: ");
			String num2 = scan.nextLine();
			
			String sql = "{call proc137_02(?,?,?)}";
			
			
			conn = util.open("211.63.89.47","project","java1234");
			stat = conn.prepareCall(sql);
			stat.setInt(1, Integer.parseInt(num1));
			stat.setInt(2, Integer.parseInt(num2));
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
			
			int totalScore = 100;
			
			while (rs.next()) {
				
				String state = rs.getString("attendense_state");
				int stateNum =  Integer.parseInt(rs.getString("cnt"));
				
				if (state.equals("지각")) totalScore -= 1*stateNum;
				if (state.equals("결석")) totalScore -= 2*stateNum;
				if (state.equals("조퇴")) totalScore -= 1*stateNum;
				
//				System.out.println(rs.getString("attendense_state"));
//				System.out.println(rs.getString("cnt"));
			}
			
			
			//System.out.println(stat.getString(3));
			
			
			stat.close();
			conn.close();
			
			
			System.out.printf("%s번 교육생의 출결점수는 %d 점입니다",num1,totalScore);

		} catch (Exception e) {

			System.out.println("오류가 발생");

		}
	}
	
	
	public static void main(String[] args) {
		
		
		
	}//

}

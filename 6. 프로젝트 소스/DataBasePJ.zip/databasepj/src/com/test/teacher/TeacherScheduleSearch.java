package com.test.teacher;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import oracle.jdbc.internal.OracleTypes;
/**
 * 
 * @author shin
 *
 */
public class TeacherScheduleSearch {
	
	
	/**
	 * 강의 스케쥴을 조회 메뉴
	 */
	public void scheduleSearch() {//강의 스케쥴 조회 하는곳
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t1. 전체 스케줄 출력");
		System.out.println("\t\t\t\t2. 특정 과목 소속 교육생 정보 확인");
		System.out.println("\t\t\t\t3. 뒤로가기");
		System.out.println("\t\t\t\t================================");
		
		System.out.print("\t\t\t\t선택(번호) : ");
		String input = scan.nextLine();
		
		switch(input) {
		case "1" :
			scheduleSearchTotal();//1. 전체 스케줄 출력
			break;
		case "2" :
			scheduleSearchSubject();//2. 특정 과목 소속 교육생 정보 확인
			break;
		case "3" ://3. 뒤로가기
			//TeacherMainMenu tm = new TeacherMainMenu();
			//tm.tMenu();
			break;
		default :
			break;
		}
	}
	
	/**
	 * 전체 스케쥴 출력
	 */
	public void scheduleSearchTotal() {//1.전체 스케쥴 출력
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc116(?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			stat.setInt(1, TeacherLogin.teacherNumber);//실전용
			//stat.setInt(1, 1);//테스트용
			stat.registerOutParameter(2, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(2);
			
			System.out.println("[과정명]－－－－[과정 시작일]－－－－[과정 종료일]－－－－[과목명]－－－－[과목번호]－－－－[교재명]－－－－[과목 시작일]－－－－[과목 종료일]－－－－[강의진행상태]");
			System.out.println();
			
			while(rs.next()) {
				
				System.out.printf("[과정명]%s－－－－[과정 시작일]%s－－－－[과정 종료일]%s－－－－[과목명]%s－－－－[과목번호]%s－－－－[교재명]%s－－－－[과목 시작일]%s－－－－[과목 종료일]%s－－－－[강의진행상태]%s\n",
						rs.getString(2),
						rs.getString(3).substring(0,10),
						rs.getString(4).substring(0,10),
						rs.getString(5),
						rs.getString(6),
						rs.getString(7),
						rs.getString(8).substring(0,10),
						rs.getString(9).substring(0,10),
						rs.getString(10));
			}
			
			stat.close();
			conn.close();
			
			ErrorPage ep = new ErrorPage();
			ep.pause();
			//TeacherScheduleSearch ts = new TeacherScheduleSearch();
			scheduleSearch();//다시 상위 메뉴로 돌아가서 선택
			

		} catch (Exception e) {

			System.out.println("오류가 발생");

		}
		
	}
	/**
	 * 특정과목 소속 교육생 정보 확인
	 */
	
	public void scheduleSearchSubject() {//2. 특정 과목 소속 교육생 정보 확인
		Scanner scan = new Scanner(System.in);
		
		List<String[]> arr = new ArrayList<String[]>();//학생정보 배열을 넣기 위한 List 라고 생각
		
		System.out.print("\t\t\t\t과목번호 선택(번호) : ");
		String input = scan.nextLine();//과목번호 입력받기
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc119(?,?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			//stat.setInt(1, 26);//테스트용 -> 과목번호 입력
			//stat.setInt(2, 1);//테스트용 -> 선생번호 입력
			
			stat.setInt(1, Integer.parseInt(input));//실전용 -> 과목번호 입력
			stat.setInt(2, TeacherLogin.teacherNumber);//실전용  -> 선생번호 입력
			
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
			
			System.out.println("[과목번호]\t\t[과목이름]\t\t\t[학생이름]\t\t[전화번호]\t\t[등록일]\t\t[수강상태]");
			System.out.println();
			
			while(rs.next()) {
				
				String[] strList = {rs.getString(1),
									rs.getString(2),
									rs.getString(3),
									rs.getString(4),
									rs.getString(5).substring(0,10),
									rs.getString(6)};//학생정보 넣어두는 곳 문자열 배열 생성!
				
				arr.add(strList);
				
				System.out.printf("%s\t\t%s\t%s\t\t%s\t%s\t%s\n",
							rs.getString(1),
							rs.getString(2),
							rs.getString(3),
							rs.getString(4),
							rs.getString(5).substring(0,10),
							rs.getString(6));

				
				
			}
			
			stat.close();
			conn.close();
			
			
			
			ErrorPage ep = new ErrorPage();
			System.out.println();
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 학생이름 조회");
			System.out.println("\t\t\t\t2. 뒤로 가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t선택(번호) : ");
			input = scan.nextLine();//입력받기
			
			if (input.equals("1")) {//1. 학생이름 조회
				
				System.out.print("\t\t\t\t학생이름 입력 : ");
				input = scan.nextLine();//학생 이름 입력받기
				
				List<Integer> matchStdList = new ArrayList<Integer>();
				
				for (int i = 0; i < arr.size(); i++) {
					if (arr.get(i)[2].equals(input)) {
						matchStdList.add(i);
					}
				}//어느 번쨰 순서가 맞는지 하나하나 확인해 주는 작업이라고 볼 수 있다!
				
				
				if (matchStdList.size() == 0) {//입력한 이름이 리스트에 없는 경우 --> 즉 수강하지 않은 교육생의 이름을 넣었을때
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t입력하신 이름에 부합하는 학생이름이 존재하지 않습니다.");
					System.out.println("\t\t\t\t================================");
					ep.pause();
					scheduleSearchSubject();
					
					
				} else {//입력한 이름이 리스트에 있는 경우
					
					System.out.println("[과목번호]\t\t\t[과목이름]\t\t\t[학생이름]\t\t[전화번호]\t\t[등록일]\t\t[수강상태]");
					System.out.println();
					
					for (int i = 0; i < matchStdList.size(); i++) {

						for (int j = 0; j < 6; j++) {
							
							if (j == 0) {
								System.out.print(arr.get(matchStdList.get(i))[j] + "\t\t\t");
							}
							else  if (j == 2) {
								System.out.print(arr.get(matchStdList.get(i))[j] + "\t\t");
							}
							else {
								System.out.print(arr.get(matchStdList.get(i))[j] + "\t");
							}
						
						}
						System.out.println();
					}
					
					ep.pause();
					scheduleSearch();

				}
				

			} else {//2. 뒤로 가기
				System.out.println("\t\t\t\t뒤로 가기를 눌렀습니다.");
				ep.pause();
				//TeacherScheduleSearch ts = new TeacherScheduleSearch();
				scheduleSearch();//다시 상위 메뉴로 돌아가서 선택
				
			}
			
			
			

		} catch (Exception e) {

			System.out.println("\t\t\t\t오류가 발생");
			
		}
	}
	
	
	
	public static void main(String[] args) {
		
		TeacherScheduleSearch ts = new TeacherScheduleSearch();
		
		ts.scheduleSearch();
		
		
	}
		
	

}

package com.test.teacher;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

import oracle.jdbc.internal.OracleTypes;

/**
 * 
 * @author shin
 *
 */
public class StudentGrade {//성적 입출력!
	
	public List<String[]> infoList;//자신이 가르쳤던(과거) 과목에 대한 정보를 넣어줄것이다 -> 여기에서는 굳이 필요있을지 의문이 든다.
	
	public void gradeSearch() {//교사가 강의를 마친 과목 목록 출력

		Scanner scan = new Scanner(System.in);

		System.out.println("\t\t\t\t================================");
		System.out.printf("\t\t\t\t%s 교사님 이 마친 과목 목록을 출력합니다.\n", TeacherLogin.teacherName);
		System.out.println("\t\t\t\t================================");
		
		ErrorPage ep = new ErrorPage();
		ep.pause();

		infoList = new ArrayList<String[]>();// 자신이 가르쳤던(과거) 과목에 대한 정보를 넣어줄것이다

		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc121print(?,?)}";// 프로시저 불러오기

			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();// 로컬 접속
			stat = conn.prepareCall(sql);

			stat.setInt(1, TeacherLogin.teacherNumber);// 실전용
			//stat.setInt(1, 1);//테스트용
			stat.registerOutParameter(2, OracleTypes.CURSOR);

			stat.executeQuery();

			rs = (ResultSet) stat.getObject(2);

			System.out.println("[과목번호][담당교사 이름]\t[과목 시작일자]\t[과목 종료일자]\t[과목명]");
			System.out.println();

			while (rs.next()) {

				String[] strList = { rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9) };

				infoList.add(strList);// 정보 넣어주기

				System.out.printf("%s\t%s\t\t%s\t%s\t%s\n", rs.getString(1), rs.getString(3),
						rs.getString(5).substring(0, 10), rs.getString(6).substring(0, 10), rs.getString(2));
			}

			stat.close();
			conn.close();

			// 상세적으로 메뉴로 들어간다
			stdMenu();//상세메뉴 시작
			

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("오류가 발생");
			
		}

	}
	/**
	 * 교육생 정보 관련 메뉴
	 */
	public void stdMenu() {

		Scanner scan = new Scanner(System.in);

		while (true) {

			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 교육생 기본정보 출력");
			System.out.println("\t\t\t\t2. 교육생 성적 조회 및 입력");
			System.out.println("\t\t\t\t3. 뒤로가기");
			System.out.println("\t\t\t\t================================");

			System.out.print("\t\t\t\t번호 입력  : ");
			String input = scan.nextLine();

			switch (input) {
			case "1":
				stdInfoSearch();//1. 교육생 기본정보 출력
				break;
			case "2":
				stdGradeMenu();//2. 교육생 성적 조회 및 입력
				break;
			case "3":
				TeacherMainMenu tm = new TeacherMainMenu();
				tm.tMenu();
				break;
			default:
				break;
			}
		}
	}
	
	/**
	 * 교육생 정보 출력
	 */
	public void stdInfoSearch() {//교육생 정보 출력
		
		Scanner scan = new Scanner(System.in);
		String subNum = "";
		while (true) {//번호입력 유효성 검사!
			System.out.print("\t\t\t\t과목번호를 입력하세요 : ");
			subNum = scan.nextLine();// 번호 입력받는다.

			boolean flag = false;

			for (int i = 0; i < infoList.size(); i++) {
				if (infoList.get(i)[0].equals(subNum)) {
					flag = true;
				}
			}

			if (flag) {
				break;
			} else {// 잘못 입력했을떄
				System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n", TeacherLogin.teacherName);
			}
		}
		
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc129StudentInfo(?,?,?)}";// 프로시저 불러오기

			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();// 로컬 접속
			stat = conn.prepareCall(sql);

			stat.setInt(1, TeacherLogin.teacherNumber);// 실전용
			//stat.setInt(1, 1);//테스트용-> 선생번호
			stat.setInt(2, Integer.parseInt(subNum));
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();

			rs = (ResultSet) stat.getObject(3);

			System.out.println("[과목번호]\t[교육생 번호]\t[교육생 이름]\t[교육생 전화번호]\t[교육생 전공여부]\t[과목진행상태]\t[과목명]");
			System.out.println();

			while (rs.next()) {
			
				String ymd = rs.getString(7).substring(0,10);//
				
				String state = "";
				
				StringTokenizer stk = new StringTokenizer(ymd,"-");
				
				int year = Integer.parseInt(stk.nextToken());//년
				int month = Integer.parseInt(stk.nextToken());//월
				int date = Integer.parseInt(stk.nextToken());//일
				
				Calendar c1 = Calendar.getInstance();
				c1.set(year,month,date);
				long subState = c1.getTimeInMillis();
				Calendar c2 = Calendar.getInstance();
				long present = c2.getTimeInMillis();
				
				if (present > subState) {
					state = "수료";
				} else {
					state = "미수료";
				}
				
				
			
				System.out.printf("%s\t%s\t\t%s\t\t%s\t%s\t\t%s\t\t%s\n",
									rs.getString(1),
									rs.getString(3),
									rs.getString(4),
									rs.getString(5),
									rs.getString(6),
									state,
									rs.getString(2));
	
			}

			stat.close();
			conn.close();
			
			ErrorPage ep = new ErrorPage();
			ep.pause();
			
			

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("오류가 발생");
			
		}
	}
	/**
	 * 교육생 성적 조회 및 입력  메인메뉴
	 */
	public void editStdGradeMenu() {//2. 교육생 성적 조회 및 입력 -> 메인메뉴
		
		
		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t1. 출결점수 입력");
		System.out.println("\t\t\t\t2. 교육생 성적 입력(출결은 제외)");
		System.out.println("\t\t\t\t3. 뒤로가기");
		System.out.println("\t\t\t\t================================");
		
		System.out.print("\t\t\t\t입력 : ");
		String input = scan.nextLine();
		
		switch(input) {
		case "1" :
			attendStdGrade();//1. 출결점수 입력
			break;
		case "2" :
			//searchGradeStd();//2. 교육생 성적 조회 및 입력(출결은 제외)
			gradeStdInput();
			break;
		case "3" :
			gradeSearch();//3.뒤로가기
			break;
		}
		
		
		
		
	}
	/**
	 * 출결점수 입력
	 */
	public void attendStdGrade() {//2-1 출결점수 입력
		Scanner scan = new Scanner(System.in);
		
		String subNum = "";//과목번호
		
		
		while (true) {//번호입력 유효성 검사!
			System.out.print("\t\t\t\t과목번호를 입력하세요 : ");
			subNum = scan.nextLine();// 번호 입력받는다.

			boolean flag = false;

			for (int i = 0; i < infoList.size(); i++) {
				if (infoList.get(i)[0].equals(subNum)) {
					flag = true;
				}
			}

			if (flag) {
				break;
			} else {// 잘못 입력했을떄
				System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n", TeacherLogin.teacherName);
			}
		}//while()
		
		
		stdSubjectCheck(Integer.parseInt(subNum));//해당 과목을 듣는 학생들의 기본정보 입력
		
		//--------------------------------------------------------------------------
		
		System.out.print("\t\t\t\t수강생 번호 입력: ");
		String stdNum = scan.nextLine();//수강생 번호
		
		int atdScore = attendScorePrint(subNum,stdNum);//해당 학생의 출석점수
		//System.out.println(atdScore);
		
		//여기서 이제 출석 성적을 입력해주면 된다!
		int tblScore = getNumtblScore(stdNum,subNum);//성적번호가 나오게 된다!
		
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		
		try {
			
			
			//System.out.println(atdScore);
			//System.out.println(tblScore);
			
			String sql = String.format("update tblScore set attendence_score = %d where seq_score = %d",
										atdScore,tblScore);
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//DB에 연결시작
			
			stat = conn.createStatement();//쿼리를 대신 날려줄놈을 먼저 생성해준다
			
			int result = stat.executeUpdate(sql);
			
			//int result = stat.executeUpdate(sql);//-> 적용된 행의 개수를 말해주는것이기 때문에 ddl,dcl 에서는 아무런 의미가 없는 숫자가 된다!
			
			stat.close();
			conn.close();
			
			
			System.out.println("\t\t\t\t " + result + "개 의 행 변경");
			
		} catch(Exception e) {
			e.printStackTrace();
			System.out.println("\t\t\t\t오류발생");
		}
		

	}
	/**
	 * 특정과목내에 특정 학생의 성적점수 번호 알아내기
	 * @param stdNum 학생번호
	 * @param subNum 과목번호
	 * @return 성적점수 번호
	 */
	public int getNumtblScore(String stdNum, String subNum) {//학생 번호와 과목번호를 통해서 성적점수의 번호를 불러온다!
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		int result  = -1;

		try {

			String sql = "{call procScoreInput_std12345(?,?,?)}";//프로시저 불러오기
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			
			stat.setInt(1, Integer.parseInt(stdNum));
			stat.setInt(2, Integer.parseInt(subNum));
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
		
			
			while(rs.next()) {
				
				 result = Integer.parseInt(rs.getString(1));


			}
			
			stat.close();
			conn.close();
			
			
			

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("\t\t\t\t오류가 발생");

		}
		
		return result;
		
		
	}
	/**
	 * 특정 과목에 특정 학생의 출결점수 알아내기
	 * @param subNum 개설과목번호
	 * @param stdNum 학생번호
	 * @return 출결점수
	 */
	public int attendScorePrint(String subNum,String stdNum) {//개설 과목 입력, 학생번호 입력
		
		//Scanner scan = new Scanner(System.in);
		
		int result = -1;
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		try {
			
//			System.out.print("개설 과목 번호 입력: ");
//			String num1 = scan.nextLine();
//			System.out.print("수강생 번호 입력: ");
//			String num2 = scan.nextLine();
			
			String sql = "{call proc137_02(?,?,?)}";
			
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속 아이피
			conn = util.open1();//테스트용 서버
			stat = conn.prepareCall(sql);
			stat.setInt(1, Integer.parseInt(subNum));//개설 과목 번호
			stat.setInt(2, Integer.parseInt(stdNum));//수강생 번호
			stat.registerOutParameter(3, OracleTypes.CURSOR);
			
			
			
			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
			
			int totalScore = 100;
			
			while (rs.next()) {
				
				String state = rs.getString("attendense_state");
				int stateNum =  Integer.parseInt(rs.getString("cnt"));
				
				if (state.equals("지각")) totalScore -= 1*stateNum;
				if (state.equals("결석")) totalScore -= 2*stateNum;
				if (state.equals("조퇴")) totalScore -= 1*stateNum;
				
//				System.out.println(rs.getString("attendense_state"));
//				System.out.println(rs.getString("cnt"));
			}
			
			
			//System.out.println(stat.getString(3));
			//System.out.println(totalScore);//해당 수강생 점수를 나타내준다
			result = totalScore;
			System.out.printf("\t\t\t\t%s번 교육생의 출결점수는 %d 점입니다\n",stdNum,totalScore);
			stat.close();
			conn.close();
			
			
			

		} catch (Exception e) {

			System.out.println("오류가 발생");
			
		}
		
		return result;
		
	}
	
	/**
	 * 
	 * @param stdNum 학생번호
	 * 해당수강생의 출결점수 조회
	 */
	public void stdSubjectCheck(int stdNum) {//해당 수강생의 출결점수 조회 -> 매개변수는 과목번호가 들어가야 한다!
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc119new(?,?,?)}";//프로시저 불러오기
			
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			//stat.setInt(1, 26);//테스트용 -> 과목번호 입력
			//stat.setInt(2, 1);//테스트용 -> 선생번호 입력
			
			stat.setInt(1, stdNum);//실전용 -> 과목번호 입력
			stat.setInt(2, TeacherLogin.teacherNumber);//실전용  -> 선생번호 입력
			//stat.setInt(2,1);//테스트용
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
			
			System.out.println("[과목번호]\t[과목이름]\t\t\t[학생번호]\t\t[학생이름]\t[전화번호]\t\t[등록일]\t\t[수강상태]");
			System.out.println();
			
			while(rs.next()) {
				
				System.out.printf("%s\t%s\t%s\t\t%s\t%s\t%s\t%s\n",
							rs.getString(1),
							rs.getString(2),
							rs.getString(3),
							rs.getString(4),
							rs.getString(5),
							rs.getString(6).substring(0,10),
							rs.getString(7));

			}
			
			stat.close();
			conn.close();
	} catch (Exception e) {
		e.printStackTrace();
		System.out.println("오류발생");
	}
		
	
}
	
	/**
	 * 2. 교육생 성적 조회 및 입력(출결은 제외)
	 */
	public void stdGradeMenu() {//2. 교육생 성적 조회 및 입력(**출결은 제외**) -> 여기서 메뉴를 선택하도록 만들자
		Scanner scan = new Scanner(System.in);
		
		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t1. 교육생 성적 조회");
		System.out.println("\t\t\t\t2. 교육생 성적  입력");
		System.out.println("\t\t\t\t3. 뒤로가기");
		System.out.println("\t\t\t\t================================");
		
		System.out.print("\t\t\t\t입력 : ");
		String input = scan.nextLine();
		
		switch(input) {
		case "1":
			searchGradeStd();//1. 교육생 성적 조회
			break;
		case "2":
			editStdGradeMenu();//2. 교육생 성적  입력
			break;
		case "3":
			gradeSearch();//3. 뒤로가기
			break;
		default :
			break;
		}
		
		
		
	}
	/**
	 * 교육생 성적 조회
	 */
	public void searchGradeStd() {// 2-1. 교육생 성적 조회~~

		Scanner scan = new Scanner(System.in);

		String subNum = "";// 과목번호

		while (true) {// 번호입력 유효성 검사! -> 자신의 과목을 쓰고 있는건지 유효성을 검사 해주는것이다!
			System.out.print("\t\t\t\t과목번호를 입력하세요 : ");
			subNum = scan.nextLine();// 번호 입력받는다.

			boolean flag = false;

			for (int i = 0; i < infoList.size(); i++) {
				if (infoList.get(i)[0].equals(subNum)) {
					flag = true;
				}
			}

			if (flag) {// 잘 입력했다면 while문을 중단할 것이다.
				break;
			} else {// 잘못 입력했을떄
				System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n", TeacherLogin.teacherName);
			}
		} // while()

		stdSubjectCheck(Integer.parseInt(subNum));// 해당 과목을 듣는 학생들의 기본정보 입력

		// 여기서 학생들
		// 여기서 중단하고 뒤로가기를 해주자!
		
		System.out.print("\t\t\t\t성적 조회할 학생의 학생번호를 입력하세요 : ");
		int stdNumInput = Integer.parseInt(scan.nextLine());//성적 조회할 학생의 번호 입력
		
		stdScoreSearch(stdNumInput, subNum);//학생성적 조회
		
		ErrorPage ep = new ErrorPage();
		ep.pause();
		stdGradeMenu();//상위 메뉴로 돌아가주기

	}
	/**
	 * 학생번호와 과목번호 입력해주면 그 학생의 과목에 대한 성적을 출력해준다!
	 * @param stdNum  학생번호
	 * @param subNum 과목번호
	 */
	public void stdScoreSearch(int stdNum,String subNum) {//학생번호와 과목번호 입력해주면 그 학생의 과목에 대한 성적을 출력해준다!
		
		
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
		int result  = -1;

		try {

			String sql = "{call proc127GradeSearch(?,?,?)}";//프로시저 불러오기
			//conn = util.open("211.63.89.47","project","java1234");//실제 접속
			conn = util.open1();//로컬 접속
			stat = conn.prepareCall(sql);
			
			stat.setInt(1, Integer.parseInt(subNum));//과목번호
			stat.setInt(2, stdNum);//학생번호
			stat.registerOutParameter(3, OracleTypes.CURSOR);

			stat.executeQuery();
			
			rs = (ResultSet)stat.getObject(3);
		
			System.out.println("[학생번호][학생이름][출결점수][필기점수][실기점수]\t[과목명]");
			
			while(rs.next()) {
				
				 System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\n",
						 			rs.getString(1),
						 			rs.getString(2),
						 			rs.getString(3),
						 			rs.getString(4),
						 			rs.getString(5),
						 			rs.getString(6));
			}
			
			
			//ErrorPage ep = new ErrorPage();
			//ep.pause();
			
			stat.close();
			conn.close();
			
			
			

		} catch (Exception e) {

			System.out.println("오류가 발생");

		}
		
		
		
	}
	
	/**
	 * 교육생 성적 입력
	 */
	public void gradeStdInput() {//2. 교육생 성적  입력
		
		Scanner scan = new Scanner(System.in);

		String subNum = "";// 과목번호

		while (true) {// 번호입력 유효성 검사! -> 자신의 과목을 쓰고 있는건지 유효성을 검사 해주는것이다!
			System.out.print("\t\t\t\t과목번호를 입력하세요 : ");
			subNum = scan.nextLine();// 번호 입력받는다.

			boolean flag = false;

			for (int i = 0; i < infoList.size(); i++) {
				if (infoList.get(i)[0].equals(subNum)) {
					flag = true;
				}
			}

			if (flag) {// 잘 입력했다면 while문을 중단할 것이다.
				break;
			} else {// 잘못 입력했을떄
				System.out.printf("\t\t\t\t%s교사님 께서 가르치시지 않은 과목이거나, 과목번호를  잘못 입력하셨습니다.\n", TeacherLogin.teacherName);
			}
		} // while()

		stdSubjectCheck(Integer.parseInt(subNum));// 해당 과목을 듣는 학생들의 기본정보 입력
		
		int stdInput = -1;//학생번호 입력
		int writeScore = -1;//필기점수 입력
		int practiceScore = -1;//실기점수 입력
		
		boolean flag = true;
		while (flag) {

			System.out.print("\t\t\t\t학생번호 입력 : ");
			stdInput = Integer.parseInt(scan.nextLine());
			System.out.print("\t\t\t\t필기점수 입력 : ");
			writeScore = Integer.parseInt(scan.nextLine());
			System.out.print("\t\t\t\t실기점수 입력 : ");
			practiceScore = Integer.parseInt(scan.nextLine());

			if (writeScore > 100 || writeScore < 0) {
				System.out.println("\t\t\t\t필기 점수는 0~100 점 사이로 입력 가능합니다.");
			} else if (practiceScore > 100 || practiceScore < 0) {
				System.out.println("\t\t\t\t실기 점수는 0~100 점 사이로 입력 가능합니다");
			} else {
				flag = false;// 탈출
			}

		} // while (flag)
		
		
		// 조회 및 입력 메서드로 뺴는게 좋을지 생각해보자
		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			String sql = "{call proc128scoreInput(?,?,?,?,?)}";

			//conn = util.open("211.63.89.47","project","java1234");//실제 접속 아이피
			conn = util.open1();// 테스트용 서버
			stat = conn.prepareCall(sql);
			stat.setInt(1, TeacherLogin.teacherNumber);// 실전용 -> 선생번호 입력
			//stat.setInt(1, 1);// 테스트용 -> 선생번호 입력
			stat.setInt(2, Integer.parseInt(subNum));// 개설과목번호
			stat.setInt(3, stdInput);// 학생번호
			stat.setInt(4, writeScore);// 필기점수
			stat.setInt(5, practiceScore);// 실기점수

			//stat.registerOutParameter(3, OracleTypes.CURSOR);
			stat.executeUpdate();//업데이트! -> 업데이트 이력을 보여주는게 좋겠지??

			stat.close();
			conn.close();
			
			

		} catch (Exception e) {

			e.printStackTrace();
			System.out.println("오류가 발생");

		}
		
		stdScoreSearch(stdInput,subNum);
		ErrorPage ep = new ErrorPage();
		ep.pause();
		stdGradeMenu();//상위 메뉴로 돌아가기
		
		
		
	}

	
	
	public static void main(String[] args) {
		
		StudentGrade sg = new StudentGrade();
		//sg.stdSubjectCheck(26);
		//sg.editStdGradeMenu();
		//sg.gradeSearch();
		//sg.searchGradeStd();
		sg.gradeSearch();
		
	}
}

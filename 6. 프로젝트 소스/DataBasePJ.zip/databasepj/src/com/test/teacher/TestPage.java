package com.test.teacher;

import java.util.Calendar;

public class TestPage {

	public static void main(String[] args) {
		
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		
		c1.set(2020,2,15);
		c2.set(2020,3,15);
		
		
		long l1 = c1.getTimeInMillis();
		long l2 = c2.getTimeInMillis();

		System.out.println(l2 - l1);

		
		System.out.printf("%tF",c1);

		
		
		
		
	}
	
}




class p1{
	public p1() {
		
	}
}
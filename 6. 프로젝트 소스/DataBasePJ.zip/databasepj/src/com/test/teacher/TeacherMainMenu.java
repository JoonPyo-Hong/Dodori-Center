package com.test.teacher;

import java.util.Scanner;

import com.test.main.Main;

/**
 * 
 * @author shin
 *
 */
public class TeacherMainMenu {

	/**
	 * 교사 메인페이지 접속
	 */
	public void tMenu() {// 교사 메인페이지 접속

		boolean flag = true;
		while (flag) {
			Scanner scan = new Scanner(System.in);

			System.out.println("\t\t\t\t================================");
			System.out.printf("\t\t\t\t%s 교사님 환영합니다.\n", TeacherLogin.teacherName);
			System.out.println("\t\t\t\t================================");

			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 강의 스케쥴 조회");
			System.out.println("\t\t\t\t2. 배점 입출력");
			System.out.println("\t\t\t\t3. 성적 입출력");
			System.out.println("\t\t\t\t4. 학생 출결관리");
			System.out.println("\t\t\t\t5. 뒤로가기");
			System.out.println("\t\t\t\t================================");

			System.out.print("\t\t\t\t선택(번호) : ");
			String input = scan.nextLine();

			switch (input) {
			case "1":// 1. 강의스케쥴 조회
				TeacherScheduleSearch tss = new TeacherScheduleSearch();
				tss.scheduleSearch();
				break;
			case "2":// 2. 배점 입출력
				DistributionScore ds = new DistributionScore();
				ds.distribution();// 여기로 다시 돌아온다.
				break;
			case "3":// 3.성적 입출력
				StudentGrade sg = new StudentGrade();
				sg.gradeSearch();
				break;
			case "4":// 4.학생 출결관리
				StudentAttendanceCheck sac = new StudentAttendanceCheck();
				sac.stdAtdCheckMenu();
				break;
			case "5":// 다시 메인 메뉴로 돌아가주기
				Main tl = new Main();
				tl.m();
				// break;
				flag = false;
			default:

			}
		}

	}

}

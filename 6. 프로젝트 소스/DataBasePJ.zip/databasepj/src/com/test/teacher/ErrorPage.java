package com.test.teacher;

import java.util.Scanner;

public class ErrorPage {//에러 상황에서 일어날 수 있는 메서드를 모아둠
	
	public void pause() {//숨고르는 메서드
		
		System.out.println("\t\t\t\t계속 하려면 엔터를 누르세요");
		
		Scanner scan = new Scanner(System.in);
		scan.nextLine();
	}
	
	public void pause(String input) {// 숨고르는 메서드

		System.out.println("\t\t\t\t" + input);

		Scanner scan = new Scanner(System.in);
		scan.nextLine();
	}
	
	
	public String exitOrGo(String sinput) {
		
		System.out.println(sinput);
		System.out.print("\t\t\t\t입력 : ");
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		
		return input;
		
	}
	
	
	
	public String exitOrGo() {
		
		System.out.println("계속 진행하시려면 1을 아니면 0을 눌러주세요");
		
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		
		return input;
		
	}

}

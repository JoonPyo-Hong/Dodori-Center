package com.test.student;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
/**
 * 
 * @author 홍준표
 *
 */
public class Select172 {
	private String q = "";
	/**
	 * 동아리 신청
	 */
	public void select() {
		Scanner scan = new Scanner(System.in);
			
		
		// 교육생 아이디 비밀번호 가져오기
		Student st = new Student();
		String name = st.id;
		String ssn = st.pw;
		 
		// 동아리 목록 출력
		  m();
		
		  System.out.println("============================");
	      System.out.println("1. 동아리 신청");
	      System.out.println("2. 이전 화면");
	      System.out.println("----------------------------");
		  System.out.print("선택(번호): ");
		  String input = scan.nextLine();
		  
		  if(input.equals("1")) {
			  
		 // 1. 동아리 신청 
			 
			  
			  // 동아리 신청에 필요한 시퀀스 받아오기
			  extracted();
			  
			  // 동아리 신청 구현
			  s();
			  
			  
		  }else if(input.equals("2")) {
			  DongariOutput o = new DongariOutput();
			  o.output();
		  }else {
			  System.out.println("잘못 입력하셨습니다.");
			  System.out.println("계속 하시려면 엔터를 누르세요...");
			  String enter = scan.nextLine();
			  select();
		  }
		  
	      
	}
/**
 * 동아리 신청구현
 */
	private void s() {
		System.out.print("신청할 동아리 번호를 입력 : ");
		Scanner scan = new Scanner(System.in);
		String input = scan.nextLine();
		
		if(input.equals("1")||input.equals("2")||input.equals("3")||input.equals("4")||input.equals("5")||input.equals("6")||input.equals("7")||
				input.equals("8")||input.equals("9")||input.equals("10")) {
			try {
				
				
				// 객체 생성
				Connection conn = null;
				CallableStatement stat = null;
				DBUtil util = new DBUtil();
				
				// 3조 연결
				conn = util.open("211.63.89.47","project","java1234");
				
				// 컬럼 수만큼 = ?
				String sql ="{call proc18901(?,?)}";
				stat = conn.prepareCall(sql);
				
			
				
				int a = Integer.parseInt(q);
				int b = Integer.parseInt(input);
				
				
				stat.setInt(1, a);
				
				stat.setInt(2, b);
				
				
				// select 에서 Update
				
				stat.executeUpdate();
				
				
				// 자원 닫기
				stat.close();
				conn.close();
				
			
			//오류 발생
			} catch (Exception e) {
			
				System.out.println(e);
			}
			Student st = new Student();
			String name = st.id;
			System.out.println("----------------------------");
			System.out.printf("%s님의 동아리 가입신청이 완료 되었습니다",name);
			System.out.println();
			
		}else {
			System.out.println("목록에 없는 번호를 입력하셨습니다");
			System.out.println("----------------------------");
			s();
		}
		
		
		
	}
/**
 * 동아리 신청에 필요한 시퀀스 받아오기
 */
	private void extracted() {
		//-------------------
		Student st = new Student();
		String name = st.id;
		String ssn = st.pw;
			// 필요한 객체 생성
			Connection conn = null;
			Statement stat = null;
			ResultSet rs = null;
			DBUtil util = new DBUtil();
			
			// 구현부
		      try {
		    	  // 3조 SQL 연결
			         conn = util.open("211.63.89.47","project","java1234");
		    	
		         stat = conn.createStatement();

		         // select문 삽입
		         String sql = "select seq_student from tblstudent where student_name = '" + name + "'";
		         rs = stat.executeQuery(sql);
		         
		         // select문 마지막행까지 반복
		         while(rs.next()) {
		            
		            	 q = rs.getString(1);  	            
		         }
		         
		         // 자원 닫기
		         stat.close();
		         conn.close();
		        
		         // 예외 처리
		      	} catch (Exception e) {
		         System.out.println("오류 발생");
		  
		      	}
		    //--------------------------------
		      
		      
		      
		      
		      
		      
		  
		  //--------------------
	}

		// 동아리 목록
	/**
	 * 동아리 목록
	 */
	private void m() {
		// 필요한 객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		System.out.println("============================");
		System.out.println("[동아리 목록]");
		System.out.println("============================");
		// 구현부
	      try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	    	  
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select *\r\n" + 
	         		"from  tblOpenStudyGroup osg";
	         rs = stat.executeQuery(sql);
	         
	         // select문 마지막행까지 반복
	         while(rs.next()) {
	            
	        
	            	System.out.print(rs.getString(1));
	            	System.out.print(". ");
	            	System.out.println(rs.getString(2));
	           	            
	         }
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
	}
}

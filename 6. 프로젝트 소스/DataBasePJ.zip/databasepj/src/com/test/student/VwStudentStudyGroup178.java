// 1. 나의 동아리 조회
package com.test.student;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
/**
 * 
 * @author 홍준표
 *
 */
public class VwStudentStudyGroup178 {
	/*
	 * 나의 동아리 조회 및 탈퇴
	 */
	static String r = "";
	public void vw() {
		
		String name = "";
		
		
		name = Student.id;
		
		System.out.println("----------------------------");
		System.out.printf("%s님의 동아리를 조회합니다.",name);
		System.out.println();
		System.out.println("----------------------------");
		System.out.println("학생번호\t이름\t동아리명\t\t가입상태");

		
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

	
		
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select * from vwStudentStudyGroup178 where 학생명 = " + "'"+name+ "'" ;
	         rs = stat.executeQuery(sql);
	         
	         // select문 마지막행까지 반복
	         while(rs.next()) {
	            
	        	System.out.print(rs.getString(1));
	        	r = rs.getString(1);
	        	System.out.print("\t");
	        	System.out.print(rs.getString(2));
	        	System.out.print("\t");
	        	System.out.print(rs.getString(3));
	        	System.out.print("\t");
	        	System.out.print(rs.getString(4));
	        	System.out.println();
	        
	         }
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	         System.out.println(e);
	         
	      }
		 System.out.println("----------------------------");
		 m2();
		
	}
/**
 * 동아리 탈퇴
 */
	private void m2() {
			Scanner scan = new Scanner(System.in);
		 System.out.println("1. 동아리 탈퇴");
		 System.out.println("2. 이전 화면");
		 System.out.println("----------------------------");
		 System.out.print("선택(번호) : ");
		 String input = scan.nextLine();
		 if(input.equals("1")) {	
			 // 동아리 탈퇴 구현
			 
			 Proc181 p = new Proc181();
			 p.pr();
		 }else if (input.equals("2")){
			
		 }else {
			 System.out.println("잘못 입력하셨습니다");
			 System.out.println("계속하시려면 엔터를 누르세요...");
			 String enter = scan.nextLine();
			 m2();
			 
		 }
	}
}

// 교육생 로그인

// 시연할때  id 노덕름 pw 1845122
package com.test.student;

import java.sql.CallableStatement;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Scanner;

import com.test.main.Main;

import oracle.jdbc.OracleTypes;


/**
 * 
 * @author 홍준표
 *
 */
public class Student {
	//id pw static 상수 선언 (여러 메소드에서 값이 필요해서)
	public static String id = "";
	public static String pw = "";
	public static int stu = 0;
	// 최초 로그인에 쓰이는 int 선언
	private static int fir = 0;
	
	// 출근에 쓰일 static 선언
	private static int chool = 0 ;
	
	
		// 필요한 객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		
	
	

	// 스캐너 선언
	Scanner scan = new Scanner(System.in);
	

	/**
	 * 로그인
	 */
	public void s(){
			
		
		// 출력문 및 id pw 입력받기
		System.out.println("----------------------------");
		System.out.print("아이디(교육생 이름) : ");
		id = scan.nextLine();
		System.out.print("비밀번호(주민번호 뒷자리) : ");
		pw = scan.nextLine();
		System.out.println("----------------------------");
	
		
		// (로그인)제어에 필요한 int 선언 및 초기화
		int control = 0;
		
		// 교육생 이름 저장에 필요한 String 선언 및 초기화
		String name = "";
		
		// 구현부
	      try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select student_name,substr(student_ssn,8,7),seq_student from tblstudent";
	         rs = stat.executeQuery(sql);
	         
	         // select문 마지막행까지 반복
	         while(rs.next()) {
	            
	        	 // select문의 id, pw와 입력받은 id pw가 일치할때 control 반환
	            if(rs.getString(1).equals(id) && rs.getString(2).equals(pw)) {
	            	control ++;
	            	name = rs.getString(1);
	            	stu=rs.getInt(3);
	            }	            
	         }
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
	      
	      
	      if(control == 0) {
	    	// 로그인 실패
	    	System.out.println("아이디 또는 비밀번호가 틀렸습니다.");
	    	System.out.println("계속 하시려면 엔터를 누르세요...");
	    	Scanner scan = new Scanner(System.in);
	    	String enter = scan.nextLine();
			Main ma = new Main();
			ma.m();
			
	      }else {
	    	// 로그인 성공
	    	  
	    	
	    	  System.out.printf("%s님 환영합니다 !",name);
	    	  System.out.println();
	    	 
	    	  System.out.println("----------------------------");
	    	  System.out.printf("[%s님의 회원정보]",name);
	    	  System.out.println();
	    	  StuMain();
	      }
	      
	      
	} // s
	/**
	 * 로그인 성공시
	 */
		// 로그인 성공시
		void StuMain() { 
		
		// 최초 로그인 성공시에만 로그인 정보 출력 메소드
		if(fir==0) {
		ok();
		};
		
		// 종료기능 및 로그아웃 구현을 위한 객체 생성
		Main ma = new Main();
	
		
		// 출력문 및 입력받기
		System.out.println("----------------------------");
		System.out.println("1. 성적 조회");
		System.out.println("2. 출결 기록(출근/퇴근)");
		System.out.println("3. 출결 조회");
		System.out.println("4. 동아리");
		System.out.println("5. 수강신청");
		System.out.println("6. 로그아웃");
		System.out.println("7. 종료");
		System.out.println("----------------------------");
		System.out.print("선택(번호) : ");
		String input = scan.nextLine(); 
		
		
		if(input.equals("1")) {
			// 1. 성적 조회
			m1();
			
		}else if(input.equals("2")) {
			// 2. 출결 관리 기록
			m2();
		}else if(input.equals("3")) {
			// 3. 출결 조회
			m3();
		}else if(input.equals("4")) {
			// 4. 동아리
			DongariOutput out = new DongariOutput();
			out.output();
			
		}else if(input.equals("5")) {
			// 5. 수강신청f
			sugang();
			
		
		}else if(input.equals("6")) {
			// 6. 로그아웃
			
			System.out.println("로그아웃 하겠습니다.");
			ma.m();
		}else if(input.equals("7")) {
			// 7. 종료
			System.out.println("----------------------------");
			System.out.println("종료 하겠습니다.");
			//ma.roof = false;
		}
			// 유효성 검사 
		else if(!input.equals("1")&&!input.equals("2")&&!input.equals("3")&&!input.equals("4")&&!input.equals("5")&&!input.equals("6")&&!input.equals("7")) {
			System.out.println("----------------------------");
			System.out.println("잘못 입력하셨습니다");
			System.out.println("1 ~ 6 사이의 숫자를 입력해주세요");
			System.out.println("계속 하시려면 엔터를 누르세요...");
			System.out.println("----------------------------");
			String enter = scan.nextLine();
			// 로그인 성공후 반복을 위한 객체 생성
			Student stu = new Student();
			stu.StuMain();
		} 
	}		
		/**
		 * 수강신청
		 */
			private void sugang() {
			// 수강 신청
				// 과정 목록 출력
				System.out.println("----------------------------");
			System.out.println("[수강신청 가능 목록]");
			System.out.println("----------------------------");
			System.out.println("[번호]\t[시작날짜]\t[끝날짜]\t[과정명]");
				
				// 필요한 객체 생성
				Connection conn = null;
				Statement stat = null;
				ResultSet rs = null;
				DBUtil util = new DBUtil();
				
				// 구현부
			      try {
			    	  // 3조 SQL 연결
				         conn = util.open("211.63.89.47","project","java1234");
			    	
			         stat = conn.createStatement();

			         // select문 삽입
			         String sql = "select c.seq_opencourse,c.course_start_date,c.course_finish_date,r.course_name from \r\n" + 
			         		"    tblOpenCourse c\r\n" + 
			         		"        inner join tblCourse r\r\n" + 
			         		"            on c.seq_course = r.seq_course order by c.seq_opencourse";
			         rs = stat.executeQuery(sql);
			         
			         String s = "";
			         String e = "";
			         // select문 마지막행까지 반복
			         while(rs.next()) {
			            System.out.print(rs.getString(1));
			            System.out.print(". ");
			            s= rs.getString(2).replace("00:00:00", "");
			            System.out.print(s);
			            System.out.print("\t");
			            e= rs.getString(3).replace("00:00:00", "");
			            System.out.print(e);
			            System.out.print("\t");
			            System.out.println(rs.getString(4));
			            
			            	  	            
			         }
			         
			         // 자원 닫기
			         stat.close();
			         conn.close();
			        
			         // 예외 처리
			      	} catch (Exception e) {
			         System.out.println("오류 발생");
			  
			      	}
			      System.out.println("----------------------------");
			System.out.print("수강 신청을 하시겠습니까?(y/n) : ");
			String su =  scan.nextLine();
			if (su.equals("y")) {
				
				//-------------------
				
				abc();
				
				//------------------------
			}else if(su.equals("n")) {
				Student st = new Student();
				st.StuMain();
			}else {
				System.out.println("잘못 입력하셨습니다");
				System.out.println("계속 하시려면 엔터를 누르세요...");
				String enter = scan.nextLine();
				Student st = new Student();
				st.StuMain();
			}
				
		}
/**
 * 수강 신청 입력받기
 */
			private void abc() {
				System.out.print("수강 신청을 할 번호를 입력해주세요 : ");
				String snum = scan.nextLine();
				
				try {
					int q = Integer.parseInt(snum);
					// 객체 생성
					Connection conn = null;
					CallableStatement stat = null;
					DBUtil util = new DBUtil();
					
					// 3조 연결
					conn = util.open("211.63.89.47","project","java1234");
					
					// 컬럼 수만큼 = ?
					String sql ="{call procsugang(?,?)}";
					stat = conn.prepareCall(sql);
					
			
					stat.setInt(1, stu);
					stat.setInt(2, q);
					// select 에서 Update
					stat.executeUpdate();
				
					
					// 자원 닫기
					stat.close();
					conn.close();
					System.out.println("----------------------------");
				System.out.println("수강신청이 완료되었습니다.");
				Student st = new Student();
				st.StuMain();
				//오류 발생
				} catch (Exception e) {
				
					System.out.println(e);
				}
				
				
			}

			// 출결 조회
			/**
			 * 출결 조회
			 */
			private void m3() {
				
				// 00:00:00 없애기
				String ddd = "";
				
				System.out.printf("%s님의 출결을 조회합니다.",id);
				System.out.println();
				System.out.println("----------------------------");
				System.out.println("날짜\t   상태");
				// 객체 생성
				Connection conn = null;
				CallableStatement stat = null;
				DBUtil util = new DBUtil();
				
				// 3조 연결
				conn = util.open("211.63.89.47","project","java1234");
				
				// 컬럼 수만큼 = ?
				String sql ="{call proc157(?,?,?)}";
				
				// 구현부 
				try {
					stat = conn.prepareCall(sql);
					
					// porc157의 where 절에 id, pw 값 넣음
					stat.setString(1, id);
					stat.setString(2, pw);
					
					
					
					// 커서 OutParameter로 가져오기
					stat.registerOutParameter(3, OracleTypes.CURSOR);
							
					// select 에서 Query
					stat.executeQuery();
					ResultSet rs = (ResultSet)stat.getObject(3);
					
					// rs 값이 있는동안 반복
					while (rs.next()) {
						
						ddd = rs.getString(1).replace("00:00:00", "");
						System.out.print(ddd);
						System.out.printf("%s\t",rs.getString(2));
					
						System.out.println();
						
					}
					System.out.println("\n");
					
					// 자원 닫기
					stat.close();
					conn.close();
					Student st = new Student();
					st.StuMain();
				//오류 발생
				} catch (Exception e) {
					System.out.println("출결 조회에서 오류");
					System.out.println(e);
				}
			
		}

			/**
			 * 출결 관리 기록(출근/퇴근)
			 */
			// 출결 관리 기록(출근/퇴근)
			private void m2() {
				chool++;
				
				// 출근(로그인후 최초 2번 선택시)
				
			if(chool==1) {
				System.out.printf("%s님 출근등록을 하시겠습니까?(y/n) : ",id);
				String start = scan.nextLine();
				if(start.equals("y")) {
				

					System.out.println("----------------------------");
					System.out.printf("%s님의 출근이 정상적으로 등록되었습니다.",id);
					System.out.println();
					System.out.println("계속 하시려면 엔터를 누르세요...");
					System.out.println("----------------------------");
					String enter =scan.nextLine();
					Student st = new Student();
					st.StuMain();
				}else if(start.equals("n")) {
					System.out.println("출근등록을 취소합니다");
					System.out.println("----------------------------");
					chool=0;
					System.out.println("계속 하시려면 엔터를 누르세요...");
					System.out.println("----------------------------");
					String enter =scan.nextLine();
					Student st = new Student();
					st.StuMain();
				}else {
					System.out.println("y 또는 n을 입력해주세요");
					System.out.println("계속 하시려면 엔터를 누르세요...");
					System.out.println("----------------------------");
					String enter =scan.nextLine();
					chool=0;
					m2();
					
				}
				// 퇴근(로그인후 두번째 2번 선택시
			}else if(chool ==2) {
					System.out.printf("%s님 퇴근등록을 하시겠습니까?(y/n) : ",id);
					String end = scan.nextLine();
					if(end.equals("y")) {
						System.out.println("----------------------------");
						System.out.printf("%s님의 퇴근이 정상적으로 등록되었습니다.",id);
						System.out.println();
						System.out.println("계속 하시려면 엔터를 누르세요...");
						System.out.println("----------------------------");
						
						
						chool++;
						//-------------------------------------------------
						
					
					
						
						
						
						// 구현부 
						try {
							
							// 객체 생성
							Connection conn = null;
							CallableStatement stat = null;
							DBUtil util = new DBUtil();
							
							// 3조 연결
							conn = util.open("211.63.89.47","project","java1234");
							
							// 컬럼 수만큼 = ?
							String sql ="{call proc156(?,?,?,?,?,?)}";
							stat = conn.prepareCall(sql);
							
							
						
							
							
							
							// porc156의 where 절에 id, pw 값 넣음
							Calendar c = Calendar.getInstance();
							
							String a = "20-06-";
							int b = c.get(Calendar.DATE);
							String e = "";
							e += b;
			
							String q = "";
							q += (a + e);
							
					
							
							
							
							stat.setString(1, q);
							stat.setString(2, "조퇴");
							stat.setString(3, id);
							stat.setString(4, pw);
							stat.setString(5, "12:00");
							stat.setString(6, "12:00");
							
							// select 에서 Update
							stat.executeUpdate();
						
							
							// 자원 닫기
							stat.close();
							conn.close();
							
						
						//오류 발생
						} catch (Exception e) {
							System.out.println("출결 관리 기록에서 오류");
							System.out.println(e);
						}
						
						
						//------------------------------------------------------
						
						String enter =scan.nextLine();
						Student st = new Student();
						st.StuMain();
					}else if(end.equals("n")) {
						System.out.println("퇴근등록을 취소합니다");
						System.out.println("----------------------------");
						chool=1;
						System.out.println("계속 하시려면 엔터를 누르세요...");
						System.out.println("----------------------------");
						String enter =scan.nextLine();
						Student st = new Student();
						st.StuMain();
					}else {
						System.out.println("y 또는 n을 입력해주세요");
						System.out.println("계속 하시려면 엔터를 누르세요...");
						System.out.println("----------------------------");
						String enter =scan.nextLine();
						
						m2();
				}
			}else if(chool >=2) {
				System.out.println("----------------------------");
				System.out.printf("%s님은 오늘 이미 출근/퇴근 기록을 하셨습니다.",id);
				System.out.println();
				System.out.println("계속 하시려면 엔터를 누르세요...");
				String t = scan.nextLine();
				
				Student st = new Student();
				st.StuMain();
			}

				
		}
/**
 * 교육생 기본 정보 출력
 */
			private void ok() {
				//line 151
				fir++;
				
				System.out.println("번호\t이름\t주민번호\t전화번호\t전공/비전공\t과정명\t\t\t\t\t\t과정시작 년월일\t과정끝 년월일\t강의실");
				// 객체 생성
				Connection conn = null;
				CallableStatement stat = null;
				DBUtil util = new DBUtil();
				
				// 3조 연결
				conn = util.open("211.63.89.47","project","java1234");
				
				// 컬럼 수만큼 = ?
				String sql ="{call proc151(?,?,?)}";
				
				
				
				// 구현부 
				try {
					stat = conn.prepareCall(sql);
					
					// 날짜부분 00:00:00 없애기 위해서 선언 및 초기화
					String startday = "";
					String endday = "";
					
					// porc151의 where 절에 id, pw 값 넣음
					stat.setString(1, id);
					stat.setString(2, pw);
					
					// 커서 OutParameter로 가져오기
					stat.registerOutParameter(3, OracleTypes.CURSOR);
							
					// select 에서 Query
					stat.executeQuery();
					ResultSet rs = (ResultSet)stat.getObject(3);
					
					// rs 값이 있는동안 반복
					while (rs.next()) {
						System.out.printf("%s\t",rs.getString(1));
						System.out.printf("%s\t",rs.getString(2));
						System.out.printf("%s\t",rs.getString(3));
						System.out.printf("%s\t",rs.getString(4));
						System.out.printf("%s\t\t",rs.getString(5));
						System.out.printf("%s\t",rs.getString(6));
						// 00:00:00 지우기
						startday = rs.getString(7).replace("00:00:00", "");
						System.out.print(startday);
						System.out.print("\t");
						// 00:00:00 지우기
						endday = rs.getString(8).replace("00:00:00", "");
						System.out.print(endday);
						System.out.print("\t");
						System.out.printf("%s\t",rs.getString(9));
						System.out.println();
					}
					
					
					// 자원 닫기
					stat.close();
					conn.close();
					
				
				//오류 발생
				} catch (Exception e) {
					System.out.println("최초 로그인에서 오류");
					System.out.println(e);
				}
				
			
		}

			// 성적 조회 line 153
			/**
			 * 성적 조회
			 */
		private void m1() {
			
			System.out.println("과목번호\t과목명\t과목기간\t교재명\t교사명\t출결배점"
					+ "\t필기배점\t실기배점\t출결점수\t필기점수\t실기점수\t시험날짜");
			
			// 객체 생성
			Connection conn = null;
			CallableStatement stat = null;
			DBUtil util = new DBUtil();
			String dday = "";
			// 3조 연결
			conn = util.open("211.63.89.47","project","java1234");
			
			// 컬럼 수만큼 = ?
			String sql ="{call proc153(?,?,?)}";
			
			// 구현부 
			try {
				stat = conn.prepareCall(sql);
				
				// porc153의 where 절에 id, pw 값 넣음
				stat.setString(1, id);
				stat.setString(2, pw);
				
				// 커서 OutParameter로 가져오기
				stat.registerOutParameter(3, OracleTypes.CURSOR);
						
				// select 에서 Query
				stat.executeQuery();
				ResultSet rs = (ResultSet)stat.getObject(3);
				
				// rs 값이 있는동안 반복
				while (rs.next()) {
					System.out.printf("%-2s\t",rs.getString(3));
					System.out.printf("%-3s\t",rs.getString(4));
					System.out.printf("%17s\t",rs.getString(5));
					System.out.printf("%s\t",rs.getString(6));
					System.out.printf("%s\t",rs.getString(7));
					System.out.printf("%s\t",rs.getString(8));
					System.out.printf("%s\t",rs.getString(9));
					System.out.printf("%s\t",rs.getString(10));
					System.out.printf("%s\t",rs.getString(11));
					System.out.printf("%s\t",rs.getString(12));
					System.out.printf("%s\t",rs.getString(13));
					// 00:00:00 지우기
					dday = rs.getString(14).replace("00:00:00", "");
					System.out.print(dday);
				
					System.out.println();
					
				}
				System.out.println("\n");
				
				// 자원 닫기
				stat.close();
				conn.close();
				
				Student st = new Student();
				st.StuMain();
			//오류 발생
			} catch (Exception e) {
				System.out.println("성적 조회에서 오류");
				System.out.println(e);
			}
			
			
		}
	
}// Student

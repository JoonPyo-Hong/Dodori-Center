package com.test.student;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
/**
 * 
 * @author 홍준표
 *
 */
public class Proc181 {
	/**
	 * 동아리 탈퇴 구현
	 */
	public void pr() {
		VwStudentStudyGroup178 vw = new VwStudentStudyGroup178();
		String o = "";
		o = vw.r;
		Student st = new Student();
		int a = st.stu;
		System.out.println(a);
		try {
			
			// 객체 생성
			Connection conn = null;
			CallableStatement stat = null;
			DBUtil util = new DBUtil();
			
			// 3조 연결
			conn = util.open("211.63.89.47","project","java1234");
			
			// 컬럼 수만큼 = ?
			String sql ="{call proc181(?)}";
			stat = conn.prepareCall(sql);
			
	
			stat.setInt(1, a);
			
		
			// select 에서 Update
			stat.executeUpdate();
		
			
			// 자원 닫기
			stat.close();
			conn.close();
			
		
		//오류 발생
		} catch (Exception e) {
		
			System.out.println(e);
		}
		System.out.println("----------------------------");
		System.out.println("동아리 탈퇴 신청이 되었습니다.");
	}
}

package com.test.student;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
/**
 * 
 * @author 홍준표
 *
 */
public class Proc175 {
	static HashMap<String, String> r = new HashMap();
	
	static int b = 0;
	/**
	 * 나의 동아리 스케줄 조회 및 참여응답
	 */
	public void pr() {
		Student st = new Student();
			String name = st.id;
			String ssn = st.pw;
			// 필요한 객체 생성
			Connection conn = null;
			Statement stat = null;
			ResultSet rs = null;
			DBUtil util = new DBUtil();
			String c = "";
			int a = 0;
			b= 0;
			
			
			
			Scanner scan = new Scanner(System.in);
			// 구현부
		      try {
		    	  // 3조 SQL 연결
			         conn = util.open("211.63.89.47","project","java1234");
		    	
		         stat = conn.createStatement();

		         // select문 삽입
		         String sql = "select * from vwstudygroupattendence175 where 학생명 = '" + name + "'";
		         rs = stat.executeQuery(sql);
		         
		         // select문 마지막행까지 반복
		         while(rs.next()) {
		        	 	
		        	 	if(a==0) {
		        	 		
				        System.out.println("----------------------------");
		        	 	System.out.print("동아리명 : ");
		            	System.out.print("[");
		            	System.out.print(rs.getString(2));
		            	System.out.println("]");
		            	System.out.print("[날짜]");
		            	System.out.print("\t");
		            	System.out.println("[참여여부]");
		        	 	}
		        	 	a++;
		        	 	
		        	 	String g = "";
		        	 	g += a;
		        	 	 
		        	 	
		        	 	 
		        	 	System.out.printf("%s.",g);
		        	 	c = rs.getString(3).replace("00:00:00", "");
		        	 	 r.put(g, c);
		            	System.out.print(c);
		            	
		            	System.out.print("\t");
		            	System.out.println(rs.getString(4));
		            	b++;
		         }
		         
		         
		         if(b<3) {
		        	 System.out.println("----------------------------");
		        	 System.out.printf("%s님은 가입완료된 동아리가 없습니다.",name);
		        	 System.out.println();
		        	 System.out.println("계속 하시려면 엔터를 누르세요...");
		        
		        	 String input = scan.nextLine();
		        	 DongariOutput out = new  DongariOutput();
					 out.output();
		         }else {
		        
		        	
		        	
		         }
		         
		         // 자원 닫기
		         stat.close();
		         conn.close();
		        
		         // 예외 처리
		      	} catch (Exception e) {
		         System.out.println("오류 발생");
		  
		      	}
			
			System.out.println("----------------------------");
			System.out.println("1. 동아리 스케줄 참여응답");
			System.out.println("2. 이전 화면");
			System.out.println("----------------------------");
			
			System.out.print("선택(번호) : ");
			String q = scan.nextLine();
			
			 
			
			if(q.equals("1")) {
				
					m();
		   
				
				
				
				
				
				
				
				
				Proc175 pr = new Proc175();
				pr.pr();
		      
			}else if(q.equals("2")) {
				 DongariOutput out = new  DongariOutput();
				 out.output();
			
			}else {
				System.out.println("1 ~ 2번 사이의 번호를 입력해주세요");
				System.out.println("계속하시려면 엔터를 누르세요...");
				String enter = scan.nextLine();
				Proc175 pr = new Proc175();
				pr.pr();
				
			}
	}
	/**
	 * 나의 동아리 스케줄 조회 및 참여응답 구현
	 */
	private void m() {
		
		System.out.print("참여 응답을 할 동아리 번호 : ");
		
		
		Scanner hhh = new Scanner(System.in);
		int input = hhh.nextInt();
		System.out.println("----------------------------");
		
		if(r.size()>=input&&input>0) {
			
			boolean loof = true;
			while (loof) {
			System.out.print("응답(참석/미참석) : ");
			Scanner scan = new Scanner(System.in);
			 String enser = scan.nextLine();
			 if(enser.equals("참석")||enser.equals("미참석")) {
			 
		
		// 객체 생성
				try {
					Connection conn = null;
					CallableStatement stat = null;
					DBUtil util = new DBUtil();
					
						
					
					// 3조 연결
					conn = util.open("211.63.89.47","project","java1234");
					
					// 컬럼 수만큼 = ?
					String sql ="{call proc182(?,?,?)}";
					stat = conn.prepareCall(sql);
					

			
					
					Student st = new Student();
					String name = st.id;
					
					String d = "";
					d +=  input;
					
					
					
					stat.setString(1,name);
					stat.setString(2,enser);
					stat.setString(3,r.get(d));
				
					
					
					stat.execute();
					// 자원 닫기
					stat.close();
					conn.close();
					System.out.println("참여응답이 완료되었습니다");
					DongariOutput out = new DongariOutput();
					out.output();
					
					}
				
				//오류 발생
				 catch (Exception e) {
				
					System.out.println(e);
			
				 }
				loof = false;
			 }else {
				 System.out.println("참석/미참석 으로 입력해주세요");
				 System.out.println("계속하시려면 엔터를 누르세요...");
				 
				 String enter = scan.nextLine();
			 }
			}
				 }else {
					 System.out.println("잘못된 값을 입력하셨습니다.");
					 System.out.println("계속하시려면 엔터를 누르세요...");
					 Scanner scan = new Scanner(System.in);
					 String enter = scan.nextLine();
					 Proc175 pr = new Proc175();
						pr.pr();
				 }
	}
}



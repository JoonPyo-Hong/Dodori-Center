package com.test.student;

import java.util.Scanner;

import com.test.main.Main;
/**
 * 
 * @author 홍준표
 *
 */
public class DongariOutput {
	/**
	 * 동아리 출력화면
	 */
	public void output() {
		
		boolean roof = true;
		
		while(roof) {
		
		System.out.println("----------------------------");
		System.out.println("1. 나의 동아리 조회 및 탈퇴");
		System.out.println("2. 동아리 신청");
		System.out.println("3. 나의 동아리 스케줄 조회 및 참여응답");
		System.out.println("4. 이전 화면");
		System.out.println("5. 로그아웃");
		System.out.println("6. 종료");
		System.out.println("----------------------------");
		System.out.print("선택(번호) : ");
		Scanner scan = new Scanner(System.in);
		
		String input = scan.nextLine();
		System.out.println("");
		
		if(input.equals("1")) {
			// 1. 나의 동아리 조회 및 삭제
			VwStudentStudyGroup178 v = new VwStudentStudyGroup178();
			v.vw();
			
		}else if(input.equals("2")) {
			// 2. 동아리 신청 
			Select172 se = new Select172();
			se.select();
		}else if(input.equals("3")){
			// 3. 나의 동아리 스케줄 조회 및 참여응답
			Proc175 pr = new Proc175();
			pr.pr();
			
		}else if(input.equals("4")) {
			// 4. 이전 화면
			 Student st = new Student();
			 st.StuMain();
		}else if(input.equals("5")) {
			// 5. 로그아웃
			System.out.println("로그아웃 하겠습니다.");
			Main ma = new Main();
			ma.m();
		}else if(input.equals("6")) {
			// 6. 종료
			System.out.println("종료 하겠습니다.");
			//프로시저
			//System.exit(1);
			
		}else {
			System.out.println("잘못 입력하셨습니다");
			System.out.println("1 ~ 6 번호를 입력해주세요");
			System.out.println("계속하시려면 엔터를 누르세요...");
			String enter = scan.nextLine();
		}
		
		
				
		}
		
	}
}

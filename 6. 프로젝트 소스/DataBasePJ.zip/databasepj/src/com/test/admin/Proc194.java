// 동아리 근태관리
package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import com.test.student.DBUtil;
/**
 * 
 * @author 홍준표
 *
 */
public class Proc194 {
	 ArrayList<String> a = new ArrayList<String>();
	Connection conn = null;
	Statement stat = null;
	ResultSet rs = null;
	DBUtil util = new DBUtil();
	Scanner scan = new Scanner(System.in);
	/**
	 * 동아리 근태관리 출력문
	 */
	public void pr() {
		
		 System.out.println("----------------------------");
		 System.out.println("1. 동아리 출석 조회(교육생)");
		 System.out.println("2. 동아리 출석 조회(동아리)");
		 System.out.println("3. 동아리 탈퇴처리");
		 System.out.println("4. 이전 화면");
		 System.out.println("----------------------------");
		 System.out.print("선택(번호): ");
		 String input = scan.nextLine();
		
		 if(input.equals("1")) {
			 m1();
		 }else if(input.equals("2")) {
			 m2();
		 }else if(input.equals("3")) {
			 m3();
		 }else if(input.equals("4")) {
			 DongariOutput o = new DongariOutput();
			 o.out();
		 }else {
			 System.out.println("잘못 입력하셨습니다.");
			 System.out.println("계속 하시려면 엔터를 누르세요...");
			 String enter = scan.nextLine();
			 Proc194 out = new Proc194();
			 out.pr();
		 }
		 
		 
		 
	}
	/**
	 * 동아리 탈퇴처리
	 */
	private void m3() {
	System.out.println("[동아리 활동 5번이상 참여하지않은 사람]");
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         
	         // select문 삽입
	         String sql = "select s.student_name,t.study_group_attendence_date, t.study_group_attendence_state from \r\n" + 
	         		"    tblStudent s inner join tblregistcourse r on s.seq_student = r.seq_student\r\n" + 
	         		"        inner join tblstudygroup g on g.seq_regist_course = r.seq_regist_course\r\n" + 
	         		"            inner join tblstudygroupattendence t on  t.seq_study_group = g.seq_study_group";
	         rs = stat.executeQuery(sql);
	         
	         // select문 마지막행까지 반복
	         int w = 0;
	       String y = "";
	       
	      
	         while(rs.next()) {
//	            if(!y.equals(rs.getString(1))){
//	            	
//	            }
	            
	        	 if(!rs.getString(1).equals(y)){
	        		w=0;
	        		 
	        	 }
	         
	        	 if(!rs.getString(3).equals("참석")) {
        			 w++;
        		 }
	            
	        	 if(w>=5) {
	        		 System.out.println(rs.getString(1));
	        		 w=0;
	        		 a.add(rs.getString(1));
	        	 }
	        	 
	        	 y = rs.getString(1);

	            
	       
	         
	         
	        	 
	         }

	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      	}
		 System.out.println("----------------------------");
		 System.out.print("해당 인원을 탈퇴처리 하시겠습니까?(y/n) :");
		 String qq = scan.nextLine();
		 if(qq.equals("y")) {
			 for(int i =0; i<a.size(); i++) {
					try {
						
						// 객체 생성
						Connection conn = null;
						CallableStatement stat = null;
						DBUtil util = new DBUtil();
						
						// 3조 연결
						conn = util.open("211.63.89.47","project","java1234");
						
						
						
						// 컬럼 수만큼 = ?
						String sql ="{call proc19005(?)}";
						stat = conn.prepareCall(sql);
						
						stat.setString(1,a.get(i));
						// select 에서 Update
						stat.executeUpdate();
					
						
						// 자원 닫기
						stat.close();
						conn.close();
						
					
					
					//오류 발생
					} catch (Exception e) {
					
						System.out.println(e);
					}
			 }
			 
			 System.out.println("탈퇴 처리가 완료 되었습니다.");
		 }else if(qq.equals("n")){
			 Proc194 out = new Proc194();
			 out.pr();
		 }
		 
		 Proc194 out = new Proc194();
		 out.pr();
		
		
	}
	/**
	 * 동아리 출석 조회(동아리)
	 */
	private void m2() {
		System.out.println("[동아리명]\t[교육생명]\t[날짜]\t[참석여부]");
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         
	         // select문 삽입
	         String sql = "select  distinct study_group_name, student_name,\r\n" + 
	         		"        sga.study_group_attendence_date , sga.study_group_attendence_state\r\n" + 
	         		"    from tblStudent s inner join tblregistcourse r on s.seq_student = r.seq_student\r\n" + 
	         		"	         		       inner join tblstudygroup g on g.seq_regist_course = r.seq_regist_course\r\n" + 
	         		"	         		           inner join tblStudyGroupSchedualAttend z on z.seq_study_group =g.seq_study_group\r\n" + 
	         		"                                inner join tblStudyGroupSchedual s on s.seq_study_group_schedual = z.seq_study_group_schedual\r\n" + 
	         		"                                    inner join tblOpenStudyGroup osg on osg.seq_open_study_group = g.seq_open_study_group\r\n" + 
	         		"                                        inner join tblStudyGroupAttendence sga on sga.seq_study_group = g.seq_study_group\r\n" + 
	         		"                                            order by study_group_name";
	         rs = stat.executeQuery(sql);
	         
	         // select문 마지막행까지 반복
	         
	       String y = "";
	       String q = "";
	         while(rs.next()) {
	            if(!y.equals(rs.getString(1))){
	            	System.out.println();
	            	System.out.print("[");
	            	System.out.print(rs.getString(1));
	            	System.out.println("]");
	            	System.out.println();
	            	
	            	
	            
	            }
	            if(!q.equals(rs.getString(2))) {
	            	System.out.print(rs.getString(2));
	            	System.out.println();
	            }
	        	 y = rs.getString(1);
	        	 q = rs.getString(2);
	            
	         System.out.print("\t");
	         String p = "";
	         p = rs.getString(3).replace("00:00:00", "");
	         System.out.print(p);
	         System.out.print("\t");
	         System.out.println(rs.getString(4));
	         
	         
	        	 
	         }

	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      	}
		 Proc194 out = new Proc194();
		 out.pr();
	}
	/**
	 * 동아리 출석조회(교육생)
	 */
	private void m1() {
		System.out.println("[교육생명]\t[날짜]\t[참석여부]");
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         System.out.println("[번호\t 날짜\t 장소\t 최대인원]");
	         // select문 삽입
	         String sql = "select s.student_name,t.study_group_attendence_date, t.study_group_attendence_state from \r\n" + 
	         		"    tblStudent s inner join tblregistcourse r on s.seq_student = r.seq_student\r\n" + 
	         		"        inner join tblstudygroup g on g.seq_regist_course = r.seq_regist_course\r\n" + 
	         		"            inner join tblstudygroupattendence t on  t.seq_study_group = g.seq_study_group";
	         rs = stat.executeQuery(sql);
	         
	         // select문 마지막행까지 반복
	         
	       String y = "";
	         while(rs.next()) {
	            if(!y.equals(rs.getString(1))){
	            	System.out.println();
	            	System.out.print("[");
	            	System.out.print(rs.getString(1));
	            	System.out.println("]");
	            }
	        	 y = rs.getString(1);

	            
	         System.out.print("\t");
	         String p = "";
	         p = rs.getString(2).replace("00:00:00", "");
	         System.out.print(p);
	         System.out.print("\t");
	         System.out.println(rs.getString(3));
	         
	         
	        	 
	         }

	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      	}
		 Proc194 out = new Proc194();
		 out.pr();
		
	}
}

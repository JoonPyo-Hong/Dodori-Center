// 관리자 메뉴 -> 동아리  메뉴 선택시
package com.test.admin;

import java.util.Scanner;

import com.test.main.Main;
/**
 * 
 * @author 홍준표
 *
 */
public class DongariOutput {
	/**
	 * 동아리 메인화면입니다.
	 */
	public void out() {
		
			//스캐너 선언
		Scanner scan = new Scanner(System.in);
		
		
			//출력문
		 System.out.println("\t\t\t\t================================");
		 System.out.println("\t\t\t\t1. 동아리 통합 관리");
		 System.out.println("\t\t\t\t2. 동아리 가입 관리");
		 System.out.println("\t\t\t\t3. 동아리 스케줄 관리");
		 System.out.println("\t\t\t\t4. 동아리 교육생 근태관리");
		 System.out.println("\t\t\t\t5. 동아리별 취업률");
		 System.out.println("\t\t\t\t6. 로그아웃");
		 System.out.println("\t\t\t\t7. 종료");
		 System.out.println("\t\t\t\t================================");
		 System.out.print("\t\t\t\t선택(번호): ");
		 String input = scan.nextLine();
		 
		 if(input.equals("1")) {
			 // 동아리 통합관리
			 Proc190 pr = new Proc190();
			 pr.qq();
		 }else if(input.equals("2")) {
			 // 동아리 가입관리
			 Proc191 pr = new Proc191();
			 pr.pr();
		 }else if(input.equals("3")) {
			 // 동아리 스케줄 관리
			 Proc193 pr = new Proc193();
			 pr.pr();
		 }else if(input.equals("4")) {
			 // 동아리 교육생 근태관리
			 Proc194 pr = new Proc194();
			 pr.pr();
		 }else if(input.equals("5")) {
			 // 동아리별 취업률
			 Dopyo d = new Dopyo();
			 d.dopyo();
		 }else if(input.equals("6")) {
			 // 로그아웃
			 System.out.println("\t\t\t\t로그아웃 하겠습니다.");
			 Main ma = new Main();
			 ma.m();
		 }else if(input.equals("7")) {
			 // 종료 
			 System.out.println("\t\t\t\t================================");
			 System.out.println("\t\t\t\t종료 하겠습니다.");
			 System.out.println("\t\t\t\t================================");
			 while(true){
				 // (약식으로 구현됨 시연하지말것)
			 }
		 }else {
			 // 유효성
			 System.out.println();
			 System.out.println("\t\t\t\t================================");
			 System.out.println("\t\t\t\t잘못 입력하셨습니다.");
			 System.out.println("\t\t\t\t계속 하시려면 엔터를 누르세요...");
			 System.out.println("\t\t\t\t================================");
			 String enter = scan.nextLine();
			 DongariOutput out = new DongariOutput();
			 out.out();
		 }
		 
 
	}
	
	
}

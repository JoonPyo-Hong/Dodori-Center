// 1. 동아리 통합관리
package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.test.main.Main;
import com.test.student.DBUtil;
/**
 * 
 * @author 홍준표
 *
 */
public class Proc190 {
	// 필요한 객체 생성
	Connection conn = null;
	Statement stat = null;
	ResultSet rs = null;
	DBUtil util = new DBUtil();
	Scanner scan = new Scanner(System.in);
	/**
	 * 통합관리 출력문
	 */
	public void qq() {
		// 통합관리 메인
		//출력문
		
		 System.out.println("\t\t\t\t================================");
		 System.out.println("\t\t\t\t1. 동아리 조회");
		 System.out.println("\t\t\t\t2. 동아리 추가");
		 System.out.println("\t\t\t\t3. 동아리 수정");
		 System.out.println("\t\t\t\t4. 동아리 삭제");
		 System.out.println("\t\t\t\t5. 동아리 가입기준");
		 System.out.println("\t\t\t\t6. 이전 화면");
		 System.out.println("\t\t\t\t================================");
		 System.out.print("\t\t\t\t선택(번호): ");
		 String input = scan.nextLine();
		 
			
		 if(input.equals("1")) {
			 // 동아리 조회
			 try {
				 
				 
		    	  // 3조 SQL 연결
		         conn = util.open("211.63.89.47","project","java1234");
		         stat = conn.createStatement();
		         System.out.println("\t\t\t\t[동아리 조회]");
		         // select문 삽입
		         String sql = "select * from tblOpenStudyGroup";
		         rs = stat.executeQuery(sql);
		         
		         // select문 마지막행까지 반복
		         
		       
		         while(rs.next()) {
		        	 System.out.print("\t\t\t\t");
		           System.out.print(rs.getString(1));
		           System.out.print(". ");
		      
		           System.out.println(rs.getString(2));
		        	 
		         }

		         
		         // 자원 닫기
		         stat.close();
		         conn.close();
		        
		         // 예외 처리
		      	} catch (Exception e) {
		         System.out.println("오류 발생");
		      }
			 Proc190 pr = new Proc190();
			 pr.qq();
		 }else if(input.equals("2")) {
			 
			 try {
				 
				 	System.out.println();
				 	System.out.println("\t\t\t\t================================");
					System.out.print("\t\t\t\t동아리 이름을 입력해주세요 : ");
					String m = scan.nextLine();
					
					// 객체 생성
					Connection conn = null;
					CallableStatement stat = null;
					DBUtil util = new DBUtil();
					
					// 3조 연결
					conn = util.open("211.63.89.47","project","java1234");
					
					
					
					// 컬럼 수만큼 = ?
					String sql ="{call proc2001(?)}";
					stat = conn.prepareCall(sql);
					
					stat.setString(1,m);
					// select 에서 Update
					stat.executeUpdate();
				
					
					// 자원 닫기
					stat.close();
					conn.close();
					
				
				
				//오류 발생
				} catch (Exception e) {
				
					System.out.println(e);
				}
			 System.out.println("\t\t\t\t동아리가 추가되었습니다!");
			 Proc190 pr = new Proc190();
			 pr.qq();
		 }else if(input.equals("3")) {
			 // 동아리 수정
			 
			 try {
		    	  // 3조 SQL 연결
		         conn = util.open("211.63.89.47","project","java1234");
		         stat = conn.createStatement();
		         
		         // select문 삽입
		         String sql = "select * from tblOpenStudyGroup";
		         rs = stat.executeQuery(sql);
		         
		         // select문 마지막행까지 반복
		         
		       
		         while(rs.next()) {
		           System.out.print(rs.getString(1));
		           System.out.print(". ");
		      
		           System.out.println(rs.getString(2));
		        	 
		         }

		         
		         // 자원 닫기
		         stat.close();
		         conn.close();
		        
		         // 예외 처리
		      	} catch (Exception e) {
		         System.out.println("오류 발생");
		      }
			 
			 
			 try {
				 	Scanner e = new Scanner(System.in);
				 	
				 	
				 	System.out.print("\t\t\t\t수정할 동아리 번호(선택) : ");
				 	int t = e.nextInt();
					System.out.print("\t\t\t\t수정할 동아리 이름을 입력해주세요 : ");
					String m = scan.nextLine();
					// 객체 생성
					Connection conn = null;
					CallableStatement stat = null;
					DBUtil util = new DBUtil();
					
					// 3조 연결
					conn = util.open("211.63.89.47","project","java1234");
					
					
					
					// 컬럼 수만큼 = ?
					String sql ="{call proc2002(?,?)}";
					stat = conn.prepareCall(sql);
					
					stat.setString(1,m);
					stat.setInt(2,t);
					// select 에서 Update
					stat.executeUpdate();
				
					
					// 자원 닫기
					stat.close();
					conn.close();
					
				
				
				//오류 발생
				} catch (Exception e) {
				
					System.out.println(e);
				}
			 System.out.println("\t\t\t\t================================");
			 System.out.println("\t\t\t\t동아리가 수정되었습니다!");
			 System.out.println("\t\t\t\t================================");
			 
			 Proc190 pr = new Proc190();
			 pr.qq();
		 }else if(input.equals("4")) {
			 // 동아리 삭제
			 
			 try {
		    	  // 3조 SQL 연결
		         conn = util.open("211.63.89.47","project","java1234");
		         stat = conn.createStatement();
		         
		         // select문 삽입
		         String sql = "select * from tblOpenStudyGroup";
		         rs = stat.executeQuery(sql);
		         
		         // select문 마지막행까지 반복
		         
		       
		         while(rs.next()) {
		        	
		        	 
		        	 System.out.println("\t\t\t\t");
		        	 System.out.print(rs.getString(1));
		        	 System.out.print(". ");
		      
		        	 System.out.println(rs.getString(2));
		        	 
		         }

		         
		         // 자원 닫기
		         stat.close();
		         conn.close();
		        
		         // 예외 처리
		      	} catch (Exception e) {
		         System.out.println("오류 발생");
		      }
			 
			 
			 try {
				 	Scanner e = new Scanner(System.in);
				 	
				 	System.out.print("\t\t\t\t삭제할 동아리 번호(선택) : ");
				 	int t = e.nextInt();
				
					// 객체 생성
					Connection conn = null;
					CallableStatement stat = null;
					DBUtil util = new DBUtil();
					
					// 3조 연결
					conn = util.open("211.63.89.47","project","java1234");
					
					
					
					// 컬럼 수만큼 = ?
					String sql ="{call proc2003(?)}";
					stat = conn.prepareCall(sql);
					
					
					stat.setInt(1,t);
					// select 에서 Update
					stat.executeUpdate();
				
					
					// 자원 닫기
					stat.close();
					conn.close();
					
				
				
				//오류 발생
				} catch (Exception e) {
				
					System.out.println(e);
				}
			 System.out.println("\t\t\t\t================================");
			 System.out.println("\t\t\t\t동아리가 삭제되었습니다!");
			 System.out.println("\t\t\t\t================================");
			 
			 Proc190 pr = new Proc190();
			 pr.qq();
		 }else if(input.equals("5")) {
			 // 동아리 가입기준
			 
			Proc190 pr = new Proc190();
			pr.pr();
		 }else if(input.equals("6")) {
			 // 이전 화면
			 
			 
			 DongariOutput out = new DongariOutput();
			 out.out();
		 }else {
			 // 유효성
			 System.out.println("\t\t\t\t================================");
			 System.out.println("\t\t\t\t잘못 입력하셨습니다.");
			 System.out.println("\t\t\t\t계속 하시려면 엔터를 누르세요...");
			 String enter = scan.nextLine();
			 System.out.println("\t\t\t\t================================");
			 Proc190 out = new Proc190();
			 out.qq();
			 }
		
		}
		
	
	/**
	 * 동아리 가입기준 출력문
	 */
	
	public void pr() {
		
		
		
		
		
		//출력문
	 System.out.println("\t\t\t\t================================");
	 System.out.println("\t\t\t\t1. 동아리 가입기준 조회");
	 System.out.println("\t\t\t\t2. 동아리 가입기준 입력");
	 System.out.println("\t\t\t\t3. 동아리 가입기준 수정");
	 System.out.println("\t\t\t\t4. 동아리 가입기준 삭제");
	 System.out.println("\t\t\t\t5. 이전 화면");
	 System.out.println("\t\t\t\t================================");
	 System.out.print("\t\t\t\t선택(번호): ");
	 String input = scan.nextLine();
	 
	 // 동아리 목록 보여주는 메소드
	 //m5();
		
	 if(input.equals("1")) {
		 // 동아리 가입기준 조회
		 m1();
	 }else if(input.equals("2")) {
		 // 동아리 가입기준 입력
		 m5();
		 m2();
	 }else if(input.equals("3")) {
		 // 동아리 가입기준 수정
		 m6();
		 m3();
	 }else if(input.equals("4")) {
		 // 동아리 가입기준 삭제
		 m6();
		 m4();
	 }else if(input.equals("5")) {
		 // 이전 화면
		 Proc190 out = new Proc190();
		 out.qq
		 ();
	 }else {
		 // 유효성
		 System.out.println("\t\t\t\t================================");
		 System.out.println("\t\t\t\t잘못 입력하셨습니다.");
		 System.out.println("\t\t\t\t계속 하시려면 엔터를 누르세요...");
		 String enter = scan.nextLine();
		 System.out.println("\t\t\t\t================================");
		 Proc190 out = new Proc190();
		 out.pr();
		 }
		
	}
	/**
	 * 동아리명/가입기준 출력문
	 */
	private void m6() {
		// 구현부
	      try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select b.study_group_name,a.study_standard, a.seq_study_standard  from tblStudyStandard a inner join tblOpenStudyGroup b on a.seq_open_study_group = b.seq_open_study_group";
	         rs = stat.executeQuery(sql);
	         System.out.println("■동아리명/가입기준■");
	         // select문 마지막행까지 반복
	         
	         String q ="";
	         while(rs.next()) {
	           
	        	if(!rs.getString(1).equals(q)) { 
	        		System.out.println();
	        		System.out.print("[");
		        	System.out.print(rs.getString(1));
		        	System.out.println("]");
		        	
	        	}
	        	System.out.print(rs.getString(3));
	        	System.out.print(". ");
	        	System.out.println(rs.getString(2));
	        	q =rs.getString(1); 
	         }

	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
		
	}


/*
 * 동아리 목록
 */

	private void m5() {
		// 동아리 목록
		
		System.out.println("[동아리 목록]");
		// 구현부
	      try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select * from tblOpenStudyGroup";
	         rs = stat.executeQuery(sql);
	        
	         // select문 마지막행까지 반복
	         
	        
	         while(rs.next()) {
	           
	        	
	      
		        System.out.print(rs.getString(1));
		        System.out.print("\t");	
		        
	        
	        	System.out.println(rs.getString(2));
	        	
	         }

	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println(e);
	      }
	}



/**
 * 동아리 삭제
 */
	private void m4() {
		// 동아리 삭제
		
		System.out.print("\t\t\t\t가입기준을 삭제할 번호 : ");
		String num = scan.nextLine();
		
		
		
		// 구현부
try {
			
			// 객체 생성
			Connection conn = null;
			CallableStatement stat = null;
			DBUtil util = new DBUtil();
			
			// 3조 연결
			conn = util.open("211.63.89.47","project","java1234");
			
			// 컬럼 수만큼 = ?
			String sql ="{call proc190_delete(?)}";
			stat = conn.prepareCall(sql);
			
			int z = Integer.parseInt(num);
			
			
			stat.setInt(1,z);
			// select 에서 Update
			stat.executeUpdate();
		
			
			// 자원 닫기
			stat.close();
			conn.close();
		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t동아리 가입기준 삭제가 완료되었습니다.");
		System.out.println("\t\t\t\t================================");
		
		//오류 발생
		} catch (Exception e) {
		
			System.out.println(e);
		}
		Proc190 pr = new Proc190();
		pr.pr();
	
	}
	/**
	 * 동아리 수정
	 */
	private void m3() {
		// 동아리 수정
		
		System.out.print("\t\t\t\t가입기준을 수정할 번호 : ");
		String num = scan.nextLine();
		
		
		System.out.print("\t\t\t\t수정할 가입기준 : ");
		String n = scan.nextLine();
		// 구현부
try {
			
			// 객체 생성
			Connection conn = null;
			CallableStatement stat = null;
			DBUtil util = new DBUtil();
			
			// 3조 연결
			conn = util.open("211.63.89.47","project","java1234");
			
			// 컬럼 수만큼 = ?
			String sql ="{call proc190_update_standard(?,?)}";
			stat = conn.prepareCall(sql);
			
			int z = Integer.parseInt(num);
			
			stat.setString(2, n);
			stat.setInt(1,z);
			// select 에서 Update
			stat.executeUpdate();
		
			
			// 자원 닫기
			stat.close();
			conn.close();
			
			System.out.println("\t\t\t\t================================");	
		System.out.println("\t\t\t\t동아리 가입기준 수정이 완료되었습니다.");
		System.out.println("\t\t\t\t================================");
		
		//오류 발생
		} catch (Exception e) {
		
			System.out.println(e);
		}
		Proc190 pr = new Proc190();
		pr.pr();
		
	}

	/**
	 * 동아리 가입기준 입력
	 */
	private void m2() {
		// 동아리 가입기준 입력
		
		System.out.print("\t\t\t\t가입기준을 추가할 번호 : ");
		String num = scan.nextLine();
		
		
		System.out.print("\t\t\t\t추가할 가입기준 : ");
		String n = scan.nextLine();
		// 구현부
try {
			
			// 객체 생성
			Connection conn = null;
			CallableStatement stat = null;
			DBUtil util = new DBUtil();
			
			// 3조 연결
			conn = util.open("211.63.89.47","project","java1234");
			
			// 컬럼 수만큼 = ?
			String sql ="{call proc190_insert(?,?)}";
			stat = conn.prepareCall(sql);
			
			int z = Integer.parseInt(num);
			
			stat.setString(1, n);
			stat.setInt(2,z);
			// select 에서 Update
			stat.executeUpdate();
		
			
			// 자원 닫기
			stat.close();
			conn.close();
			
		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t동아리 가입기준 입력이 완료되었습니다.");
		System.out.println("\t\t\t\t================================");
		
		//오류 발생
		} catch (Exception e) {
		
			System.out.println(e);
		}
		Proc190 pr = new Proc190();
		pr.pr();
	}
/*
 *  동아리 조회
 */
	private void m1() {
		// 동아리 조회
		
		// 구현부
	      try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select b.study_group_name,a.study_standard from tblStudyStandard a inner join tblOpenStudyGroup b on a.seq_open_study_group = b.seq_open_study_group";
	         rs = stat.executeQuery(sql);
	         System.out.println("■동아리명/가입기준■");
	         // select문 마지막행까지 반복
	         
	         String q ="";
	         while(rs.next()) {
	           
	        	if(!rs.getString(1).equals(q)) { 
	        		System.out.println();
	        		System.out.print("[");
		        	System.out.print(rs.getString(1));
		        	System.out.println("]");
		        	
	        	}
	        	System.out.println(rs.getString(2));
	        	q =rs.getString(1); 
	         }

	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
	      Proc190 pr = new Proc190();
	      pr.pr();
		
	}
}

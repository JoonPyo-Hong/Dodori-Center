package com.test.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

//import com.test.main.DBUtil;


/**
 * 
 * @author lllss
 * 
 */


public class Score {

	Scanner scan = new Scanner(System.in);

	/**
	 * 성적조회 메뉴
	 * 
	 */
	public void scoreAdmin() {

		boolean roof = true;

		while (roof) {
			System.out.println("============================");
			System.out.println("1. 시험 및 성적 등록여부 조회");
			System.out.println("2. 과목별 성적조회");
			System.out.println("3. 교육생별 성적조회");
			System.out.println("4. 이전화면");
			System.out.println("============================");
			System.out.print("선택(번호) : ");
			String input = scan.nextLine();
			System.out.println("============================");
			System.out.println();

			// 시험, 성적 등록여부 조회
			if (input.equals("1")) {
				printOpenCourse();// 전체 개설과정출력
				testScoreRegistCheck();

				// 과정별 성적조회
			} else if (input.equals("2")) {
				scoreCheckSubject();

				// 교육생별 성적조회
			} else if (input.equals("3")) {
				scoreCheckStudent();

				// 이전화면
			} else if (input.equals("4")) {
//				ManagerLogin m = new ManagerLogin();
//				m.printManagerMenu();
				break;

			}

			else {
				System.out.println("잘못입력하셨습니다.");
				System.out.println("번호를 다시 입력해주세요.");
				System.out.println("계속하시려면 엔터를 누르세요.");
				String enter = scan.nextLine();

			}

		}

	}

	/**
	 * 성적등록여부 출력
	 */
	// vwtestScoreRegistCheck95
	// 성적등록여부 출력
	public void testScoreRegistCheck() {
		// 연결객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {
			// 연결
			conn = util.open();
			// conn = util.open("", "project", "java1234");
			stat = conn.createStatement();
			// 특정과정 선택
			System.out.println("============================");
			System.out.print("개설과정선택(번호) : ");
			String input = scan.nextLine();
			System.out.println("============================");

			// String sql = String.format("select * from vwtestScoreRegistCheck95 where
			// 개설과정번호 = %s", input);
			// 과정별 개설과목 출력
			String sql = String.format("select distinct 개설과목명 from vwtestScoreRegistCheck95 where 개설과정번호 = %s", input);
			rs = stat.executeQuery(sql);

			System.out.println("[번호][개설과목명]");
			int cnt = 0;
			while (rs.next()) {
				cnt++;
				System.out.printf("%d %s\r\n", cnt,rs.getString("개설과목명"));
				System.out.println();
			}
			
			
			
			
			
//
//			System.out.printf("%s\t ", rs.getString("개설과정명"));
//			System.out.printf("%s\t ", rs.getString("개설과정번호"));
//			System.out.printf("%s\t ", rs.getString("학생명"));
//			System.out.printf("%s\t ", rs.getString("필기성적 등록여부"));
//			System.out.printf("%s\t\r\n ", rs.getString("실기성적 등록여부"));
//			
			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 전체 개설과정 목록 출력
	 * 
	 */
	// vwOpenCourse95
	// 전체 개설과정 목록 출력메소드
	public void printOpenCourse() {

		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			// conn = util.open("", "project", "java1234");
			stat = conn.createStatement();
			// 전체 개설과정을 출력
			String sql = "select * from vwOpenCourse95";
			rs = stat.executeQuery(sql);
			System.out.println("[개설과정번호]\t[과정시작일]\t[과정종료일]\t[개설과정명]");
			// 출력
			while (rs.next()) {
				System.out.printf("%s\t\t ", rs.getString("개설과정번호"));
				System.out.printf("%s\t ", rs.getString("과정시작일"));
				System.out.printf("%s\t ", rs.getString("과정종료일"));
				System.out.printf("%s\t\r\n ", rs.getString("개설과정명"));
			}

			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();

		}

	}
	/**
	 * 
	 * 교육생별 성적조회
	 * 
	 */
	// vwScoreSubject97
	public void scoreCheckStudent() {

		// 연결객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {
			// 연결
			conn = util.open();
			// conn = util.open("", "project", "java1234");
			stat = conn.createStatement();

			// 입력받을 학생번호 입력
			System.out.print("학생번호 : ");
			String studentNum = scan.nextLine();

			// 실행할 쿼리
			String sql = String.format("select * from vwScoreSubject97 where 교육생번호 = %s", studentNum);

			// 쿼리 실행해서 result에 넣기
			rs = stat.executeQuery(sql);

			System.out.println(
					"[개설 과정명] \t\t\t\t [과정시작일]\t [과정종료일] \t [강의실명] [교사명]\t [교육생명] [주민번호 뒷자리]\t [필기점수] [실기점수]\t[개설 과목명]\t\t[교재명] ");

			// 출력

			while (rs.next()) {

				System.out.printf("%s\t ", rs.getString("개설과정명"));
				System.out.printf("%s\t ", rs.getString("과정시작일"));
				System.out.printf("%s\t ", rs.getString("과정종료일"));
				System.out.printf("%s\t ", rs.getString("강의실명"));
				System.out.printf("   %s\t", rs.getString("교사명"));
				System.out.printf("   %s\t     ", rs.getString("교육생명"));
				System.out.printf("%s\t      ", rs.getString("주민번호 뒷자리"));
				System.out.printf("%s    ", rs.getString("필기점수"));
				System.out.printf("%s\t ", rs.getString("실기점수"));
				System.out.printf("%s\t ", rs.getString("개설과목명"));
				System.out.printf("%s\t\r\n", rs.getString("교재명"));

			}

			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 과목별 성적조회
	 */
	// vwScoreSubject97

	// 과목별 성적출력
	public void scoreCheckSubject() {

		// 연결 객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		DBUtil util = new DBUtil();

		try {
			// 연결
			conn = util.open();
			// conn = util.open("", "project", "java1234");
			stat = conn.createStatement();
			//과목 전체 출력 쿼리
			String sql2 = String.format("select * from tblSubject");
			rs2 = stat.executeQuery(sql2);
			System.out.println("[과목번호]\t[과목명]");
			while(rs2.next()) {
				System.out.print(rs2.getString(1)+"    ");
				System.out.print(rs2.getString(2)+"\r\n");

			}
			
			// 입력받을 과목번호를 입력
			System.out.print("개설과목번호 : ");
			String subject = scan.nextLine();
			
			// 가져올 쿼리
			String sql = String.format("select * from vwScoreSubject97 where 과목번호 = %s", subject);

			// 쿼리 실행해서 result에 넣기
			rs = stat.executeQuery(sql);

			System.out.println(
					"[과정시작일]\t [과정종료일] \t [강의실명] \t [개설 과목명]\t [교사명]\t [교재명]\t [교육생명]\t [주민번호 뒷자리]\t [필기점수][실기점수][개설 과정명] ");

			// 출력
			while (rs.next()) {

				System.out.printf("%s\t ", rs.getString("과정시작일"));
				System.out.printf("%s\t ", rs.getString("과정종료일"));
				System.out.printf("%s\t ", rs.getString("강의실명"));
				System.out.printf("%s\t ", rs.getString("개설과목명"));
				System.out.printf("%s\t ", rs.getString("교사명"));
				System.out.printf("%s\t ", rs.getString("교재명"));
				System.out.printf("%s\t ", rs.getString("교육생명"));
				System.out.printf("%s\t ", rs.getString("주민번호 뒷자리"));
				System.out.printf("%s\t ", rs.getString("필기점수"));
				System.out.printf("%s\t ", rs.getString("실기점수"));
				System.out.printf("%s\t\r\n ", rs.getString("개설과정명"));

			}
			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

	}

}

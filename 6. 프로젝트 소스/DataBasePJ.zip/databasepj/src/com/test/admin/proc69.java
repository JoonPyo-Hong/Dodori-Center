package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

/**
 * 
 * @author 강혜림
 *
 */
//개설 과정 관리
public class proc69 {

	
	// 필요한 객체 생성
	static Connection conn = null;
	static Statement stat = null;
	static ResultSet rs = null;
	static DBUtil util = new DBUtil();
	
	
	/**
	 * 개설과정 메뉴의 서브메뉴 출력
	 */
	public static void openCourseMain() {
		Scanner scan = new Scanner(System.in);
		System.out.println("               [개설과정 관리]             ");
		System.out.println("----------------------------------------");
		System.out.println("1. 개설 과정 정보 입력");
		System.out.println("2. 개설 과정 정보 출력");
		System.out.println("3. 개설 과정 정보 수정");
		System.out.println("4. 개설 과정 정보 삭제");
		System.out.println("5. 뒤로 가기");
		System.out.println("----------------------------------------");
		System.out.print("번호 : ");
		int num = scan.nextInt();
		
		switch(num) {
		//입력
		case 1:
			insert();
			break;
		//출력	
		case 2:
			m1();
			break;
		//수정
		case 3:
			m3();
			break;
		//삭제
		case 4:
			m4();
			break;
		//뒤로 가기
		case 5:
			ManagerLogin m1 = new ManagerLogin();
	    	m1.printManagerMenu();
	    	break;
		}
		
	}

	/**
	 * 개설과정 정보입력
	 */
	private static void insert() {
		String coursename = "";
		Scanner scan = new Scanner(System.in);
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement(); 
	         
	         
	         //과정명 기초데이터 출력
	         String sql = "select * from vw73";
	         rs = stat.executeQuery(sql);
	         
	         int cnt = 0;
	         System.out.println("[번호]\t\t[개설과정명]");
	         while(rs.next()) {
		        	
	        	 cnt++;
	  
	        	 System.out.print(cnt + "\t");
	        	 System.out.print(rs.getString(1));
	        	 System.out.println("\n");
	         }
	         
	         System.out.println("----------------------------------------");
	         System.out.print("추가할 개설 과정번호 입력 : ");
	         int course = scan.nextInt();
	         System.out.println("----------------------------------------");
	         System.out.print("추가할 개설 과정 시작날짜 입력 : ");
	         String start = scan.next();
	         System.out.print("추가할 개설 과정 종료날짜 입력 : ");
	         String finish = scan.next();
	         System.out.println("----------------------------------------");
	         
	         
	         // 강의실명 기초데이터 출력
	         sql = "select * from tblClassroom order by seq_classroom";
	         rs = stat.executeQuery(sql);
	         
	         System.out.println("[번호]\t\t[강의실명]");
	         while(rs.next()) {
		     
	        	 System.out.print(rs.getString(1));
	        	 System.out.print("\t");
	        	 System.out.print(rs.getString(2));
	        	 System.out.println("\n");
	         }
	         System.out.println("----------------------------------------");
	         System.out.print("추가할 강의실명 입력 : ");
	         String room = scan.next();
	         System.out.println("----------------------------------------");
	         
	       
	         
	         //proc76_insert에 값 넣기
	         CallableStatement stat2 = null;	
	         String sql2 = "{call proc76_insert(?,?,?,?)}";
        	 stat2 = conn.prepareCall(sql2);
        	 
        	 stat2.setInt(1, course);
        	 stat2.setString(2, start);
        	 stat2.setString(3, finish);
        	 stat2.setString(4, room);
        	 
        	 stat2.executeUpdate();
	         
        	 
        	 System.out.println("----------------------------------------");
        	 System.out.println("개설과정 정보 입력이 완료되었습니다.");
        	 System.out.println("개설과정의 개설과목 정보 입력창으로 넘어갑니다.");
        	 System.out.println("----------------------------------------");
        	 
        	 //개설된 과정의 과목 입력 클래스로 이동
        	 proc77 p = new proc77();
        	 p.insert(course);
        	 
        	 
	         // 자원 닫기
        	 stat2.close();
	         stat.close();
	        
	         conn.close();
	         

	         
		 } catch(Exception e) {
			 e.printStackTrace();
		 }

		
	}//insert() - 입력메소드

	
	/**
	 * 개설과정 삭제
	 */
	private static void m4() {
		String a = "";
		String b = "";
		Scanner scan = new Scanner(System.in);
		
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         CallableStatement stat2 = null;	 
	         
	         

	         // select문 삽입
	         String sql = "select * from vw73";
	         rs = stat.executeQuery(sql);
	         
	         int cnt = 0;
 	         System.out.println("[번호]\t\t[개설과정명]\t\t[개설과정 시작날짜]\t\t[개설과정 종료날짜]\t\t[강의실명]");
 	         while(rs.next()) {
 		        	
 	        	 cnt++;
 	        	 CallableStatement stat = null;
 	        	 System.out.print(cnt);
 	        	 System.out.print("\t");
 	        	 System.out.print(rs.getString(1));
 	        	 System.out.print("\t");
 	        	 a = rs.getString(2).replace("00:00:00", "");
 	        	 System.out.print(a);
 	        	 System.out.print("\t");
 	        	 b = rs.getString(3).replace("00:00:00", "");
 	        	 System.out.print(b);
 	        	 System.out.print(rs.getString(4));
 	        	 System.out.println("\n");
 	         }
	         

 			System.out.println("----------------------------------------");
 			System.out.print("삭제할 개설 과정명 입력 : ");
 			String name = scan.nextLine();
 			System.out.println("----------------------------------------");
	         
        	 String sql2 = "{call proc76_delete(?)}";
        	 stat2 = conn.prepareCall(sql2);
        	 
        	 stat2.setString(1, name);
  
      
       
        	 
        	 stat2.executeQuery();
        	
        	 
        	 String sql3 = "select * from vw73";
 	         rs = stat.executeQuery(sql3);
 	         
 	         cnt = 0;
 	         
 	         System.out.println("----------------------------------------");
	         System.out.println("개설과정이 삭제되었습니다.");
	         System.out.println("----------------------------------------");
 	         System.out.println("[번호]\t\t[개설과정명]\t\t[개설과정 기간]");
 	         while(rs.next()) {
 		        	
 	        	 cnt++;	
 	        	 CallableStatement stat = null;
 	        	 System.out.print(cnt);
 	        	 System.out.print("\t");
 	        	 System.out.print(rs.getString(1));
 	        	 System.out.print("\t");
 	        	System.out.print(rs.getString(2));
	        	 System.out.print("\t");
	        	 System.out.print(rs.getString(3));
 	        	 System.out.print("\t");
 	        	 System.out.println("\n");
 	         }
 	         
 	        System.out.println("----------------------------------------");
 	       openCourseMain(); 
 	        
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
		
	}//개설과정 삭제 메소드

	
	/**
	 * 개설과정 수정
	 */
	private static void m3() {
		Scanner scan = new Scanner(System.in);
		String a = "";
		String b = "";
		try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select * from vw73";
	         rs = stat.executeQuery(sql);
	         
	         int cnt = 0;
	         System.out.println("[번호]\t\t[개설과정명]\t\t[개설과정 시작날짜]\t\t[개설과정 종료날짜]\t\t[강의실명]");
	         while(rs.next()) {
		        	
	        	 cnt++;
	        	 CallableStatement stat2 = null;
	        	 System.out.print(cnt);
	        	 System.out.print("\t");
	        	 System.out.print(rs.getString(1));
	        	 System.out.print("\t");
	        	 a = rs.getString(2).replace("00:00:00", "");
	        	 System.out.print(a);
	        	 System.out.print("\t");
	        	 b = rs.getString(3).replace("00:00:00", "");
	        	 System.out.print(b);
	        	 System.out.print(rs.getString(4));
	        	 System.out.println("\n");
	         }
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
		System.out.println("----------------------------------------");
		System.out.println("1. 개설과정명 수정");
		System.out.println("2. 개설과정기간 수정");
		System.out.println("3. 개설과정 강의실명 수정");
		System.out.println("4. 뒤로 가기");
		System.out.println("----------------------------------------");
		System.out.print("번호 : ");
		int num = scan.nextInt();
		
		switch(num) {
		case 1:
			m3_name();
			break;
		case 2:
			m3_date();
			break;
		case 3:
			m3_classroom();
			break;
		case 4:
			openCourseMain();
			break;
		}
		
	}

	
	/**
	 * 개설과정에 대한 강의실명 수정 메소드
	 */
	private static void m3_classroom() {
		String a = "";
		String b = "";
		Scanner scan = new Scanner(System.in);
		
		System.out.println("----------------------------------------");
		System.out.print("수정할 기존 강의실명 입력 : ");
		String room = scan.nextLine();
		System.out.print("수정할 새로운 강의실명 입력 : ");
		String new_room = scan.nextLine();
		System.out.println("----------------------------------------");
		
		
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         CallableStatement stat2 = null;	 
	         
        	 String sql = "{call proc76_update_classroomname(?,?)}";
        	 stat2 = conn.prepareCall(sql);
        	 
        	 stat2.setString(1, room);
        	 stat2.setString(2, new_room);
      
       
        	 
        	 stat2.executeQuery();
        	
        	 
        	 String sql2 = "select * from vw73";
 	         rs = stat.executeQuery(sql2);
 	         
 	        System.out.println("----------------------------------------");
 	        System.out.println("개설과정의 강의실명이 수정되었습니다.");
 	       System.out.println("----------------------------------------");
 	         
 	         int cnt = 0;
 	         System.out.println("[번호]\t\t[개설과정명]\t\t[개설과정 시작날짜]\t\t[개설과정 종료날짜]\t\t[강의실명]");
 	         while(rs.next()) {
 		        	
 	        	 cnt++;
 	        	 CallableStatement stat = null;
 	        	 System.out.print(cnt);
 	        	 System.out.print("\t");
 	        	 System.out.print(rs.getString(1));
 	        	 System.out.print("\t");
 	        	 a = rs.getString(2).replace("00:00:00", "");
 	        	 System.out.print(a);
 	        	 System.out.print("\t");
 	        	 b = rs.getString(3).replace("00:00:00", "");
 	        	 System.out.print(b);
 	        	 System.out.print(rs.getString(4));
 	        	 System.out.println("\n");
 	         }
 	         
 	        System.out.println("----------------------------------------");
 	        openCourseMain();
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
		
	}

	/**
	 * 개설과정의 기간 수정 메소드
	 */
	private static void m3_date() {
		String a = "";
		String b = "";
		Scanner scan = new Scanner(System.in);
		
		System.out.println("----------------------------------------");
		System.out.print("수정할 기존 개설과정 시작날짜 입력 : ");
		String start = scan.nextLine();
		System.out.print("수정할 새로운 개설과정 시작날짜 입력 : ");
		String new_start = scan.nextLine();
		System.out.print("수정할 기존 개설과정 종료날짜 입력 : ");
		String finish = scan.nextLine();
		System.out.print("수정할 새로운 개설과정 종료날짜 입력 : ");
		String new_finish = scan.nextLine();
		System.out.println("----------------------------------------");
		
		
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         CallableStatement stat2 = null;	 
	         
        	 String sql = "{call proc76_update_coursedate(?,?,?,?)}";
        	 stat2 = conn.prepareCall(sql);
        	 
        	 stat2.setString(1, start);
        	 stat2.setString(2, new_start);
        	 stat2.setString(3, finish);
        	 stat2.setString(4, new_finish);
       
        	 
        	 stat2.executeQuery();
        	
        	 
        	 
        	 System.out.println("----------------------------------------");
  	        System.out.println("개설과정의 기간이 수정되었습니다.");
  	       System.out.println("----------------------------------------");
        	 
        	 String sql2 = "select * from vw73";
 	         rs = stat.executeQuery(sql2);
 	         
 	         
 	         
 	         
 	         int cnt = 0;
 	         System.out.println("[번호]\t\t[개설과정명]\t\t[개설과정 시작날짜]\t\t[개설과정 종료날짜]\t\t[강의실명]");
 	         while(rs.next()) {
 		        	
 	        	 cnt++;
 	        	 CallableStatement stat = null;
 	        	 System.out.print(cnt);
 	        	 System.out.print("\t");
 	        	 System.out.print(rs.getString(1));
 	        	 System.out.print("\t");
 	        	 a = rs.getString(2).replace("00:00:00", "");
 	        	 System.out.print(a);
 	        	 System.out.print("\t");
 	        	 b = rs.getString(3).replace("00:00:00", "");
 	        	 System.out.print(b);
 	        	 System.out.print(rs.getString(4));
 	        	 System.out.println("\n");
 	         }
 	         
 	        System.out.println("----------------------------------------");
 	        openCourseMain();
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
		
	}

	/**
	 * 개설과정명 수정 메소드
	 */
	private static void m3_name() {
		String a = "";
		String b = "";
		Scanner scan = new Scanner(System.in);
		
		System.out.println("----------------------------------------");
		System.out.print("수정할 기존 개설과정명 입력 : ");
		String name = scan.nextLine();
		System.out.print("수정할 새로운 개설과정명 입력 : ");
		String new_name = scan.nextLine();
		System.out.println("----------------------------------------");
		
		
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         CallableStatement stat2 = null;	 
	         
        	 String sql = "{call proc76_update_coursename(?,?)}";
        	 stat2 = conn.prepareCall(sql);
        	 
        	 stat2.setString(1, name);
        	 stat2.setString(2, new_name);
       
        	 
        	 stat2.executeQuery();
        	
        	 
        	 
        	 System.out.println("----------------------------------------");
        	 System.out.println("개설과정명이 수정되었습니다.");
        	 System.out.println("----------------------------------------");
        	 
        	 
        	 String sql2 = "select * from vw73";
 	         rs = stat.executeQuery(sql2);
 	         
 	         int cnt = 0;
 	         System.out.println("[번호]\t\t[개설과정명]\t\t[개설과정 시작날짜]\t\t[개설과정 종료날짜]\t\t[강의실명]");
 	         while(rs.next()) {
 		        	
 	        	 cnt++;
 	        	 CallableStatement stat = null;
 	        	 System.out.print(cnt);
 	        	 System.out.print("\t");
 	        	 System.out.print(rs.getString(1));
 	        	 System.out.print("\t");
 	        	 a = rs.getString(2).replace("00:00:00", "");
 	        	 System.out.print(a);
 	        	 System.out.print("\t");
 	        	 b = rs.getString(3).replace("00:00:00", "");
 	        	 System.out.print(b);
 	        	 System.out.print(rs.getString(4));
 	        	 System.out.println("\n");
 	         }
 	         
 	        System.out.println("----------------------------------------");
 	        openCourseMain();
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
		
		
	}

	
	/**
	 * 개설 과정 정보 출력시 개설 과정명, 개설 과정기간(시작 년월일, 끝 년월일), 강의실명, 교육생 등록 인원, --vw73 
	       개설 과목 등록 여부를 출력한다. 
	 */
	public static void m1() {
		Scanner scan = new Scanner(System.in);
		String a = "";
		String b = "";
		
		// 구현부
	      try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();

	         // select문 삽입
	         String sql = "select * from vw73";
	         rs = stat.executeQuery(sql);

	         
	         int cnt = 0;
	         System.out.println("[번호]\t\t[개설과정명]\t\t[개설과정시작날짜]\t\t\t[개설과정종료날짜]\t\t[강의실명]");
	         while(rs.next()) {
		        	
	        	 cnt++;
	        	 CallableStatement stat2 = null;
	        	 System.out.print(cnt);
	        	 System.out.print("\t");
	        	 System.out.print(rs.getString(1));
	        	 System.out.print("\t");
	        	 a = rs.getString(2).replace("00:00:00", "");
	        	 System.out.print(a);
	        	 System.out.print("\t");
	        	 b = rs.getString(3).replace("00:00:00", "");
	        	 System.out.print(b);
	        	 System.out.print("\t");
	        	 System.out.print(rs.getString(4));
	        	 System.out.print("\t");
	        	 System.out.print(rs.getString(5));
	        	 System.out.print("\t");
	        	 
	        	 String sql2 = "{call proc73(?,?)}";
	        	 stat2 = conn.prepareCall(sql2);
	        	 
	        	 stat2.setString(1, rs.getString(1));
	        	 stat2.registerOutParameter(2,  OracleTypes.CURSOR);
	        	 
	        	 stat2.executeQuery();
	        	 ResultSet rs2 = (ResultSet)stat2.getObject(2);
	     
	        	 while(rs2.next()) {
	        		 System.out.print(rs2.getString(2)+", ");
	        		 //System.out.print("\t");
	        	 }
	        	 System.out.println("\n");
	         }
	         
	         System.out.println("---------------------------------------------------------------------");
	         System.out.print("개설 과정명 번호 입력 : ");
	         int num = scan.nextInt();
	         System.out.println("---------------------------------------------------------------------");
	         
	         //특정 개설 과정 선택 시
	         m2(num);
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      }
		
	}

	/**
	 * 특정 개설 과정명을 입력받은 경우, 해당 개설 과정에 대한 개설과목정보출력
	 * @param 특정 개설과정명
	 */
	private static void m2(int num) {
		Scanner scan = new Scanner(System.in);
		//개설 과정에 등록된 개설 과목 정보(과목명, 과목기간(시작 년월일, 끝 년월일), 교재명, 교사명) 
		String a = "";
		String b = "";
		 
    	 try {
    		 CallableStatement stat2 = null;
    		 conn = util.open("211.63.89.47","project","java1234");
    		
    		 String sql2 = "{call proc74_subject(?,?)}";
			 stat2 = conn.prepareCall(sql2);
			
			 stat2.setInt(1, num);
			 stat2.registerOutParameter(2,  OracleTypes.CURSOR);
       	 
	       	 stat2.executeQuery();
	       	 ResultSet rs2 = (ResultSet)stat2.getObject(2);
	    
	       	 System.out.println("[개설과목명]\t\t[개설과목시작날짜]\t\t[개설과목 종료날짜]\t\t[교재명]\t\t[교사명]");
	       	 while(rs2.next()) {
	       		 System.out.print(rs2.getString(2));
	       		 System.out.print("\t");
		       	 a = rs2.getString(3).replace("00:00:00", "");
		       	 System.out.print(a);
		       	 System.out.print("\t");
		       	 b = rs2.getString(4).replace("00:00:00", "");
		       	 System.out.print(b);
		       	 System.out.print("\t");
		       	 System.out.print(rs2.getString(5));
		       	 System.out.print("\t");
		       	 System.out.println(rs2.getString(6)); 
	       	 }
	       	 System.out.println("\n");
       	 
	       	 
	       	 //등록된 교육생 정보(교육생 이름, 주민번호 뒷자리, 전화번호, 등록일, 수료 및 중도탈락)을 확인할 수 있어야 한다. 
	       	 sql2 = "{call proc74_student(?,?)}";
	       	 stat2 = conn.prepareCall(sql2);
				
			 stat2.setInt(1, num);
			 stat2.registerOutParameter(2,  OracleTypes.CURSOR);
       	 
	       	 stat2.executeQuery();
	       	 rs2 = (ResultSet)stat2.getObject(2);
	    
	       	 System.out.println("[교육생이름]\t\t[주민번호 뒷자리]\t\t[핸드폰번호]\t\t[수료 및 중도탈락]");
	       	 while(rs2.next()) {
	       		System.out.print(rs2.getString(1));
	       		System.out.print("\t\t\t");
	       		System.out.print(rs2.getString(2));
	       		System.out.print("\t\t\t");
	       		System.out.print(rs2.getString(3));
	       		System.out.print("\t\t\t");
	       		System.out.println(rs2.getString(4));
	       	 }
       	 
       	 
	       	 System.out.println("---------------------------------------------------------------------");
	       	 System.out.println("개설과정 및 과목 정보 출력이 완료되었습니다.");
	       	 System.out.println("---------------------------------------------------------------------");
	       	 
	       	openCourseMain();
	       	 
	       	 
	       	 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
	}
	
	
	
}

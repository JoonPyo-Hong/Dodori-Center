package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;

/**
 * 
 * @author 강혜림
 *
 */
//개설 과목 관리
public class proc77 {

   
   // 필요한 객체 생성
      static Connection conn = null;
      static Statement stat = null;
      static ResultSet rs = null;
      static DBUtil util = new DBUtil();
   
      
      /**
       * 개설과목관리 서브메뉴출력 메소드
       */
   public static void openSubjcetMain() {
      Scanner scan = new Scanner(System.in);
      System.out.println("               [개설과목 관리]             ");
      System.out.println("----------------------------------------");
      System.out.println("1. 개설 과목 정보 출력");
      System.out.println("2. 개설 과목 정보 수정");
      System.out.println("3. 개설 과목 정보 삭제");
      System.out.println("4. 뒤로 가기");
      System.out.println("----------------------------------------");
      System.out.print("번호 : ");
      int num = scan.nextInt();
      System.out.println("----------------------------------------");
      
      switch(num) {
      //출력   
      case 1:
         proc69 p = new proc69();
         p.m1();
         break;
      //수정
      case 2:
         m3();
         break;
      //삭제
      case 3:
         m4();
         break;
      //뒤로가기
      case 4:
    	  ManagerLogin m1 = new ManagerLogin();
    	  m1.printManagerMenu();
    	  break;
      }
      
   }

   /**
    * 개설 과목명 수정 메소드
    */
   private static void m3() {
      String a = "";
      String b = "";
      Scanner scan = new Scanner(System.in);
      
      try {
        // 3조 SQL 연결
        conn = util.open("211.63.89.47","project","java1234");
       //conn = util.open1();
       stat = conn.createStatement();
        CallableStatement stat2 = null;    
        
        

        // select문 삽입
        String sql = "select * from tblSubject";
        rs = stat.executeQuery(sql);
        
   
         System.out.println("[번호]\t\t[개설과정명]");
         while(rs.next()) {
              
  
            System.out.print(rs.getString(1));
            System.out.print("\t");
           System.out.print(rs.getString(2));
            System.out.println("\n");
         }
        
      
      System.out.println("----------------------------------------");
      System.out.print("수정할 기존 개설 과목명 입력 : ");
      String subject = scan.nextLine();
      System.out.print("수정할 새로운 개설 과목명 입력 : ");
      String new_subject = scan.nextLine();
      System.out.println("----------------------------------------");
      
      
   
            // 3조 SQL 연결
            //conn = util.open1();
            conn = util.open("211.63.89.47","project","java1234");
            stat = conn.createStatement();
            //CallableStatement stat2 = null;    
            
            String sql2 = "{call proc85_update_subjectname(?,?)}";
            stat2 = conn.prepareCall(sql2);
            
            stat2.setString(1, subject);
            stat2.setString(2, new_subject);
      
       
            
            stat2.executeQuery();
           

            System.out.println("----------------------------------------");
            System.out.println("개설과목명이 수정되었습니다.");
            System.out.println("----------------------------------------");
            
           // select문 삽입
             String sql3 = "select * from tblSubject";
             rs = stat.executeQuery(sql3);
             
        
              System.out.println("[번호]\t\t[개설과정명]");
              while(rs.next()) {
                   
       
                 System.out.print(rs.getString(1));
                 System.out.print("\t");
                System.out.print(rs.getString(2));
                 System.out.println("\n");
              }
            
              System.out.println("----------------------------------------");
              openSubjcetMain();
              
            // 자원 닫기
            stat.close();
            conn.close();
           
            // 예외 처리
            } catch (Exception e) {
            System.out.println("오류 발생");
         }
      
   }

   /**
    * 개설 과목 삭제 메소드
    */
   private static void m4() {
   
      Scanner scan = new Scanner(System.in);
   

       try {
            // 3조 SQL 연결
            conn = util.open("211.63.89.47","project","java1234");
          //conn = util.open1(); 
          stat = conn.createStatement();
            CallableStatement stat2 = null;    
            
            

            // select문 삽입
            String sql = "select * from tblSubject";
            rs = stat.executeQuery(sql);
            
       
             System.out.println("[번호]\t\t[개설과정명]");
             while(rs.next()) {
                  
      
                System.out.print(rs.getString(1));
                System.out.print("\t");
               System.out.print(rs.getString(2));
                System.out.println("\n");
             }
            

          System.out.println("----------------------------------------");
          System.out.print("삭제할 개설 과목명 입력 : ");
          String name = scan.nextLine();
          System.out.println("----------------------------------------");
            
            String sql2 = "{call proc85_delete(?)}";
            stat2 = conn.prepareCall(sql2);
            
            stat2.setString(1, name);
  
      
       
            
            stat2.executeQuery();
           
            
            System.out.println("----------------------------------------");
            System.out.println("개설과목이 삭제되었습니다.");
            System.out.println("----------------------------------------");
            
            String sql3 = "select * from tblSubject";
             rs = stat.executeQuery(sql3);
             
             System.out.println("[번호]\t\t[개설과목명]");
             while(rs.next()) {

                System.out.print(rs.getString(1));
                System.out.print("\t");
               System.out.print(rs.getString(2));
                System.out.println("\n");
             }
             
             System.out.println("----------------------------------------");
             openSubjcetMain();
            
            // 자원 닫기
            stat.close();
            conn.close();
           
            // 예외 처리
            } catch (Exception e) {
            System.out.println("오류 발생");
         }
      
   }

   /**
    * 특정 과정명을 선택한 경우, 해당 과정에 대한 새로운 과목 정보 입력 메소드
    * @param course 특정 과정명
    */
   public static void insert(int course) {
      Scanner scan = new Scanner(System.in);
     // course  = 1;
      
       try {
            // 3조 SQL 연결
            conn = util.open("211.63.89.47","project","java1234");
           //conn = util.open1();
           stat = conn.createStatement(); 
            
             
               // 과목명 기초데이터 출력
               String sql = "select * from tblSubject";
               rs = stat.executeQuery(sql);
               
               System.out.println("[번호]\t\t[개설과목명]");
               while(rs.next()) {
              
                  System.out.print(rs.getString(1));
                  System.out.print("\t");
                  System.out.print(rs.getString(2));
                  System.out.println("\n");
               }
               
               
               System.out.println("----------------------------------------");
               System.out.print("추가할 개설 과목 번호 입력 : ");
               String num = scan.nextLine();
               int num2 = Integer.parseInt(num);
               System.out.println("----------------------------------------");
               System.out.print("추가할 개설 과목 시작날짜 입력 : ");
               String start = scan.nextLine();
               System.out.print("추가할 개설 과목 종료날짜 입력 : ");
               String finish = scan.nextLine();
               System.out.println("----------------------------------------");
               
               // 교재명 기초데이터 출력
               sql = "select * from vw81";
               rs = stat.executeQuery(sql);
               
               System.out.println("[번호]\t\t[교재명]\t\t[출판사]");
               while(rs.next()) {
              
                  System.out.print(rs.getString(1));
                  System.out.print("\t");
                  System.out.print(rs.getString(2));
                  System.out.print("\t");
                  System.out.print(rs.getString(3));
                  System.out.println("\n");
               }
               System.out.println("----------------------------------------");
               System.out.print("추가할 개설 교재명 입력 : ");
               String book = scan.nextLine();
               System.out.println("----------------------------------------");
               
               //교사 데이터 출력
               CallableStatement stat2 = null;    
               
               sql = "{call proc82(?,?)}";
               stat2 = conn.prepareCall(sql);
               
               stat2.setInt(1, num2);
               stat2.registerOutParameter(2,  OracleTypes.CURSOR);
               
               stat2.executeQuery();
               ResultSet rs2 = (ResultSet)stat2.getObject(2);
        
               while(rs2.next()) {
                  System.out.print(rs2.getString(2));
                  System.out.print("\n");
                  
               }
          
               stat2.executeQuery();
               
               Scanner scan1 = new Scanner(System.in);
               System.out.println("----------------------------------------");
               System.out.print("추가할 교사명 입력 : ");
               String teacher = scan1.nextLine();
               System.out.println("----------------------------------------");
               
               
               //proc79_insert에 값 넣기
               String sql2 = "{call proc79_insert(?,?,?,?,?,?)}";
               stat2 = conn.prepareCall(sql2);
               

               stat2.setInt(1, course);
               stat2.setInt(2, num2);
               stat2.setString(3, start);
               stat2.setString(4, finish);
               stat2.setString(5, book);
               stat2.setString(6, teacher);
               
               System.out.println("----------------------------------------");
               System.out.println("새로 개설된 과정의 과목 정보가 입력되었습니다.");
               System.out.println("----------------------------------------");
               proc69 p69 = new proc69();
               p69.openCourseMain();
               
            // 자원 닫기
            
            stat2.close();
            stat.close();
           
            conn.close();
           
            // 예외 처리
            } catch (Exception e) {
           // System.out.println(e);
            e.printStackTrace();
         }
      
   }

   
}
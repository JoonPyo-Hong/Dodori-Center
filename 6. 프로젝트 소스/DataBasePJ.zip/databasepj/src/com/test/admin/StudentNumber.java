package com.test.admin;

public class StudentNumber {
//삭제할 학생번호 받아서 저장하는 변수
	public String studentNum;

	public String getStudentNum() {
		return studentNum;
	}

	public void setStudentNum(String studentNum) {
		this.studentNum = studentNum;
	} 
	
	
}

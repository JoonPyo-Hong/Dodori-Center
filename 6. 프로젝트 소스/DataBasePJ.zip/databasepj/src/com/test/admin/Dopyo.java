// 도표 클래스
package com.test.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

//import com.test.student.DBUtil;
/**
 * 
 * @author 홍준표
 *
 */
public class Dopyo {
	Connection conn = null;
	Statement stat = null;
	ResultSet rs = null;
	DBUtil util = new DBUtil();
	Scanner scan = new Scanner(System.in);
	ArrayList<String> s1 = new ArrayList<String>();
	ArrayList<Integer> s2 = new ArrayList<Integer>();

	ArrayList<Integer> s3 = new ArrayList<Integer>();
	ArrayList<Double> s4 = new ArrayList<Double>();
	ArrayList<String> qq = new ArrayList<String>();
	
	/**
	 * 동아리별 취업률 첫출력문
	 */
	
	public void dopyo() {
		System.out.println("----------------------------");
		System.out.println("동아리별 취업률");
		System.out.println("----------------------------");
		
		m1();
		m2();
		m3();
		m4();
	
	}
	/**
	 * 동아리별 취업률 도표 출력문
	 */
	private void m4() {
	
		int a = 0;
		int b = 0;
		Double c = 0.0;
		Double d = 0.0;
		Double e = 0.0;
		for(int i=0; i<s2.size(); i++) {
			
			a = s2.get(i);
			b = s3.get(i);
			d = (double) a;
			e = (double) b;
			c= e/d *100;
			s4.add(c);
			
			
		}
		
		
		int w = 10;
		
		//System.out.println(s4);
		String[][] arr = new String[w][s2.size()];
		
		for(int i=0; i<s2.size(); i++) {
			if(s4.get(i) == 100) {
				for(int j=w-1; j>=0; j--) {
					arr[j][i] = "■";
				}
			} else if(s4.get(i)<100&&s4.get(i)>=90) {
				for(int j=w-1; j>=1; j--) {
					arr[j][i] = "■";
				}
			} else if(s4.get(i)<90&&s4.get(i)>=80) {
				for(int j=w-1; j>=2; j--) {
					arr[j][i] = "■";
				}
			} else if(s4.get(i)<80&&s4.get(i)>=70) {
				for(int j=w-1; j>=3; j--) {
					arr[j][i] = "■";
				}
			} else if(s4.get(i)<70&&s4.get(i)>=60) {
				for(int j=w-1; j>=4; j--) {
					arr[j][i] = "■";
				}
			} else if(s4.get(i)<60&&s4.get(i)>50) {
				for(int j=w-1; j>=5; j--) {
					arr[j][i] = "■";
				}
			}
		}
		
		for(int i=0;i<w; i++) {
			for(int j=0;j<s2.size();j++) {
				if(arr[i][j]==null) {
					System.out.print("\t\t\t");
				}
				else {
					
					System.out.print("\t\t"+arr[i][j] + "\t");
				}
				
			}
			System.out.println();
		}
		
		
		for(int q=0; q<s1.size(); q++) {
			System.out.print(s1.get(q)+"\t\t  ");
		}
		
		
		
//		for (int j=0; j<w; j++) {
//			
//			for(int i=0; i<s2.size(); i++) {
//				if(s4.get(i)==100) {
//					
//					w =10;
//				}else if(s4.get(i)<100&&s4.get(i)>=90) {
//						
//					w =9;
//				}else if(s4.get(i)<90&&s4.get(i)>=80) {
//					w =8;
//				}else if(s4.get(i)<80&&s4.get(i)>=70) {
//					w =7;
//				}else if(s4.get(i)<70&&s4.get(i)>=60) {
//				
//					w =6;
//				}else if(s4.get(i)<60&&s4.get(i)>50) {
//			
//					w =5;
//				}
//				
//				for(int k = 0; k<w; k++) {
//					
//				}
//				System.out.print("■ "); System.out.print("\t\t");
//				
//			}
			

		
//		System.out.print(s1.get(1));
		for(int i=0; i<s2.size(); i++) {
		
		
		if(s4.get(i)==100) {
	
	
		}else if(s4.get(i)<100&&s4.get(i)>=90) {

			
		}else if(s4.get(i)<90&&s4.get(i)>=80) {

		}else if(s4.get(i)<80&&s4.get(i)>=70) {
			
		}else if(s4.get(i)<70&&s4.get(i)>=60) {
		
		}else if(s4.get(i)<60&&s4.get(i)>50) {
	
		
		}else {
		
		}
		}
		
	}
	private void m3() {
		try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         
	         // select문 삽입
	         String sql = "select count(sg.seq_open_study_group)--동아리별 취업한 교육생 숫자\r\n" + 
	         		"    from tblcompany c \r\n" + 
	         		"        inner join tbljobinfo j \r\n" + 
	         		"            on c.seq_company = j.seq_company\r\n" + 
	         		"                inner join tblStudyGroup sg\r\n" + 
	         		"                    on sg.seq_study_group = j.seq_study_group\r\n" + 
	         		"                        inner join tblOpenStudyGroup osg\r\n" + 
	         		"                            on sg.seq_open_study_group = osg.seq_open_study_group\r\n" + 
	         		"                                inner join tblRegistCourse r\r\n" + 
	         		"                                    on sg.seq_regist_course = r.seq_regist_course\r\n" + 
	         		"                                        inner join tblStudent st\r\n" + 
	         		"                                            on r.seq_student = st.seq_student \r\n" + 
	         		"                                                group by sg.seq_open_study_group";
	         rs = stat.executeQuery(sql);
	         
	         
	        
	         
	         
	         while(rs.next()) {
	        
	        	 		s3.add(rs.getInt(1));
	        	 		
	        	 	
	        	
	        
	        	 		
	        	 
	        
 	 		
	        	 
	         }
	         
	         
	         
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      	}
	}
	private void m2() {
		try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         
	         // select문 삽입
	         String sql = "select count(osg.seq_open_study_group) as 동아리원수\r\n" + 
	         		"    from tblOpenStudyGroup osg \r\n" + 
	         		"        inner join tblStudyGroup sg \r\n" + 
	         		"            on osg.seq_open_study_group = sg.seq_open_study_group \r\n" + 
	         		"                group by osg.seq_open_study_group";
	         rs = stat.executeQuery(sql);
	         
	         
	        
	         
	         
	         while(rs.next()) {
	        
	        	 		s2.add(rs.getInt(1));
	        	 		
	        	 	
	        	
	        
	        	 		
	        	 
	        
   	 		
	        	 
	         }
	         
	         
	         
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      	}
	}
	private void m1() {
		try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         
	         // select문 삽입
	         String sql = "select s.study_group_name,j.seq_job_info from \r\n" + 
	         		"    tblOpenStudyGroup s\r\n" + 
	         		"        inner join \r\n" + 
	         		"            tblStudyGroup o\r\n" + 
	         		"                on s.seq_open_study_group = o.seq_open_study_group\r\n" + 
	         		"                    inner join tblJobInfo j\r\n" + 
	         		"                        on j.seq_study_group =o.seq_study_group\r\n" + 
	         		"                    order by s.study_group_name";
	         rs = stat.executeQuery(sql);
	         
	         
	         String a ="";
	         
	         
	         while(rs.next()) {
	        
	        	 	if(!rs.getString(1).equals(a)) {
	        	 		s1.add(rs.getString(1));
	        	 		
	        	 	}
	        	
	        
	        	 		
	        	 
	        
     	 		 a = rs.getString(1);
	        	 
	         }
	         
	         
	         
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println("오류 발생");
	      	}
		
	
	}

}


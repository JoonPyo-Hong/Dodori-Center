package com.test.admin;

public class Test {
	public static void main(String[] args) {
		DongariOutput out = new DongariOutput();
		out.out();
	}
}	


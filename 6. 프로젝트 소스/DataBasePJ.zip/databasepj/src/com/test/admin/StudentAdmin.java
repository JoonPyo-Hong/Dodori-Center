package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

//import com.test.main.DBUtil;

import oracle.jdbc.OracleTypes;


/**
 * 
 * @author lllss
 *
 */
public class StudentAdmin {
	StudentNumber st = new StudentNumber();
	public static Boolean roof = true;
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		StudentAdmin ad = new StudentAdmin();
		ad.studentMain();

	}
	
	
	/**
	 * 교육생 관리메뉴
	 */
	public void studentMain() {

		while (roof) {
			// 출력문
			System.out.println("============================");	
			System.out.println("1. 교육생 등록 및 관리");
			System.out.println("2. 교육생 조회");
			System.out.println("3. 뒤로가기");
			System.out.println("============================");	
			System.out.print("선택(번호) : ");
			String input = scan.nextLine();
			System.out.println("============================");	

			// 교육생 등록 및 관리
			if (input.equals("1")) {
				studentManage();
				// 교육생 조회
			} else if (input.equals("2")) {
				studentViewM();
				// 뒤로가기
			} else if (input.equals("3")) {
				// roof = false;
				break;
			}

		}

	}

	/**
	 * 교육생 등록및 관리 메뉴
	 */
	public void studentManage() {
		while (true) {
			System.out.println("============================");	
			System.out.println("1. 교육생신규등록");
			System.out.println("2. 교육생정보수정");
			System.out.println("3. 교육생정보삭제 ");
			System.out.println("4. 교육생수료여부 관리");
			System.out.println("5. 뒤로가기");
			System.out.println("============================");	
			System.out.print("번호 입력 : ");
			String input = scan.nextLine();
			System.out.println("============================");	
			if (input.equals("1")) {
				studentRegist();

			} else if (input.equals("2")) {
				studentMod();

			} else if (input.equals("3")) {
				studentDelete();

			} else if (input.equals("4")) {
				studentState();

			} else if (input.equals("5")) {
				break;

			}

		}

	}

	/**
	 * 교육생신규등록
	 */
	public void studentRegist() {

		Connection conn = null;
		CallableStatement stat = null;
		// ResultSet rs = null;
		DBUtil util = new DBUtil();
		System.out.println("교육생을 신규등록합니다.");
		System.out.println("신규등록할 정보를 입력해주세요.");
		try {
			System.out.println("============================");	
			System.out.print("교육생명 : ");
			String name = scan.nextLine();
			System.out.print("주민등록번호 : ");
			String ssn = scan.nextLine();
			System.out.print("전화번호 : ");
			String tel = scan.nextLine();
			System.out.print("전공여부: ");
			String major = scan.nextLine();
			System.out.println("============================");	
			// conn = util.open("", "project", "java1234");
			conn = util.open();
			// 교육생 추가 프로시저 호출
			String sql = "{call proc88mod(?,?,?,?)";
			stat = conn.prepareCall(sql);
			stat.setString(1, name);
			stat.setString(2, ssn);
			stat.setString(3, tel);
			stat.setString(4, major);
			
			stat.executeUpdate();
			System.out.println("등록이 완료되었습니다.");
			
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
	/**
	 * 수정할 교육생의 정보를 받는 메소드
	 */
	public void studentMod() {

		Connection conn = null;
		ResultSet rs = null;
		Statement stata = null;
		DBUtil util = new DBUtil();
		System.out.println("교육생정보를 수정합니다.");
		System.out.println("교육생 번호를 입력해주세요.");
		try {
			// conn = util.open("", "project", "java1234");
			conn = util.open();
			stata = conn.createStatement();
			// 수정할 교육생 번호 입력
			System.out.print("교육생번호입력 : ");
			String studentNum = scan.nextLine();
			// 입력받은 번호 세터로 넣어주기
			st.setStudentNum(studentNum);
			// 교육생 보여주기
			String sql = String.format("select * from tblStudent where seq_student = %s", studentNum);
			rs = stata.executeQuery(sql);
			System.out.println("[교육생번호]    [교육생명]\t[교육생주민등록번호]\t   [교육생전화번호]\t  [전공]");
			while (rs.next()) {
				System.out.printf("%s\t           ", rs.getString(1));
				System.out.printf("%s\t", rs.getString(2));
				System.out.printf("%s     ", rs.getString(3));
				System.out.printf("%s        ", rs.getString(4));
				System.out.printf("%s\r\n", rs.getString(5));
			}
			System.out.println("============================");	
			System.out.println("위 학생을 수정하시겠습니까?");
			System.out.println("입력(Y/N) : ");
			String input = scan.nextLine();
			System.out.println("============================");	

			if (input.toUpperCase().equals("Y")) {
				studentModYes();
			} else if (input.toUpperCase().equals("N")) {
				System.out.println("============================");	
				System.out.println("교육생수정을 취소합니다.");
				System.out.println("이전 메뉴로 되돌아갑니다.");
				System.out.println("============================");	

			} else {

				System.out.println("잘못입력했습니다.");
				System.out.println("다시 돌아가려면 엔터를 눌러주세요..");
				String enter = scan.nextLine();
				studentMod();
			}

			rs.close();
			stata.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 교육생 정보 수정
	 * 
	 */
	private void studentModYes() {

		Connection conn = null;
		CallableStatement stat = null;
		Statement stata = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		try {
			conn = util.open();
			// conn = util.open("", "project", "java1234");
			// 교육생 수정 프로시저 호출
			System.out.println("============================");	
			System.out.print("교육생이름 : ");
			String name = scan.nextLine();
			System.out.print("교육생주민등록번호 : ");
			String ssn = scan.nextLine();
			System.out.print("교육생전화번호 : ");
			String tel = scan.nextLine();
			System.out.print("교육생전공 : ");
			String major = scan.nextLine();
			System.out.println("============================");	
			String sql = "{call proc93UpdateMod(?,?,?,?,?)}";
			stat = conn.prepareCall(sql);
			stat.setString(1, st.getStudentNum());
			stat.setString(2, name);
			stat.setString(3, ssn);
			stat.setString(4, tel);
			stat.setString(5, major);
			stat.executeUpdate();
			// 수정된 값을 출력해서 보여주기
			stata = conn.createStatement();
			String sql2 = String.format("select * from tblStudent where seq_student = %s", st.getStudentNum());
			rs = stata.executeQuery(sql2);
			System.out.println("[교육생번호]    [교육생명]\t[교육생주민등록번호]\t   [교육생전화번호]\t  [전공]");
			while (rs.next()) {
				System.out.printf("%s\t           ", rs.getString(1));
				System.out.printf("%s\t", rs.getString(2));
				System.out.printf("%s     ", rs.getString(3));
				System.out.printf("%s        ", rs.getString(4));
				System.out.printf("%s\r\n", rs.getString(5));
			}

			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 삭제할 교육생의 정보를 받는 메소드
	 */
	public void studentDelete() {

		Connection conn = null;
		ResultSet rs = null;
		Statement stat = null;
		DBUtil util = new DBUtil();
		System.out.println("교육생을 삭제합니다.");
		System.out.println("삭제할 교육생 번호를 입력해주세요.");

		try {
			conn = util.open();
			// conn = util.open("", "project", "java1234");
			stat = conn.createStatement();
			// 삭제할 교육생 번호 입력
			System.out.print("교육생번호입력 : ");
			String studentNum = scan.nextLine();
			// 교육생 보여주기
			String sql = String.format("select * from tblStudent where seq_student = %s", studentNum);
			rs = stat.executeQuery(sql);
			st.setStudentNum(studentNum);

			System.out.println("[교육생번호]    [교육생명]\t[교육생주민등록번호]\t   [교육생전화번호]\t  [전공]");
			while (rs.next()) {
				System.out.printf("%s\t           ", rs.getString(1));
				System.out.printf("%s\t", rs.getString(2));
				System.out.printf("%s     ", rs.getString(3));
				System.out.printf("%s        ", rs.getString(4));
				System.out.printf("%s\r\n", rs.getString(5));
			}

			System.out.println("============================");	
			System.out.println("위 학생을 삭제하시겠습니까?");
			System.out.println("입력(Y/N) : ");
			String input = scan.nextLine();
			System.out.println("============================");	

			if (input.toUpperCase().equals("Y")) {

				studentDeleteYes();

			} else if (input.toUpperCase().equals("N")) {
				System.out.println("============================");	
				System.out.println("교육생삭제를 취소합니다.");
				System.out.println("이전 메뉴로 되돌아갑니다.");
				System.out.println("============================");	
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 교육생 삭제
	 */
	public void studentDeleteYes() {

		Connection conn = null;
		CallableStatement stat = null;
		ResultSet rs = null;
		Statement stata = null;
		DBUtil util = new DBUtil();
		try {
			conn = util.open();
			// conn = util.open("", "project", "java1234");
			// 교육생 삭제 프로시저 호출
			String sql = "{call proc93_delete(?)}";
			stat = conn.prepareCall(sql);
			stat.setString(1, st.getStudentNum());
			stat.executeUpdate();
			// 삭제된 값을 출력해서 보여주기
			stata = conn.createStatement();
			String sql2 = String.format("select * from tblStudent where seq_student = %s", st.getStudentNum());
			rs = stata.executeQuery(sql2);

			System.out.println("[교육생번호]    [교육생명]\t[교육생주민등록번호]\t   [교육생전화번호]\t  [전공]");
			while (rs.next()) {
				System.out.printf("%s\t           ", rs.getString(1));
				System.out.printf("%s\t", rs.getString(2));
				System.out.printf("%s     ", rs.getString(3));
				System.out.printf("%s        ", rs.getString(4));
				System.out.printf("%s\r\n", rs.getString(5));
			}

			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 교육생 수료/중도탈락 상태 변경
	 */
	
	public void studentState() {

		Connection conn = null;
		CallableStatement stat = null;
		DBUtil util = new DBUtil();
		System.out.println("교육생 수료여부를 변경합니다.");
		System.out.println("수료상태를 변경할 교육생 번호를 입력해주세요.");

		try {
			conn = util.open();
			// conn = util.open("", "project", "java1234");
			// 상태를 변경할 교육생 번호 입력
			System.out.print("교육생번호입력 : ");
			String studentNum = scan.nextLine();
			// 수료정보 입력
			System.out.print("수료상태 입력(수료/중도탈락): ");
			String state = scan.nextLine();
			System.out.print("중도탈락일 입력 (yyyy-mm-dd): ");
			String endDate = scan.nextLine();

			// 교육생 수료여부 변경
			String sql = "{call proc92(?,?,?)";

			stat = conn.prepareCall(sql);
			stat.setString(1, studentNum);
			stat.setString(2, state);
			stat.setString(3, endDate);
			stat.executeUpdate();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	/**
	 * 학생정보검색 메뉴
	 */
	
	public void studentViewM() {
		while (true) {
			System.out.println("1. 번호로 조회하기");
			System.out.println("2. 뒤로가기");
			System.out.println("============================");	
			System.out.print("번호입력 : ");
			String input = scan.nextLine();
			System.out.println("============================");	
			if (input.equals("1")) {
				studentNumView();

			} else if (input.equals("2")) {
				break;
				
			} else {
				System.out.println("잘못 입력 하셨습니다.");
				System.out.println("다시 돌아가려면 엔터를 눌러주세요..");
				String enter = scan.nextLine();
			}
		}
	}


	/**
	 * 학생번호로 학생정보 조회
	 */
	
	public void studentNumView() {

		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		ResultSet rs2 = null;
		DBUtil util = new DBUtil();
		System.out.println("교육생 정보를 조회합니다.");
		System.out.println("조회할 교육생의 번호를 입력해주세요.");
		try {
			// 연결
			// conn = util.open("", "project", "java1234");
			conn = util.open();
			stat = conn.createStatement();
			// 특정학생 번호 받기
			System.out.println("============================");	
			System.out.print("교육생번호 입력 : ");
			String studentNum = scan.nextLine();
			System.out.println("============================");	
			String sql = String.format(
					"select student_name, student_ssn, student_tel, major from tblStudent where seq_student = %s",
					studentNum);
			rs = stat.executeQuery(sql);

			System.out.println("[교육생명]\t     [주민등록번호]\t       [전화번호]\t        [전공여부]\t [교육생번호] [수강횟수]");
			int cnt = 0;
			while (rs.next()) {
				cnt++;
				if (cnt >= 0) {
					System.out.printf("%s\t     ", rs.getString(1));
					System.out.printf("%s    ", rs.getString(2));
					System.out.printf("%s\t  ", rs.getString(3));
					System.out.printf("%s\t  ", rs.getString(4));
				}

			}
			if (cnt == 0) {
				System.out.println("============================");	
				System.out.println("잘못된 정보입니다. 다시 입력해주세요.");
				System.out.println("============================");	
				studentNumView();
			}

			String sql2 = String.format("select * from vwCountSugang where 교육생번호 = %s", studentNum);
			rs2 = stat.executeQuery(sql2);

			while (rs2.next()) {
				System.out.printf("%s\t    ", rs2.getString(1));
				System.out.printf("%s\r\n", rs2.getString(2));

			}

			rs.close();
			rs2.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 학생이름으로 학생정보 조회
//	public void studentNameView() {
//
//		Connection conn = null;
//		Statement stat = null;
//		ResultSet rs = null;
//		DBUtil util = new DBUtil();
//		System.out.println("교육생 정보를 조회합니다.");
//		System.out.println("조회할 교육생의 이름을 입력해주세요.");
//		try {
//			// 연결
//			// conn = util.open("", "project", "java1234");
//			conn = util.open();
//			stat = conn.createStatement();
//			// 특정학생 번호 받기
//			System.out.println("============================");	
//			System.out.print("교육생이름 입력 : ");
//			String studentName = scan.nextLine();
//			System.out.println("============================");	
//			String sql = String.format(
//					"select student_name, student_ssn, student_tel, major from tblStudent where student_name = '%s'",
//					studentName);
//			rs = stat.executeQuery(sql);
//			System.out.println("[교육생명]\t     [주민등록번호]\t       [전화번호]\t        [전공여부]");
//			int cnt = 0;
//			while (rs.next()) {
//				cnt++;
//				if (cnt >= 0) {
//					System.out.printf("%s\t     ", rs.getString(1));
//					System.out.printf("%s    ", rs.getString(2));
//					System.out.printf("%s        ", rs.getString(3));
//					System.out.printf("%s\r\n", rs.getString(4));
//
//				}
//
//			}
//			if (cnt == 0) {
//				System.out.println("============================");	
//				System.out.println("잘못된 정보입니다. 다시 입력해주세요.");
//				System.out.println("============================");	
//				studentNameView();
//			}
//			rs.close();
//			stat.close();
//			conn.close();
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}

//	// 학생전화번호로 학생정보검색
//	public void studentTelView() {
//		Connection conn = null;
//		Statement stat = null;
//		ResultSet rs = null;
//		DBUtil util = new DBUtil();
//		System.out.println("교육생 정보를 조회합니다.");
//		System.out.println("조회할 교육생의 전화번호를 입력해주세요.");
//		try {
//			// 연결
//			// conn = util.open("", "project", "java1234");
//			conn = util.open();
//			stat = conn.createStatement();
//			// 특정학생 번호 받기
//			System.out.println("============================");	
//			System.out.print("교육생전화번호 입력 : ");
//			String studenttel = scan.nextLine();
//			System.out.println("============================");	
//			String sql = String.format(
//					"select student_name, student_ssn, student_tel, major from tblStudent where student_tel = '%s'",
//					studenttel);
//			rs = stat.executeQuery(sql);
//
//			System.out.println("[교육생명]\t     [주민등록번호]\t       [전화번호]\t        [전공여부]");
//			int cnt = 0;
//			while (rs.next()) {
//				cnt++;
//				if (cnt >= 0) {
//					System.out.printf("%s\t     ", rs.getString(1));
//					System.out.printf("%s    ", rs.getString(2));
//					System.out.printf("%s        ", rs.getString(3));
//					System.out.printf("%s\r\n", rs.getString(4));
//
//				}
//
//			}
//			if (cnt == 0) {
//				System.out.println("============================");	
//				System.out.println("잘못된 정보입니다. 다시 입력해주세요.");
//				System.out.println("============================");	
//				studentTelView();
//			}
//
//			rs.close();
//			stat.close();
//			conn.close();
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}

}
// 동아리 가입관리
package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.test.student.DBUtil;
/**
 * 
 * @author 홍준표
 *
 */
public class Proc191 {
	// 필요한 객체 생성
	Connection conn = null;
	Statement stat = null;
	ResultSet rs = null;
	DBUtil util = new DBUtil();
	Scanner scan = new Scanner(System.in);
	private static int j = 0;
	private static int c = 1;
	private int listsize = 0;
	/**
	 * 동아리 가입관리
	 */
	public void pr() {
			
		 try {
	    	  // 3조 SQL 연결
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	         
	         // select문 삽입
	         String sql = "select  s.student_name,g.state_study_group,g.seq_study_group from tblRegistCourse rc inner join tblStudent s on s.seq_student = rc.seq_student\r\n" + 
	         		" inner join tblStudyGroup g on g.seq_regist_course = rc.seq_regist_course order by g.seq_study_group";
	         rs = stat.executeQuery(sql);
	         
	         // select문 마지막행까지 반복
// 이전페이지 구현---------------------------------------------------------
	         
//	         ArrayList 선언
	       ArrayList<String> list = new ArrayList<String>();
	         
	       // list 통제용 int 선언 및 초기화
	       	int con = 0;
	       String g= "";
	       System.out.println("----------------------------");
	         System.out.println("[동아리 가입신청 현황]");
	         System.out.println();
	         while(rs.next()) {
	        	
	        	 // list에 출력 원하는 순서대로 값을 넣음
	        	 g = rs.getString(3) +". "+ rs.getString(1) + "\t" + rs.getString(2);
	        	 list.add(g);
	        
	         }
	         
	   
	         
	         
	         
	         
	         String q = "";
	         // 10으로 나눈 페이지 수
	         listsize = list.size()/10;
	         q += listsize;
	       
	         
	         for (int i=0+j; i<10+j; i++) {
	        	 
	        	 try {
	        		 System.out.println(list.get(i));
				} catch (Exception e) {
					// TODO: handle exception
				}
	         }
	         
	         System.out.println();
	         System.out.println("----------------------------");
	         System.out.printf("페이지 : %s/%s",c,q);      
	        
	         System.out.println();
//	          백업용 주석
//	         while(rs.next()) {
//	           System.out.print(rs.getString(3));
//	           System.out.print(". ");
//	           System.out.print(rs.getString(1));
//	           System.out.print("\t ");
//	           System.out.println(rs.getString(2));
//	        	 
//	         }


 // 이전페이지 구현----------------------------------------------------------------------  
	         
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println(e);
	      }
		 System.out.println("----------------------------");
		 System.out.println("1. 이전 페이지");
		 System.out.println("2. 다음 페이지");
		 System.out.println("3. 첫 페이지");
		 System.out.println("4. 마지막 페이지");
		 System.out.println("5. 가입변경");
		 System.out.println("6. 이전화면");
		 System.out.println("----------------------------");
		 System.out.print("선택(번호) : ");
		 String input = scan.nextLine();
		 if(input.equals("6")){
			 DongariOutput o = new DongariOutput();
			 o.out();
		 }else if(input.equals("1")) {
			 // 이전 페이지
			 j -=10; c-=1;
			 Proc191 pr = new Proc191();
			 pr.pr();
		 }else if(input.equals("2")) {
			 // 다음 페이지
			 j +=10; c+=1;
			 Proc191 pr = new Proc191();
			 pr.pr();
		 } else if(input.equals("3")) {
			 // 첫 페이지
			 j =0; c=1;
			 Proc191 pr = new Proc191();
			 pr.pr();
		 }else if(input.equals("4")) {
			 // 마지막 페이지
			 j =0; c = listsize;
			 j +=(10*listsize);
			 
			 Proc191 pr = new Proc191();
			 pr.pr();
		 }else if(input.equals("5")) {
			 
		 
		 
		//--------------------------------------------------------------------
		 	System.out.print("가입을 변경하시겠습니까?(y/n) : ");
		 	String t = scan.nextLine();
		 	if(t.equals("y")) {
			System.out.print("가입상태를 변경할 번호 : ");
			String num = scan.nextLine();
			
			
			System.out.print("변경할 가입기준 : ");
			String n = scan.nextLine();
			// 구현부
	try {
				
				// 객체 생성
				Connection conn = null;
				CallableStatement stat = null;
				DBUtil util = new DBUtil();
				
				// 3조 연결
				conn = util.open("211.63.89.47","project","java1234");
				
				// 컬럼 수만큼 = ?
				String sql ="{call proc191(?,?)}";
				stat = conn.prepareCall(sql);
				
				int z = Integer.parseInt(num);
				
				stat.setString(2, n);
				stat.setInt(1,z);
				// select 에서 Update
				stat.executeUpdate();
			
				
				// 자원 닫기
				stat.close();
				conn.close();
				
			System.out.println("가입상태 변경이 완료되었습니다.");
			
			//오류 발생
			} catch (Exception e) {
			
				System.out.println(e);
			}
	DongariOutput o = new DongariOutput();
	o.out();
	}else if(t.equals("n")){
		DongariOutput o = new DongariOutput();
		o.out();
	}
		 	
		 }else {
			 System.out.println("잘못 입력 하셨습니다.");
			 System.out.println("계속 하시려면 엔터를 누르세요...");
			 String enter = scan.nextLine();
			 DongariOutput o = new DongariOutput();
			 o.out();
		 }
}
}
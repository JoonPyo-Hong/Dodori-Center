package com.test.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

//import com.test.main.DBUtil;
/**
 * 
 * @author lllss
 *
 */
public class Attendence {

	Scanner scan = new Scanner(System.in);

	/**
	 * 출석조회 메뉴
	 *  
	 */
	public void attendenceAdmin() {

		boolean roof = true;
		while (roof) {
			System.out.println("============================");	
			System.out.println("1. 과정별 출석조회 ");
			System.out.println("2. 교육생별 출석조회 ");
			System.out.println("3. 기간별 출석조회");
			System.out.println("4. 이전화면");
			System.out.println("============================");	
			System.out.print("선택(번호) : ");
			String input = scan.nextLine();
			System.out.println("============================");			
			System.out.println();

			// 과정별 출석조회
			if (input.equals("1")) {
				attendenceCourse();
				// 학생별 출석조회
			} else if (input.equals("2")) {
				attendenceStudent();
				// 기간별 출석조회
			} else if (input.equals("3")) {
				attendenceDate();
				// 이전화면
			} else if (input.equals("4")) {
				
				//roof = false;
				break;

			}

		}

	}
/**
 * 기간별 출석조회
 * 
 */
	public void attendenceDate() {
		// 기간별 출석조회
		// 연결객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {
			// 연결
			conn = util.open();
			//conn = util.open("", "project", "java1234");
			stat = conn.createStatement();
			// 기간별 조회할 날짜 입력
			System.out.print("시작 년월일 입력(yyyy-mm-dd) : ");
			String startDate = scan.nextLine();
			System.out.print("끝 년월일 입력(yyyy-mm-dd) : ");
			String endDate = scan.nextLine();
			//시작년월일 입력~ 끝 년월일 입력하여 사이의 값 출력
			String sql = String.format("select * from vwAttendence101 where 출결일 between '%s' and '%s' order by 출결일",
					startDate, endDate);

			rs = stat.executeQuery(sql);
			System.out.println();
			System.out.println(startDate + " ~ "+ endDate);
			System.out.println();
			System.out.println("[과정번호]\t\t[출결일]\t\t[교육생명]\t[근태]\t[과정명]");

			while (rs.next()) {

				System.out.printf("%s\t\t", rs.getString("과정번호"));
				System.out.printf("%s\t", rs.getString("출결일"));
				System.out.printf("%s\t", rs.getString("교육생명"));
				System.out.printf("%s\t", rs.getString("근태"));
				System.out.printf("%s\t\r\n", rs.getString("과정명"));

			}
			
			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * 교육생별 출석조회
	 * 
	 */
	//교육생별 출석조회
	public void attendenceStudent() {
		// 연결객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
	

		try {
			// 연결
			conn = util.open();
			//conn = util.open("", "project", "java1234");
			stat = conn.createStatement();
			// 특정 교육생 선택
			System.out.println("============================");			
			System.out.print("교육생선택(번호) : ");
			String input = scan.nextLine();
			System.out.println("============================");			
			String sql = String.format("select * from vwAttendence101 where 교육생번호 = %s", input);
			rs = stat.executeQuery(sql);
			System.out.println("[교육생명]\t[과정번호]\t[출결일]\t\t[근태]\t[과정명]");
			
			while (rs.next()) {

				System.out.printf("%s\t",rs.getString("교육생명"));
				System.out.printf("%s\t", rs.getString("과정번호"));
				System.out.printf("%s\t", rs.getString("출결일"));
				System.out.printf("%s\t", rs.getString("근태"));
				System.out.printf("%s\t\r\n", rs.getString("과정명"));

			}
			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * 과정별 출석조회
	 * 
	 */
	//과정별 출석조회
	public void attendenceCourse() {
		Score sc = new Score();
		// 전체 개설과정 출력
		sc.printOpenCourse();
		// 연결객체 생성
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {
			// 연결
			conn = util.open();
			//conn = util.open("", "project", "java1234");
			stat = conn.createStatement();

			// 특정과정 선택
			System.out.println("============================");			
			System.out.print("과정선택(번호) : ");
			String input = scan.nextLine();
			System.out.println("============================");			
			
			String sql = String.format("select * from vwAttendence101 where 과정번호 = %s", input);
			rs = stat.executeQuery(sql);


			System.out.println("[과정번호]\t[출결일]\t[교육생명]\t[근태]\t[과정명]");
			while (rs.next()) {
				
				System.out.printf("%s\t",rs.getString("과정번호"));				
				System.out.printf("%s\t", rs.getString("출결일"));
				System.out.printf("%s\t", rs.getString("교육생명"));
				System.out.printf("%s\t", rs.getString("근태"));
				System.out.printf("%s\r\n", rs.getString("과정명"));
				
			}
			rs.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

package com.test.admin;

import java.lang.Thread.State;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import oracle.jdbc.OracleTypes;
/**
 * 
 * @author 조윤경
 *
 */
public class Proc66 {

	Scanner scan = new Scanner(System.in);

	/**
	 * 
	 */
	public void printTeacherMenu() {

		while (true) {
			System.out.println("\t\t\t\t교사 정보 관리");
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 교사 정보 보기");
			System.out.println("\t\t\t\t2. 교사 정보 입력");
			System.out.println("\t\t\t\t3. 교사 정보 수정");
			System.out.println("\t\t\t\t4. 교사 정보 삭제");
			System.out.println("\t\t\t\t5. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t입력: ");
			String select = scan.nextLine();

			if (select.equals("1")) {
				printTeacherInfo();

			} else if (select.equals("2")) {
				// 입력
				insertTeacher();
			} else if (select.equals("3")) {
				// 수정
				updateTeacher();
			} else if (select.equals("4")) {
				// 삭제
				deleteTeacher();
			} else if (select.equals("5")) {
				break;
			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}
		}
	}

	public void insertTeacher() {

		while (true) {
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 교사 기초 정보 입력");
			System.out.println("\t\t\t\t2. 강의 가능 과목 입력");

			System.out.println("\t\t\t\t3. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("입력: ");
			String select = scan.nextLine();

			if (select.equals("1")) { // 1. 교사 기초 정보 입력
				insertTeacherInfo();

			} else if (select.equals("2")) { // 2. 강의 가능 과목 입력
				m1();

			} else if (select.equals("3")) {
				break;
			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}
		} // while

	}
	//=================================================================
	private void m1() {
		// 입력
		System.out.print("교사를 추가하시겠습니까?(y/n) : ");
		String a1 = scan.nextLine();
		if(a1.equals("y")) {
		System.out.print("이름 : ");
		String a2 = scan.nextLine();
		System.out.print("주민번호 : ");
		String a3 = scan.nextLine();
		System.out.print("전화번호 : ");
		String a4 = scan.nextLine();
		System.out.println();
		out();
		System.out.println();
		System.out.print("강의 가능한 번호(숫자) : ");
		String a5 = scan.nextLine();
		//수정
		try {
			Connection conn = null;
			CallableStatement stat = null;
			DBUtil util = new DBUtil();
			
				
			int t = Integer.parseInt(a5);
			// 3조 연결
			conn = util.open("211.63.89.47","project","java1234");
			
			// 컬럼 수만큼 = ?
			String sql ="{call proc00000003(?,?,?,?)}";
			stat = conn.prepareCall(sql);
	
			
			stat.setString(1,a2);
			stat.setString(2,a3);
			stat.setString(3,a4);
			stat.setInt(4,t);
			
		
			
			
			stat.execute();
			// 자원 닫기
			stat.close();
			conn.close();
			System.out.println("입력이 완료되었습니다");
			
			
			}
		
		//오류 발생
		 catch (Exception e) {
		
			System.out.println(e);
	
		 }
		}else if(a1.equals("n")){
			Proc66 sg = new Proc66();
			sg.printTeacherMenu();
		}
		Proc66 sg = new Proc66();
		sg.printTeacherMenu();
		
	}
	
	private void out() {
		// 강의 목록 출력문
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();
		 try {
	         conn = util.open("211.63.89.47","project","java1234");
	         stat = conn.createStatement();
	    
	       
	         // select문 삽입
	         String sql = "select seq_subject,subject_name from tblSubject";
	         rs = stat.executeQuery(sql);
	         System.out.println("[강의목록]");
	         // select문 마지막행까지 반복
	       
	        	  while(rs.next()) {
	        		  System.out.print(rs.getString(1));
	        		  System.out.print(". ");
	        		  System.out.println(rs.getString(2));
	 	         }
	         
	         // 자원 닫기
	         stat.close();
	         conn.close();
	        
	         // 예외 처리
	      	} catch (Exception e) {
	         System.out.println(e);
	      	}
		
	}

//==================================================================

	public void updateTeacher() {

		while (true) {

			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 교사 기초 정보 수정");

			System.out.println("\t\t\t\t2. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t입력: ");
			String select = scan.nextLine();

			if (select.equals("1")) { // 1. 교사 기초 정보 입력
				updateTeacherInfo();

			} else if (select.equals("2")) {
				break;
			} else {
				System.out.println("잘못 입력 하셨습니다.");
			}
		} // while

	}

	/**
	 * 
	 */
	public void deleteTeacher() {

		while (true) {

			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 교사 기초 정보 삭제");
			System.out.println("\t\t\t\t2. 강의 가능 과목 삭제");

			System.out.println("\t\t\t\t3. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("입력: ");
			String select = scan.nextLine();

			if (select.equals("1")) { // 1. 교사 기초 정보 입력
				deleteTeacherInfo();

			} else if (select.equals("2")) { // 2. 강의 가능 과목 입력

			} else if (select.equals("3")) {
				break;
			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}
		} // while

	}

	/**
	 * 새로운 교사의 이름, 주민번호, 전화번호를 입력받아 데이터베이스에 업데이트시켜주는 메서드
	 */
	public void insertTeacherInfo() {

		Connection conn = null;
		Statement stat = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t교사이름을 입력하세요: ");
			String teacher_name = scan.nextLine();
			System.out.print("\t\t\t\t교사의 주민등록번호를 입력하세요: ");
			String teacher_ssn = scan.nextLine();
			System.out.print("\t\t\t\t교사의 전화번호를 입력하세요: ");
			String teacher_tel = scan.nextLine();

			String sql = String.format("insert into tblTeacher values(seq_teacher.nextVal, '%s', '%s', '%s')",
					teacher_name, teacher_ssn, teacher_tel);

			stat.executeUpdate(sql);

			System.out.printf("\t\t\t\t이름: [%s], 주민번호: [%s], 전화번호: [%s]를 입력하시겠습니까?(y/n): ", teacher_name, teacher_ssn,
					teacher_tel);
			String answer_yn = scan.nextLine();

			while (true) {
				if (answer_yn.equals("y")) {

					System.out.println("\t\t\t\t입력이 완료되었습니다.");
					conn.commit();
					printTeacherInfo();
					break;

				} else if (answer_yn.equals("n")) {
					System.out.println("\t\t\t\t입력이 취소되었습니다.");
					conn.rollback();
					break;

				} else {
					System.out.println("\t\t\t\t잘못 입력하셨습니다.");
				}

			}

			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

	}// insertTeacherInfo()
	
	
	/**
	 * 교사의 이름, 주민번호, 전화번호 수정
	 */
	public void updateTeacherInfo() { // 3. 기존 교사정보 수정하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {
			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> seq_teacher_list = new ArrayList<String>();
			ArrayList<String> teacher_name_list = new ArrayList<String>();
			ArrayList<String> teacher_ssn_list = new ArrayList<String>();
			ArrayList<String> teacher_tel_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select seq_teacher, teacher_name, teacher_ssn, teacher_tel from tblTeacher";
			rs1 = stat.executeQuery(sql1);
			System.out.println("\t\t\t\t[교사목록]");
			int num = 1;
			System.out.println("\t\t\t\t교사명\t\t주민번호\t\t전화번호");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %s\t\t\t\t%s\t\t%s\n", num, rs1.getString(2), rs1.getString(3),
						rs1.getString(4));
				seq_teacher_list.add(rs1.getString(1));
				teacher_name_list.add(rs1.getString(2));
				teacher_ssn_list.add(rs1.getString(3));
				teacher_tel_list.add(rs1.getString(4));
				// 어레이 리스트에 이름과 기간을 각각 저장

				num++;
			}

			while (true) {// 뒤로가기
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t수정할 교사의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_course = scan.nextLine();
				if (select_course.equals("b")) {
					break;
				}

				int select_teacher_num = Integer.parseInt(select_course) - 1;
				String select_teacher_seq = seq_teacher_list.get(select_teacher_num);

				// 교사 시퀀스 번호

				while (true) {// 뒤로가기 > 번호입력 창
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t1. 교사 이름 수정");
					System.out.println("\t\t\t\t2. 교사 주민번호 수정");
					System.out.println("\t\t\t\t3. 교사 전화번호 수정");
					System.out.println("\t\t\t\t4. 뒤로가기");
					System.out.println("\t\t\t\t================================");
					System.out.print("\t\t\t\t입력: ");
					String select_update = scan.nextLine();
					// 이름을 수정할지 기간을 수정할지 선택

					while (true) {
						if (select_update.equals("1")) { // 과정 이름 수정 선택

							// 새로 수정할 이름을 입력받음
							System.out.print("\t\t\t\t새로 수정할 교사의 이름을 입력해 주세요.: ");
							String new_teacher_name = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblTeacher set teacher_name = '%s' where seq_teacher = %s",
									new_teacher_name, select_teacher_seq);

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t이름[%s]를 [%s]로 변경하시겠습니까?(y/n): ",
										teacher_name_list.get(select_teacher_num), new_teacher_name);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t교사 [%s]의 이름이 [%s]로 변경 완료되었습니다.\n",
											teacher_name_list.get(select_teacher_num), new_teacher_name);
									printTeacherInfo();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t교사이름 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							}

						} else if (select_update.equals("2")) {

							System.out.print("\t\t\t\t새로 수정할 교사의 주민번호를 입력해 주세요.: ");
							String new_teacher_ssn = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblTeacher set teacher_ssn = '%s' where seq_teacher = %s", new_teacher_ssn,
									select_teacher_seq);

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t주민번호[%s]를 [%s]로 변경하시겠습니까?(y/n): ",
										teacher_ssn_list.get(select_teacher_num), new_teacher_ssn);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t교사 [%s]의 주민번호가 [%s]로 변경 완료되었습니다.\n",
											teacher_ssn_list.get(select_teacher_num), new_teacher_ssn);
									printTeacherInfo();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t교사 주민등록번호 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							} // 확인절차

						} else if (select_update.equals("3")) {

							System.out.print("\t\t\t\t새로 수정할 교사의 전화번호를 입력해 주세요.: ");
							String new_teacher_tel = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblTeacher set teacher_tel = '%s' where seq_teacher = %s", new_teacher_tel,
									select_teacher_seq);

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t전화번호[%s]를 [%s]로 변경하시겠습니까?(y/n): ",
										teacher_tel_list.get(select_teacher_num), new_teacher_tel);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t교사 [%s]의 전화번호가 [%s]로 변경 완료되었습니다.\n",
											teacher_tel_list.get(select_teacher_num), new_teacher_tel);
									printTeacherInfo();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t교사 전화번호 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							} // 확인절차

							break;// 확인절차이후 이름, 기간 선택창으로..

						} else if (select_update.equals("4")) {
							break;
						} else {
							System.out.println("\t\t\t\t잘못 입력하셨습니다.");
						}
						break;// 확인절차이후 이름, 기간 선택창으로..
					} // while
					break;
				}
			} // while
			rs1.close();
			stat.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// updateCourse()

	/**
	 * 기존 교사의 정보를 삭제하는 메서드
	 */
	public void deleteTeacherInfo() { // 4. 기존 교사 삭제하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {
			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> seq_teacher_list = new ArrayList<String>();
			ArrayList<String> teacher_name_list = new ArrayList<String>();
			ArrayList<String> teacher_ssn_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select seq_teacher, teacher_name, teacher_ssn, teacher_tel from tblTeacher";
			rs1 = stat.executeQuery(sql1);
			System.out.println("\t\t\t\t[교사목록]");
			int num = 1;
			System.out.println("\t\t\t\t교사명\t\t주민번호\t\t전화번호");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("%d. %s\t\t\t\t\t%s\n", num, rs1.getString(2), rs1.getString(3), rs1.getString(4));
				seq_teacher_list.add(rs1.getString(1));
				teacher_name_list.add(rs1.getString(2));
				teacher_ssn_list.add(rs1.getString(3));

				// 어레이 리스트에 이름과 기간을 각각 저장

				num++;
			}
			while (true) {

				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t삭제할 교사의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_course = scan.nextLine();
				if (select_course.equals("b")) {
					break;
				}

				int select_teacher_num = Integer.parseInt(select_course) - 1;
				String select_teacher_seq = seq_teacher_list.get(select_teacher_num);

				// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
				String sql2 = String.format(
						"update tblTeacher set teacher_name = teacher_name||'(삭제)' where seq_teacher = %s",
						select_teacher_seq);

				stat.executeUpdate(sql2);

				while (true) { // 입력할지 확인 절차

					System.out.printf("\t\t\t\t교사[%s]를 삭제하시겠습니까?(y/n): ", teacher_name_list.get(select_teacher_num));

					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t교사 [%s]가 삭제 되었습니다.\n", teacher_name_list.get(select_teacher_num));
						printTeacherInfo();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t교사 삭제 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}

			} // while

			stat.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// deleteCourse()

	/**
	 * 교사의 기초정보 출력   교사의 기초정보 출력  교사번호 입력   강의가능과목 + 배정된 개설과정/과목 출력
	 */
	public void printTeacherInfo() {
		Connection conn = null;
		Statement stat = null;
		CallableStatement stat2 = null;
		ResultSet rs = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();

			String sql = String
					.format("select seq_teacher,teacher_name, substr(teacher_ssn,8), teacher_tel from tblTeacher");

			rs = stat.executeQuery(sql);
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t[교사 목록]");
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t[교사번호]\t[교사이름]\t[비밀번호]\t[전화번호]");
			while (rs.next()) {
				System.out.printf("\t\t\t\t%s\t\t%s\t\t%s\t\t%s\n", rs.getString(1), rs.getString(2), rs.getString(3),
						rs.getString(4));

			}
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 강의 가능 과목 보기");
			System.out.println("\t\t\t\t2. 배정된 개설 과정 보기");
			System.out.println("\t\t\t\t3. 배정된 개설 과목 보기");
			System.out.println("\t\t\t\t4. 뒤로가기");
			System.out.print("\t\t\t\t입력: ");
			String select_num = scan.nextLine();

			while (true) {

				System.out.print("\t\t\t\t교사 번호를 입력하세요: ");
				String select_teacher_num = scan.nextLine();

				int teacher_num = Integer.parseInt(select_teacher_num);

				if (select_num.equals("1")) { // 1. 강의 가능 과목 보기

//					ResultSet rs1 = null;

					String sql1 = "{ call proc67_01_2_2(?, ?) }";
					stat2 = conn.prepareCall(sql1);

					stat2.setString(1, teacher_num + "");
					stat2.registerOutParameter(2, OracleTypes.CURSOR);

					stat2.executeQuery();

					rs = (ResultSet) stat2.getObject(2);
					int count = 1;
					System.out.println();
					System.out.println("\t\t\t\t================================");
					while (rs.next()) {

						System.out.printf("\t\t\t\t%d. %s\n", count, rs.getString(1));
						count++;

					}
					System.out.println("\t\t\t\t================================");

					break;

				} else if (select_num.equals("2")) { // 2. 배정된 개설 과정 보기

					String sql2 = "{ call proc67_02_2(?, ?) }";
					stat2 = conn.prepareCall(sql2);

					stat2.setString(1, teacher_num + "");
					stat2.registerOutParameter(2, OracleTypes.CURSOR);

					stat2.executeQuery();

					rs = (ResultSet) stat2.getObject(2);
					String date1 = "";
					String date2 = "";

					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t배정된 개설 과정");
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t[과정명]\t\t\t\t[과정기간]\t\t[강의실]\t\t[강의진행여부]");
					System.out.println("\t\t\t\t================================");
					while (rs.next()) {
						date1 = rs.getString(3).replace("00:00:00", "");
						date2 = rs.getString(4).replace("00:00:00", "");
						System.out.printf("\t\t\t\t%s\t\t\t\t%s~%s\t\t%20s\t\t%20s\n", rs.getString(2), date1, date2,
								rs.getString(5), rs.getString(6));

					}

					break;

				} else if (select_num.equals("3")) { // 3. 배정된 개설 과목 보기

					String sql2 = "{ call proc67_02_1(?, ?) }";
					stat2 = conn.prepareCall(sql2);

					stat2.setString(1, teacher_num + "");
					stat2.registerOutParameter(2, OracleTypes.CURSOR);

					stat2.executeQuery();

					rs = (ResultSet) stat2.getObject(2);
					String date1 = "";
					String date2 = "";

					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t배정된 개설 과목");
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t[과목명]\t\t[과목기간]\t\t[교재명]");
					System.out.println("\t\t\t\t================================");
					while (rs.next()) {
						date1 = rs.getString(4).replace("00:00:00", "");
						date2 = rs.getString(5).replace("00:00:00", "");
						System.out.printf("\t\t\t\t%s\t\t%s~%s\t\t%s\n", rs.getString(3), date1, date2,
								rs.getString(6));

					}

					break;

				} else {
					System.out.println("\t\t\t\t잘못 입력하셨습니다.");

				}

			}

			rs.close();

			stat2.close();
			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();

		}

	}
}

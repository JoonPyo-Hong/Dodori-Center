package com.test.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.test.main.Main;

public class ManagerLogin {

	Scanner scan = new Scanner(System.in);
	
	
	public void login() {
		Scanner scan = new Scanner(System.in);

	
		boolean flag = true;
		
		while (flag) {
		
		try {

			Connection conn = null;
			Statement stat = null;
			DBUtil util = new DBUtil();

			//conn = util.open();
			conn = util.open("211.63.89.47","project","java1234");
			stat = conn.createStatement();

			ResultSet rs = null;

				int control = 0;


					String sql = "select * from tblManager";

					rs = stat.executeQuery(sql);
					String manager = "";
					System.out.println("\t\t\t\t========================");
					System.out.print("\t\t\t\tID: ");
					String id2 = scan.nextLine();

					System.out.print("\t\t\t\tPW: ");
					String pass2 = scan.nextLine();

					System.out.println("\t\t\t\t========================");
					
					while (rs.next()) {
						if (id2.equals(rs.getString(2)) && pass2.equals(rs.getString(3))) {
							manager = rs.getString(2);
							control++;
						}

					}

					if (control == 1) {
						System.out.println();
						System.out.printf("\t\t\t\t♩♪♬[%s]님 환영합니다!♬♪♩\n",manager);
						break;

					} else {
						System.out.println();
						
						System.out.println("\t\t\t\t로그인 실패");

					}

				rs.close();
				stat.close();
				conn.close();
				
			}
			

		 catch (Exception e) {
			e.printStackTrace();
		}
		}

	}//login
	
	
	public void printManagerMenu() {
		while(true) {
		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t\t  관리자 모드");
		System.out.println("\t\t\t\t================================");
		System.out.println("\t\t\t\t1. 기초정보 관리");
		System.out.println("\t\t\t\t2. 교사계정 관리");
		System.out.println("\t\t\t\t3. 개설과정 관리");
		System.out.println("\t\t\t\t4. 개설과목 관리");
		System.out.println("\t\t\t\t5. 교육생 관리");
		System.out.println("\t\t\t\t6. 시험 관리 및 성적 조회");
		System.out.println("\t\t\t\t7. 출결 관리 및 출결 조회");
		System.out.println("\t\t\t\t8. 동아리 관리");
		System.out.println("\t\t\t\t9. 로그아웃");
		System.out.println("\t\t\t\t10. 종료");
		System.out.println("\t\t\t\t================================");
		
		System.out.println();
		
		System.out.println("\t\t\t\t================================");	
		System.out.print("\t\t\t\t입력: ");
		String select = scan.nextLine();
		System.out.println("\t\t\t\t================================");	
		
		if(select.equals("1")) { //1. 기초정보 관리
			
			Proc59 p59 = new Proc59();
			p59.printMenu();
			
			
		}else if(select.equals("2")) { //2. 교사계정 관리
			Proc66 p66 = new Proc66();
			p66.printTeacherMenu();
			
			
			
		}else if(select.equals("3")) { //3. 개설과정 관리
			proc69 p69 = new proc69();
			p69.openCourseMain();
			
			
		}else if(select.equals("4")) { //4. 개설과목 관리
			proc77 p77 = new proc77();
			p77.openSubjcetMain();
			
			
			
			
		}else if(select.equals("5")) { //5. 교육생 관리
			StudentAdmin sadmin = new StudentAdmin();
			sadmin.studentMain();
			
		}else if(select.equals("6")) { //6. 시험 관리 및 성적 조회
			Score sc = new Score();
			sc.scoreAdmin();
		}else if(select.equals("7")) { //7. 출결 관리 및 출결 조회
			Attendence atten = new Attendence();
			atten.attendenceAdmin();
			
		}else if(select.equals("8")) { //8. 동아리 관리
			DongariOutput o = new DongariOutput();
			o.out();
		}else if(select.equals("9")) { //9. 로그아웃
			
			Main main = new Main();
			main.m();
			
			
		}else if(select.equals("10")) { //10. 종료
		
		}else {
			
			System.out.println("잘못 입력 하셨습니다.");
			ManagerLogin ml = new ManagerLogin();
			ml.printManagerMenu();
			
		}
		
		
		}
		
		
		
		
	}
	
	
	
	

}//class

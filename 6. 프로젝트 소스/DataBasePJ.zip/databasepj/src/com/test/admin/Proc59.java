package com.test.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.test.main.Main;
/**
 * 
 * @author 조윤경
 *
 */
public class Proc59 {

	Scanner scan = new Scanner(System.in);

	// 기초정보 관리
	/**
	 * 기초정보 관리기능을 실행 시키는 메소드
	 */
	public void printMenu() {
		while (true) {
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t\t  기초정보 관리");
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 과정 정보 관리");
			System.out.println("\t\t\t\t2. 과목 정보 관리");
			System.out.println("\t\t\t\t3. 강의실 정보 관리");
			System.out.println("\t\t\t\t4. 교재 정보 관리");
			System.out.println("\t\t\t\t5. 뒤로가기");
			System.out.println("\t\t\t\t================================");

			System.out.print("\t\t\t\t입력: ");

			String select = scan.nextLine();
			

			if (select.equals("1")) {
				printCourseMenu();

			} else if (select.equals("2")) {
				printSubjectMenu();

			} else if (select.equals("3")) {
				printClassroomMenu();

			} else if (select.equals("4")) {
				printBookMenu();

			} else if (select.equals("5")) {
				break;
				
				
			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}
		}

	}

// 과정정보===============================================================================================

	/**
	 * 기초 과정 정보를 호출하는 메소드
	 */
	private void printCourseMenu() {

		while (true) {
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 과정 목록 보기");
			System.out.println("\t\t\t\t2. 새 과정 입력하기");
			System.out.println("\t\t\t\t3. 기존 과정 수정하기");
			System.out.println("\t\t\t\t4. 기존 과정 폐강하기");
			System.out.println("\t\t\t\t5. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t입력: ");
			
			String select = scan.nextLine();

			if (select.equals("1")) {
				printCourse();

			} else if (select.equals("2")) {
				insertCourse();
			} else if (select.equals("3")) {
				updateCourse();

			} else if (select.equals("4")) {
				deleteCourse();
			} else if (select.equals("5")) { // back
//			ManagerLogin ml = new ManagerLogin();
//			
//			ml.printManagerMenu();
				break;

			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}

		}

	}

	/**
	 * 데이터베이스의 기초과정 테이블에서 과정 정보를 불러와 목록을 출력하는 메소드
	 */
	private void printCourse() {// 1. 과정 목록 보기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();

			String sql1 = "select course_name, course_period from tblCourse";
			rs1 = stat.executeQuery(sql1);
			System.out.println("\t\t\t\t================================================================");
			System.out.printf("\t\t\t\t%30s\n","[과정목록]");
			System.out.println("\t\t\t\t================================================================");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","과정명","과정기간");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력
			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));

				num++;
			}

			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();

		}
	}
	
	
	/**
	 * 새로 입력할 과정의 이름과 기간을 입력받아 데이터베이스에 입력하는 메소드
	 */
	private void insertCourse() { // 2. 새 과정 입력하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			while (true) {
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t새로 입력할 과정 이름(뒤로가기>b): ");
				String new_name = scan.nextLine();
				if (new_name.equals("b")) {
					break;
				}

				System.out.print("\t\t\t\t새로 입력할 과정 기간(뒤로가기>b): ");
				String new_period = scan.nextLine();
				if (new_period.equals("b")) {

					insertCourse();

				}
				System.out.println("\t\t\t\t================================");

				// 새로 입력하는 과정의 이름과 기간을 입력받음

				String sql1 = String.format("insert into tblCourse values (seq_course.nextVal, '%s', %s)", new_name,
						new_period);
				// 입력할 과정을 sql문으로 날려줌

				rs1 = stat.executeQuery(sql1);

				while (true) { // 입력할지 확인 절차
					System.out.printf("\t\t\t\t[%s] 과정 (기간: %s일) 을 새로 입력하시겠습니까?(y/n): ", new_name, new_period);
					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t새로운 과정 [%s] 의 입력이 완료되었습니다.\n", new_name);
						printCourse();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t새로운 과정 입력이 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}

				stat.close();
				conn.close();
			} // while
		} catch (Exception e) {

		}

	}// insertCourse()

	/**
	 * 기존과정의 이름과 기간을 수정해주어 데이터베이스에 업데이트 시켜주는 메소드
	 */
	private void updateCourse() { // 3. 기존 과정 수정하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {
			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> course_name_list = new ArrayList<String>();
			ArrayList<String> course_period_list = new ArrayList<String>();
			
			
			
			
			
			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select course_name, course_period from tblCourse";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[과정목록]");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","과정명","과정기간");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {
				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				course_name_list.add(rs1.getString(1));
				course_period_list.add(rs1.getString(2));
				// 어레이 리스트에 이름과 기간을 각각 저장

				num++;
			}

			while (true) {// 뒤로가기
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t수정할 과정의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_course = scan.nextLine();
				if (select_course.equals("b")) {
					break;
				}

				int select_course_num = Integer.parseInt(select_course) - 1;// 어레이 리스트 번호

				while (true) {// 뒤로가기 > 번호입력 창
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t1. 과정 이름 수정");
					System.out.println("\t\t\t\t2. 과정 기간 수정");
					System.out.println("\t\t\t\t3. 뒤로가기");
					System.out.println("\t\t\t\t================================");
					System.out.print("\t\t\t\t입력: ");
					String select_update = scan.nextLine();
					// 이름을 수정할지 기간을 수정할지 선택

					while (true) {
						if (select_update.equals("1")) { // 과정 이름 수정 선택

							// 새로 수정할 이름을 입력받음
							System.out.print("\t\t\t\t새로 수정할 과정의 이름을 입력해 주세요.: ");
							String new_course_name = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblCourse set course_name = '%s' where course_name = '%s' and course_period = %s",
									new_course_name, course_name_list.get(select_course_num),
									course_period_list.get(select_course_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t[%s]를 [%s]로 변경하시겠습니까?(y/n): ",
										course_name_list.get(select_course_num), new_course_name);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t과정 [%s]의 이름이 [%s]로 변경 완료되었습니다.\n",
											course_name_list.get(select_course_num), new_course_name);
									printCourse();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t과정이름 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							}

						} else if (select_update.equals("2")) {

							System.out.print("\t\t\t\t새로 수정할 과정의 기간을 입력해 주세요.: ");
							String new_course_period = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblCourse set course_period = %s where course_name = '%s' and course_period = %s",
									new_course_period, course_name_list.get(select_course_num),
									course_period_list.get(select_course_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t[%s]의 기간을 [%s]일로 변경하시겠습니까?(y/n): ",
										course_name_list.get(select_course_num), new_course_period);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t과정 [%s]의 기간이 [%s]일로 변경 완료되었습니다.\n",
											course_name_list.get(select_course_num), new_course_period);
									printCourse();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t과정가간 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							} // 확인절차

							break;// 확인절차이후 이름, 기간 선택창으로..

						} else if (select_update.equals("3")) {
							break;
						} else {
							System.out.println("\t\t\t\t잘못 입력하셨습니다.");
						}
						break;// 확인절차이후 이름, 기간 선택창으로..
					} // while
					break;
				}
			} // while
			rs1.close();
			stat.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// updateCourse()

	/**
	 * 삭제할 데이터의 번호를 받아서 이름에 (폐강)이라는 글자를 달아서 업데이트 시켜주는 메서드
	 */
	private void deleteCourse() { // 4. 기존 과정 폐강하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> course_name_list = new ArrayList<String>();
			ArrayList<String> course_period_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select course_name, course_period from tblCourse";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[과정목록]");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","과정명","과정기간");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				course_name_list.add(rs1.getString(1));
				course_period_list.add(rs1.getString(2));
				// 어레이 리스트에 이름을 저장

				num++;
			}
			while (true) {

				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t폐강할 과정의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_course = scan.nextLine();
				if (select_course.equals("b")) {
					break;
				}

				int select_course_num = Integer.parseInt(select_course) - 1;// 어레이 리스트 번호

				// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
				String sql2 = String.format(
						"update tblCourse set course_name = course_name||'(폐강)' where course_name = '%s' and course_period = %s",
						course_name_list.get(select_course_num), course_period_list.get(select_course_num));

				stat.executeUpdate(sql2);

				while (true) { // 입력할지 확인 절차

					System.out.printf("\t\t\t\t[%s]를 삭제하시겠습니까?(y/n): ", course_name_list.get(select_course_num));

					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t과정 [%s]이 삭제 되었습니다.\n", course_name_list.get(select_course_num));
						printCourse();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t과정 삭제 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}

			} // while

			stat.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// deleteCourse()

//과목정보==============================================================================================================

	/**
	 * 기초 과목 정보를 호출하는 메소드
	 */
	private void printSubjectMenu() {

		while (true) {
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 과목 목록 보기");
			System.out.println("\t\t\t\t2. 새 과목 입력하기");
			System.out.println("\t\t\t\t3. 기존 과목 수정하기");
			System.out.println("\t\t\t\t4. 기존 과목 폐강하기");
			System.out.println("\t\t\t\t5. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t입력: ");
			String select = scan.nextLine();

			if (select.equals("1")) {
				printSubject();

			} else if (select.equals("2")) {
				insertSubject();
			} else if (select.equals("3")) {
				updateSubject();

			} else if (select.equals("4")) {
				deleteSubject();
			} else if (select.equals("5")) {
				break;

			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}
		}
	}

	/**
	 * 데이터베이스의 기초과목 테이블에서 과목 정보를 불러와 목록을 출력하는 메소드
	 */
	private void printSubject() {// 1. 과목 목록 보기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select subject_name, subject_period from tblSubject";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[과목목록]");
			System.out.println("\t\t\t\t================================================================");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","과목명","과목기간");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력
			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));

				num++;
			}

			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

	/**
	 * 새로 입력할 과목의 이름과 기간을 입력받아 데이터베이스에 입력하는 메소드
	 */
	private void insertSubject() { // 2. 새 과목 입력하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);
			while (true) {
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t새로 입력할 과목 이름(뒤로가기>b): ");
				String new_name = scan.nextLine();
				if (new_name.equals("b")) {
					break;
				}
				System.out.print("\t\t\t\t새로 입력할 과목 기간(뒤로가기>b): ");
				String new_period = scan.nextLine();
				if (new_period.equals("b")) {
					insertSubject();

				}
				System.out.println("\t\t\t\t================================");

				// 새로 입력하는 과목의 이름과 기간을 입력받음

				String sql1 = String.format("insert into tblSubject values (seq_subject.nextVal, '%s', %s)", new_name,
						new_period);
				// 입력할 과정을 sql문으로 날려줌

				rs1 = stat.executeQuery(sql1);

				while (true) { // 입력할지 확인 절차
					System.out.printf("\t\t\t\t[%s] 과목 (기간: %s일) 을 새로 입력하시겠습니까?(y/n): ", new_name, new_period);
					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t새로운 과목 [%s] 의 입력이 완료되었습니다.\n", new_name);
						printSubject();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t새로운 과목 입력이 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}

				stat.close();
				conn.close();
			} // while
		} catch (Exception e) {

		}

	}// insertCourse()

	/**
	 * 기존과목의 이름과 기간을 수정해주어 데이터베이스에 업데이트 시켜주는 메소드
	 */
	public void updateSubject() { // 3. 기존 과목 수정하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {
			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> subject_name_list = new ArrayList<String>();
			ArrayList<String> subject_period_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select subject_name, subject_period from tblSubject";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[과목목록]");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","과목명","과목기간");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				subject_name_list.add(rs1.getString(1));
				subject_period_list.add(rs1.getString(2));
				// 어레이 리스트에 이름과 기간을 각각 저장

				num++;
			}

			while (true) {// 뒤로가기
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t수정할 과목의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_subject = scan.nextLine();
				if (select_subject.equals("b")) {
					break;
				}

				int select_subject_num = Integer.parseInt(select_subject) - 1;// 어레이 리스트 번호

				while (true) {// 뒤로가기 > 번호입력 창
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t1. 과목 이름 수정");
					System.out.println("\t\t\t\t2. 과목 기간 수정");
					System.out.println("\t\t\t\t3. 뒤로가기");
					System.out.println("\t\t\t\t================================");
					System.out.print("\t\t\t\t입력: ");
					String select_update = scan.nextLine();
					
					// 이름을 수정할지 기간을 수정할지 선택

					while (true) {
						if (select_update.equals("1")) { // 과정 이름 수정 선택

							// 새로 수정할 이름을 입력받음
							System.out.print("\t\t\t\t새로 수정할 과목의 이름을 입력해 주세요.");
							String new_subject_name = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblSubject set subject_name = '%s' where subject_name = '%s' and subject_period = %s",
									new_subject_name, subject_name_list.get(select_subject_num),
									subject_period_list.get(select_subject_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t[%s]를 [%s]로 변경하시겠습니까?(y/n): ",
										subject_name_list.get(select_subject_num), new_subject_name);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t과목 [%s]의 이름이 [%s]로 변경 완료되었습니다.\n",
											subject_name_list.get(select_subject_num), new_subject_name);
									printSubject();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t과목이름 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							}

						} else if (select_update.equals("2")) {

							System.out.print("\t\t\t\t새로 수정할 과목의 기간을 입력해 주세요.: ");
							String new_subject_period = scan.nextLine();

							// 기존의 과목이름, 기간이 같은 레코드의 과목이름을 변경
							String sql2 = String.format(
									"update tblSubject set subject_period = %s where subject_name = '%s' and subject_period = %s",
									new_subject_period, subject_name_list.get(select_subject_num),
									subject_period_list.get(select_subject_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t[%s]의 기간을 [%s]일로 변경하시겠습니까?(y/n): ",
										subject_name_list.get(select_subject_num), new_subject_period);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t과목 [%s]의 기간이 [%s]일로 변경 완료되었습니다.\n",
											subject_name_list.get(select_subject_num), new_subject_period);
									printSubject();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t과목기간 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}
							} // 확인절차

							break;// 확인절차 이후 이름, 기간 선택창,,,
						} else if (select_update.equals("3")) {
							break;// 확인절차 이후 이름, 기간 선택창,,,

						} else {
							System.out.println("\t\t\t\t잘못 입력하셨습니다.");
						}
						break;
					} // while
					break;

				}
			} // while

			rs1.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// updateSubject()

	/**
	 * 삭제할 데이터의 번호를 받아서 이름에 (폐강)이라는 글자를 달아서 업데이트 시켜주는 메서드
	 */
	private void deleteSubject() { // 4. 기존 과목 폐강하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> subject_name_list = new ArrayList<String>();
			ArrayList<String> subject_period_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select subject_name, subject_period from tblSubject";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[과목목록]");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","과목명","과목기간");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				subject_name_list.add(rs1.getString(1));
				subject_period_list.add(rs1.getString(2));
				// 어레이 리스트에 이름을 저장

				num++;
			}

			while (true) {
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t폐강할 과목의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_subject = scan.nextLine();
				if (select_subject.equals("b")) {
					break;
				}

				int select_subject_num = Integer.parseInt(select_subject) - 1;// 어레이 리스트 번호

				// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
				String sql2 = String.format(
						"update tblSubject set subject_name = subject_name||'(폐강)' where subject_name = '%s' and subject_period = %s",
						subject_name_list.get(select_subject_num), subject_period_list.get(select_subject_num));

				stat.executeUpdate(sql2);

				while (true) { // 입력할지 확인 절차

					System.out.printf("\t\t\t\t[%s]를 삭제하시겠습니까?(y/n): ", subject_name_list.get(select_subject_num));

					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t과목 [%s]이 삭제 되었습니다.\n", subject_name_list.get(select_subject_num));
						printSubject();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t과목 삭제 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}

			} // while
			stat.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}// deleteSubject()

//강의실정보=========================================================================================================

	/**
	 * 기초 강의실 정보를 호출하는 메소드
	 */
	private void printClassroomMenu() {

		while (true) {
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 강의실 목록 보기");
			System.out.println("\t\t\t\t2. 새 강의실 입력하기");
			System.out.println("\t\t\t\t3. 기존 강의실 수정하기");
			System.out.println("\t\t\t\t4. 기존 강의실 폐쇄하기");
			System.out.println("\t\t\t\t5. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t입력: ");
			String select = scan.nextLine();

			if (select.equals("1")) {
				printClassroom();

			} else if (select.equals("2")) {
				insertClassroom();
			} else if (select.equals("3")) {
				updateClassroom();

			} else if (select.equals("4")) {
				deleteClassroom();
			} else if (select.equals("5")) {
				break;

			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}
		}
	}

	/**
	 * 데이터베이스의 기초강의실 테이블에서 강의실 정보를 불러와 목록을 출력하는 메소드
	 */
	private void printClassroom() {// 1. 강의실 목록 보기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select classroom_name, classroom_capacity from tblClassroom";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[강의실목록]");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","강의실명","강의실정원");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력
			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				num++;
			}

			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

	/**
	 * 새로 입력할 강의실의 이름과 정원을 입력받아 데이터베이스에 입력하는 메소드
	 */
	private void insertClassroom() { // 2. 새 강의실 입력하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			while (true) {
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t새로 입력할 강의실 이름(뒤로가기>b): ");
				String new_name = scan.nextLine();
				if (new_name.equals("b")) {
					break;
				}

				System.out.print("\t\t\t\t새로 입력할 강의실 수용 정원(뒤로가기>b): ");
				String new_capacity = scan.nextLine();
				if (new_capacity.equals("b")) {
					insertClassroom();
				}
				System.out.println("\t\t\t\t================================");

				// 새로 입력하는 강의실의 이름과 정원을 입력받음

				String sql1 = String.format("insert into tblClassroom values (seq_classroom.nextVal, '%s', %s)",
						new_name, new_capacity);
				// 입력할 과정을 sql문으로 날려줌

				rs1 = stat.executeQuery(sql1);

				while (true) { // 입력할지 확인 절차
					System.out.printf("\t\t\t\t[%s] 강의실 (정원: %s명) 을 새로 입력하시겠습니까?(y/n): ", new_name, new_capacity);
					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t새로운 강의실 [%s] 의 입력이 완료되었습니다.\n", new_name);
						printClassroom();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t새로운 강의실 입력이 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}

				stat.close();
				conn.close();
			} // while
		} catch (Exception e) {

			e.printStackTrace();

		}

	}// insertClassroom()

	/**
	 * 기존강의실의 이름과 정원을 수정해주어 데이터베이스에 업데이트 시켜주는 메소드
	 */
	public void updateClassroom() { // 3. 기존 강의실 수정하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {
			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> classroom_name_list = new ArrayList<String>();
			ArrayList<String> classroom_capacity_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select classroom_name, classroom_capacity from tblClassroom";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[강의실목록]");
			System.out.println("\t\t\t\t================================================================");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","강의실명","강의실정원");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				classroom_name_list.add(rs1.getString(1));
				classroom_capacity_list.add(rs1.getString(2));
				// 어레이 리스트에 이름과 기간을 각각 저장

				num++;
			}

			while (true) {// 뒤로가기
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t수정할 강의실의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_classroom = scan.nextLine();
				if (select_classroom.equals("b")) {
					break;
				}

				int select_classroom_num = Integer.parseInt(select_classroom) - 1;// 어레이 리스트 번호

				while (true) {// 뒤로가기 > 번호 입력창
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t1. 강의실 이름 수정");
					System.out.println("\t\t\t\t2. 강의실 수용 정원 수정");
					System.out.println("\t\t\t\t3. 뒤로가기");
					System.out.println("\t\t\t\t================================");
					System.out.print("\t\t\t\t입력: ");
					String select_update = scan.nextLine();
					// 이름을 수정할지 정원을 수정할지 선택

					while (true) {
						if (select_update.equals("1")) { // 강의실 이름 수정 선택

							// 새로 수정할 이름을 입력받음
							System.out.print("\t\t\t\t새로 수정할 강의실의 이름을 입력해 주세요.: ");
							String new_classroom_name = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblClassroom set classroom_name = '%s' where classroom_name = '%s' and classroom_capacity = %s",
									new_classroom_name, classroom_name_list.get(select_classroom_num),
									classroom_capacity_list.get(select_classroom_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t[%s]를 [%s]로 변경하시겠습니까?(y/n): ",
										classroom_name_list.get(select_classroom_num), new_classroom_name);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t강의실 [%s]의 이름이 [%s]로 변경 완료되었습니다.\n",
											classroom_name_list.get(select_classroom_num), new_classroom_name);
									printClassroom();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t강의실 이름 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							}

						} else if (select_update.equals("2")) {

							System.out.print("\t\t\t\t새로 수정할 강의실의 수용 정원을 입력해 주세요.: ");
							String new_classroom_capacity = scan.nextLine();

							// 기존의 강의실이름, 정원이 같은 레코드의 강의실이름을 변경
							String sql2 = String.format(
									"update tblClassroom set classroom_capacity = %s where classroom_name = '%s' and classroom_capacity = %s",
									new_classroom_capacity, classroom_name_list.get(select_classroom_num),
									classroom_capacity_list.get(select_classroom_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t강의실[%s]의 수용 정원을 [%s]명으로 변경하시겠습니까?(y/n): ",
										classroom_name_list.get(select_classroom_num), new_classroom_capacity);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t강의실 [%s]의 수용 정원이 [%s]명으로 변경 완료되었습니다.\n",
											classroom_name_list.get(select_classroom_num), new_classroom_capacity);
									printClassroom();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t강의실 정원 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							} // 확인절차
							break;// 확인절차 이후 이름, 정원 선택창...
						} else if (select_update.equals("3")) {
							break;
						} else {
							System.out.println("\t\t\t\t잘못 입력하셨습니다.");
						}
						break;// 확인절차 이후 이름, 정원 선택창...
					} // while

					break;
				}
			} // while
			rs1.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// updateClassroom()

	/**
	 * 삭제할 데이터의 번호를 받아서 이름에 (폐쇄)이라는 글자를 달아서 업데이트 시켜주는 메서드
	 */
	public void deleteClassroom() { // 4. 기존 강의실 폐쇄하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> classroom_name_list = new ArrayList<String>();
			ArrayList<String> classroom_capacity_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select classroom_name, classroom_capacity from tblClassroom";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[강의실목록]");
			System.out.println("\t\t\t\t================================================================");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","강의실명","강의실정원");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				classroom_name_list.add(rs1.getString(1));
				classroom_capacity_list.add(rs1.getString(2));
				// 어레이 리스트에 이름을 저장

				num++;
			}
			while (true) {

				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t폐쇄할 강의실의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_classroom = scan.nextLine();
				if (select_classroom.equals("b")) {
					break;
				}

				int select_classroom_num = Integer.parseInt(select_classroom) - 1;// 어레이 리스트 번호

				// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
				String sql2 = String.format(
						"update tblClassroom set classroom_name = classroom_name||'(폐쇄)' where classroom_name = '%s' and classroom_capacity = %s",
						classroom_name_list.get(select_classroom_num),
						classroom_capacity_list.get(select_classroom_num));

				stat.executeUpdate(sql2);

				while (true) { // 입력할지 확인 절차

					System.out.printf("\t\t\t\t강의실 [%s]를 삭제하시겠습니까?(y/n): ", classroom_name_list.get(select_classroom_num));

					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t강의실 [%s]이 삭제 되었습니다.\n", classroom_name_list.get(select_classroom_num));
						printClassroom();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t강의실 삭제 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}
			} // while
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// deleteClassroom()

//교재정보============================================================================================================

	/**
	 * 기초 교재 정보를 호출하는 메소드
	 */
	private void printBookMenu() {

		while (true) {
			System.out.println("\t\t\t\t================================");
			System.out.println("\t\t\t\t1. 교재 목록 보기");
			System.out.println("\t\t\t\t2. 새 교재 입력하기");
			System.out.println("\t\t\t\t3. 기존 교재 수정하기");
			System.out.println("\t\t\t\t4. 기존 교재 삭제하기");
			System.out.println("\t\t\t\t5. 뒤로가기");
			System.out.println("\t\t\t\t================================");
			System.out.print("\t\t\t\t입력: ");
			String select = scan.nextLine();

			if (select.equals("1")) {
				printBook();

			} else if (select.equals("2")) {
				insertBook();
			} else if (select.equals("3")) {
				updateBook();

			} else if (select.equals("4")) {
				deleteBook();
			} else if (select.equals("5")) {
				break;

			} else {
				System.out.println("\t\t\t\t잘못 입력 하셨습니다.");
			}
		}
	}

	/**
	 * 데이터베이스의 기초교재 테이블에서 교재 정보를 불러와 목록을 출력하는 메소드
	 */
	private void printBook() {// 1. 교재 목록 보기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select book_name, publisher from tblBook";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[교재목록]");
			System.out.println("\t\t\t\t================================================================");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","교재명","출판사");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력
			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));

				num++;
			}

			stat.close();
			conn.close();

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

	/**
	 * 새로 입력할 교재의 이름과 출판사를 입력받아 데이터베이스에 입력하는 메소드
	 */
	private void insertBook() { // 2. 새 교재 입력하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			while (true) {
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t새로 입력할 교재 이름(뒤로가기>b): ");
				String new_name = scan.nextLine();
				if (new_name.equals("b")) {
					break;
				}

				System.out.print("\t\t\t\t새로 입력할 교재 출판사(뒤로가기>b): ");
				String new_publisher = scan.nextLine();
				if (new_publisher.equals("b")) {

					insertBook();

				}
				System.out.println("\t\t\t\t================================");

				// 새로 입력하는 교재의 이름과 출판사를 입력받음

				String sql1 = String.format("insert into tblBook values (seq_book.nextVal, '%s', '%s')", new_name,
						new_publisher);
				// 입력할 과정을 sql문으로 날려줌

				rs1 = stat.executeQuery(sql1);

				while (true) { // 입력할지 확인 절차
					System.out.printf("\t\t\t\t[%s] 교재 (출판사: %s) 를 새로 입력하시겠습니까?(y/n): ", new_name, new_publisher);
					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t새로운 교재 [%s] 의 입력이 완료되었습니다.\n", new_name);
						printBook();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t새로운 교재 입력이 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}

				stat.close();
				conn.close();
			} // while
		} catch (Exception e) {

		}

	}// insertBook()

	
	/**
	 * 기존교재의 이름과 출판사를 수정해주어 데이터베이스에 업데이트 시켜주는 메소드
	 */
	private void updateBook() { // 3. 기존 교재 수정하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {
			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> book_name_list = new ArrayList<String>();
			ArrayList<String> publisher_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select book_name, publisher from tblBook";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[교재목록]");
			int num = 1;
			System.out.println("\t\t\t\t================================================================");
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","교재명","출판사");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				book_name_list.add(rs1.getString(1));
				publisher_list.add(rs1.getString(2));
				// 어레이 리스트에 이름과 기간을 각각 저장

				num++;
			}

			while (true) {
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t수정할 교재의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_book = scan.nextLine();
				if (select_book.equals("b")) {
					break;
				}

				int select_book_num = Integer.parseInt(select_book) - 1;// 어레이 리스트 번호

				while (true) {
					System.out.println("\t\t\t\t================================");
					System.out.println("\t\t\t\t1. 교재 이름 수정");
					System.out.println("\t\t\t\t2. 교재 출판사 수정");
					System.out.println("\t\t\t\t3. 뒤로가기");
					System.out.println("\t\t\t\t================================");
					System.out.print("\t\t\t\t입력: ");
					String select_update = scan.nextLine();
					// 이름을 수정할지 정원을 수정할지 선택

					while (true) {
						if (select_update.equals("1")) { // 교재 이름 수정 선택

							// 새로 수정할 이름을 입력받음
							System.out.print("\t\t\t\t새로 수정할 교재의 이름을 입력해 주세요.: ");
							String new_book_name = scan.nextLine();

							// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
							String sql2 = String.format(
									"update tblBook set book_name = '%s' where book_name = '%s' and publisher = '%s'",
									new_book_name, book_name_list.get(select_book_num),
									publisher_list.get(select_book_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t교재[%s]를 [%s]로 변경하시겠습니까?(y/n): ", book_name_list.get(select_book_num),
										new_book_name);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t교재 [%s]의 이름이 [%s]로 변경 완료되었습니다.\n",
											book_name_list.get(select_book_num), new_book_name);
									printBook();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t교재 이름 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							}

						} else if (select_update.equals("2")) {

							System.out.print("\t\t\t\t새로 수정할 교재의 출판사 입력해 주세요.: ");
							String new_publisher = scan.nextLine();

							// 기존의 강의실이름, 정원이 같은 레코드의 강의실이름을 변경
							String sql2 = String.format(
									"update tblBook set publisher = '%s' where book_name = '%s' and publisher = '%s'",
									new_publisher, book_name_list.get(select_book_num),
									publisher_list.get(select_book_num));

							stat.executeUpdate(sql2);

							while (true) { // 입력할지 확인 절차

								System.out.printf("\t\t\t\t교재[%s]의 출판사를 [%s]으로 변경하시겠습니까?(y/n): ",
										book_name_list.get(select_book_num), new_publisher);

								String answer_yn = scan.nextLine();

								if (answer_yn.toLowerCase().equals("y")) {
									// y입력시 커밋
									conn.commit();
									// 입력 완료 후 완료 메세지
									System.out.printf("\t\t\t\t교재 [%s]의 출판사가 [%s]으로 변경 완료되었습니다.\n",
											book_name_list.get(select_book_num), new_publisher);
									printBook();
									break;

								} else if (answer_yn.toLowerCase().equals("n")) {
									// n입력시 롤백
									System.out.println("\t\t\t\t출판사 변경이 취소되었습니다.");
									conn.rollback();
									break;

								} else {

									System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
								}

							} // 확인절차
							break;

						} else if (select_update.equals("3")) {
							break;
						} else {
							System.out.println("\t\t\t\t잘못 입력하셨습니다.");
						}
						break;
					} // while
					break;
				}
			} // while

			rs1.close();
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// updateBook()

	/**
	 * 삭제할 데이터의 번호를 받아서 이름에 (삭제)이라는 글자를 달아서 업데이트 시켜주는 메서드
	 */
	private void deleteBook() { // 4. 기존 교재 삭제하기

		Connection conn = null;
		Statement stat = null;
		ResultSet rs1 = null;
		DBUtil util = new DBUtil();

		try {

			conn = util.open();
			stat = conn.createStatement();
			conn.setAutoCommit(false);

			ArrayList<String> book_name_list = new ArrayList<String>();
			ArrayList<String> publisher_list = new ArrayList<String>();

			System.out.println("\t\t\t\t================================================================");
			String sql1 = "select book_name, publisher from tblBook";
			rs1 = stat.executeQuery(sql1);
			System.out.printf("\t\t\t\t%30s\n","[교재목록]");
			System.out.println("\t\t\t\t================================================================");
			int num = 1;
			System.out.printf("\t\t\t\t%30s\t\t\t\t\t%3s\n","교재명","출판사");
			System.out.println("\t\t\t\t================================================================");
			// 결과셋 출력

			while (rs1.next()) {

				System.out.printf("\t\t\t\t%d. %-35s\t\t\t\t%-10s\n", num, rs1.getString(1), rs1.getString(2));
				book_name_list.add(rs1.getString(1));
				publisher_list.add(rs1.getString(2));
				// 어레이 리스트에 이름을 저장

				num++;
			}

			while (true) {
				System.out.println("\t\t\t\t================================");
				System.out.print("\t\t\t\t삭제할 교재의 번호를 입력해 주세요.(뒤로가기>b): ");
				String select_book = scan.nextLine();
				if (select_book.equals("b")) {
					break;
				}

				int select_book_num = Integer.parseInt(select_book) - 1;// 어레이 리스트 번호

				// 기존의 과정이름, 기간이 같은 레코드의 과정이름을 변경
				String sql2 = String.format(
						"update tblBook set book_name = book_name||'(삭제)' where book_name = '%s' and publisher = '%s'",
						book_name_list.get(select_book_num), publisher_list.get(select_book_num));

				stat.executeUpdate(sql2);

				while (true) { // 입력할지 확인 절차

					System.out.printf("\t\t\t\t교재 [%s]를 삭제하시겠습니까?(y/n): ", book_name_list.get(select_book_num));

					String answer_yn = scan.nextLine();

					if (answer_yn.toLowerCase().equals("y")) {
						// y입력시 커밋
						conn.commit();
						// 입력 완료 후 완료 메세지
						System.out.printf("\t\t\t\t교재 [%s]이 삭제 되었습니다.\n", book_name_list.get(select_book_num));
						printBook();
						break;

					} else if (answer_yn.toLowerCase().equals("n")) {
						// n입력시 롤백
						System.out.println("\t\t\t\t교재 삭제 취소되었습니다.");
						conn.rollback();
						break;

					} else {

						System.out.println("\t\t\t\ty 또는 n으로 입력해 주세요.");
					}

				}
			} // while
			stat.close();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}// deleteBook()

}// class

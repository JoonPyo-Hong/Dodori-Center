// 동아리 스케줄 관리
package com.test.admin;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.test.student.DBUtil;
/**
 * 
 * @author 홍준표
 *
 */

public class Proc193 {
	Connection conn = null;
	Statement stat = null;
	ResultSet rs = null;
	DBUtil util = new DBUtil();
	Scanner scan = new Scanner(System.in);
	private int listsize = 0;
	private static int j = 0;
	private static int c = 1;
	private static int d = 0;
	
	 public void pq() {
		m(); 
	 }
	 /**
	  * 동아리 스케줄 관리 출력문
	  */
	public void pr() {
		
		System.out.println("----------------------------");
		 System.out.println("1. 동아리 스케줄 조회");
		 System.out.println("2. 동아리 스케줄 추가");
		 System.out.println("3. 이전화면");
		 System.out.println("----------------------------");
		 System.out.print("선택(번호) : ");
		 String a = scan.nextLine();
		
		 if(a.equals("1")) {
			 m();
			
			 //-------------------------------------------------------
		 }else if(a.equals("2")) {
			 
			 //-------------------------------------
				System.out.print("날짜 : ");
				String d = scan.nextLine();
				
				
				System.out.print("장소 : ");
				String n = scan.nextLine();
				
				
				System.out.print("인원 : ");
				String c = scan.nextLine();
				// 구현부
		try {
					
					// 객체 생성
					Connection conn = null;
					CallableStatement stat = null;
					DBUtil util = new DBUtil();
					
					// 3조 연결
					conn = util.open("211.63.89.47","project","java1234");
					
					
					int f = Integer.parseInt(c);
					// 컬럼 수만큼 = ?
					String sql ="{call proc193(?,?,?)}";
					stat = conn.prepareCall(sql);
					stat.setString(1, d);
					stat.setString(2, n);
					stat.setInt(3,f);
					// select 에서 Update
					stat.executeUpdate();
				
					
					// 자원 닫기
					stat.close();
					conn.close();
					
				System.out.println("스케줄이 추가 되었습니다.");
				
				//오류 발생
				} catch (Exception e) {
				
					System.out.println(e);
				}
			 
		Proc193 pr = new Proc193();
		 pr.pr();
		 }else if(a.equals("3")) {
			 DongariOutput o = new DongariOutput();
			 o.out();
		 }else {
			 System.out.println("잘못 입력하셨습니다.");
			 System.out.println("계속 하시리면엔터를 누르세요...");
			 String b = scan.nextLine();
			 Proc193 pr = new Proc193();
			 pr.pr();
		 }
		 
		 
		 
	}
	/*
	 * 동아리스케줄 출력문 구현부
	 */
	private void m() {
		try {
			  // 3조 SQL 연결
		     conn = util.open("211.63.89.47","project","java1234");
		     stat = conn.createStatement();
		     System.out.println("[번호\t 날짜\t 장소\t 최대인원]");
		     // select문 삽입
		     String sql = "select * from tblStudyGroupSchedual";
		     rs = stat.executeQuery(sql);
		     
		     // select문 마지막행까지 반복
		     ArrayList<String> list = new ArrayList<String>();
		   String  g = "";
		     while(rs.next()) {
		    	 
		    	 
		    	   String yy = "";
			         yy = rs.getString(2).replace("00:00:00", "");
		       g =rs.getString(1) + ".\t" + yy + "\t" + rs.getString(3) + "\t" + rs.getString(4);
		     
		  list.add(g);

		    	 
		     }
		     String q = "";
		     // 10으로 나눈 페이지 수
		     listsize = list.size()/10;
		     q += listsize;
		   
		     
		     for (int i=0+j; i<10+j; i++) {
		    	 
		    	 try {
		    		 System.out.println(list.get(i));
				} catch (Exception e) {
					
				}
		     }
		     	
		     
		     System.out.println("----------------------------");
		     System.out.printf("페이지 : %s/%s",c,q);   
		     System.out.println();
		     System.out.println("----------------------------");
		    
			 System.out.println("1. 이전 페이지");
			 System.out.println("2. 다음 페이지");
			 System.out.println("3. 첫 페이지");
			 System.out.println("4. 마지막 페이지");
			 System.out.println("5. 이전화면");
			 System.out.println("----------------------------");
			 System.out.print("선택(번호) : ");
			 String input = scan.nextLine();
			 if(input.equals("5")){
				 DongariOutput o = new DongariOutput();
				 o.out();
			 }else if(input.equals("1")) {
				 // 이전 페이지
				 j -=10; c-=1;
				 Proc193 pr = new Proc193();
				 pr.pq();
			 }else if(input.equals("2")) {
				 // 다음 페이지
				 j +=10; c+=1;
				 Proc193 pr = new Proc193();
				 pr.pq();
			 } else if(input.equals("3")) {
				 // 첫 페이지
				 j =0; c=1;
				 Proc193 pr = new Proc193();
				 pr.pq();
			 }else if(input.equals("4")) {
				 // 마지막 페이지
				 j =0; c = listsize;
				 j +=(10*listsize);
				 
				 Proc193 pr = new Proc193();
				 pr.pq();
			 }else {
				 System.out.println("잘못 입력하셨습니다.");
				 System.out.println("계속 하시려면 엔터를 누르세요...");
				 String enter = scan.nextLine();
				 Proc193 pr = new Proc193();
				 pr.pq();
			 }
		     // 자원 닫기
		     stat.close();
		     conn.close();
		    
		     // 예외 처리
		  	} catch (Exception e) {
		     System.out.println("오류 발생");
		  	}
	}
}

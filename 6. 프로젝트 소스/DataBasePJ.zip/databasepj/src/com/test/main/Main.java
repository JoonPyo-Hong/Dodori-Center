package com.test.main;

import java.util.Scanner;

import com.test.admin.ManagerLogin;
import com.test.student.Student;
import com.test.teacher.ErrorPage;
import com.test.teacher.TeacherLogin;
import com.test.teacher.TeacherMainMenu;

public class Main {//맨 처음 시작 로그인 창이라고 생각.
	
	public void m() {	
	// 스캐너 선언 -> static 보단 그냥 클래스 내에서 선언해주는게 좋다
	Scanner scan = new Scanner(System.in);
	boolean roof = true;
	
	while(roof) {
		
		// 출력문
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("                                                            \r\n" + 
				"\t\t\t                       ,jy5yyw         wD9ZZ9Dw   ,         \r\n" + 
				"\t\t\t                   wDz898D5B8zzz5W wZZZZZZZZZZZZZZZ         \r\n" + 
				"\t\t\t                 yB5DDw       5, yZZZZz       ZZw           \r\n" + 
				"\t\t\t               jByj55          wZEz9Z                       \r\n" + 
				"\t\t\t              D5jjjD          9Z8BzZ                        \r\n" + 
				"\t\t\t             55jWWyw         zZzBBzZ                        \r\n" + 
				"\t\t\t             DjWWWyj         ZzBBBzZ                        \r\n" + 
				"\t\t\t            y5WWWWjD,       yZBBBBBZD                       \r\n" + 
				"\t\t\t            y5WWWWWjDj      jZBBBBBzZZ                      \r\n" + 
				"\t\t\t             ByWWWWWjyBj     Z9BBBBBBEZ9                    \r\n" + 
				"\t\t\t             ,ByjWWWWWj5By    ZZzBBBBBzEZZ,                 \r\n" + 
				"\t\t\t               yByjWWWWWjyDD   zZZ8BBBBBB9ZZW               \r\n" + 
				"\t\t\t                 yB5yjWWWWjyDj   BZZ9zBBBBB8ZZ      zZ5     \r\n" + 
				"\t\t\t                   wDDyjWWWWj55     BZEzBBBBzZZ     ZZ      \r\n" + 
				"\t\t\t                      D5jWWWWjB    Zy EZzBBBBBZ ZZZZZZZZZ   \r\n" + 
				"\t\t\t                       yyWWWWWD    9,  BZBBBBBZj   ZZ       \r\n" + 
				"\t\t\t                        DjjWWjB  ZZZ    ZBBBBBZw  ZZ,       \r\n" + 
				"\t\t\t                         ,jjj5y   ZW    ZBBBBEZ  yZZ        \r\n" + 
				"\t\t\t    ,zzzB            ZZZZ  j5D   ZZ     ZBBBEZ   ZZj        \r\n" + 
				"\t\t\t    DDjjyDj         zZzB8Zz ,   wZ     Z9B8ZZ   5ZZ         \r\n" + 
				"\t\t\t     B5jjj55         ZZ9zzEZ    ZZZ   ZZ9ZZD    ZZ   y      \r\n" + 
				"\t\t\t      WDBD5DBDW   ,j5 wZZZZZZZz    jZZZZZy     zZZ ZZB      \r\n" + 
				"\t\t\t          WyDz9EEE9zBj    yzZZZZZZZZZzw        ZZZZj    ");
		System.out.println();
		System.out.println("                                                                                                    \r\n" + 
				"                      wZZZZZZZZw                        DZZZZ8w              Wj Wj           w  wj  \r\n" + 
				"     ZZZ ZZZZ ZZZ    ZZZ      9ZZy  ZZZZZZZZZZZZZZ   ZZZZE9zEZZZZy    ZZZZZ  ZZWZZ9 ZZZZZZZZZZ BZZ  \r\n" + 
				"    zZZZZZZZZ ZZZZZ  ZZZDD88DDZZZ              ZZZ   ZZZ      DZZE   ZZZ ZZEzZZ ZZj 9ZZ         ZZ  \r\n" + 
				"    ZZ 8ZZ wZZZZZ      ZZ5w,jZZ                ZZZ      w8ZZE5      yZZ   ZZ 9Z ZZj 9ZZ     w  wZZ  \r\n" + 
				"   ZZZ  85  zDZZZ  WZZZZZZZZZZZZZZZ   ZZZ  ZZw ZZZ  ZZZZZZZZZZZZZZZ ZZZ   ZZZZZWZZz 9ZZZZZZZZBZZZZ  \r\n" + 
				"      5ZZZZZZZZ        zZZZZZZ8       ZZZ  ZZ5 ZZZ     ZZ    ZZW                8Ew 9ZZ         ZZ  \r\n" + 
				"     ZZD      EZZ   BZZy      wZZZ    ZZZ  ZZ, jWj  9ZZZZZZZZZZZZz   ZZZ            9ZZ        ,ZZ  \r\n" + 
				"     ZZZ      ZZZ   5ZZE      8ZZE    ZZZ  ZZ                  ZZ5   ZZZ            ZZZZZZZZZZ WZZ  \r\n" + 
				"      jZZZZZZZZ       5ZZZZZZZZ5   BZZZZZZZZZZZZZZZ            ZZ9   ZZZZZZZZZZZZZZ            DZZ  ");
		

		
		System.out.println();
		System.out.println("\t\t\t\t┌────────────────────────────────┐");
		System.out.println("\t\t\t\t│1. 관리자 로그인			 │");
		System.out.println("\t\t\t\t│2. 교사 로그인			 │");
		System.out.println("\t\t\t\t│3. 교육생 로그인			 │");
		System.out.println("\t\t\t\t│4. 종료				 │");
		System.out.println("\t\t\t\t└────────────────────────────────┘");
		
		// 입력받는 값 (1 ~ 4)
		System.out.print("\t\t\t\t선택(번호) : ");
		String input = scan.nextLine();
		
		if(input.equals("1")) {
			ManagerLogin ml = new ManagerLogin();
			ml.login();
			ml.printManagerMenu();
			// 1. 관리자 로그인
			
		}else if(input.equals("2")) {
			
			//2. 교사 로그인
			
			TeacherLogin tr = new TeacherLogin();//로그인 시도
			
			
			if (TeacherLogin.teacherNumber == -1) {//로그인 실패상황
				System.out.println("\t\t\t\t없는 계정이거나 아이디 또는 패스워드가 일치하지 않습니다.");
				ErrorPage ep = new ErrorPage();
				m();//상위 메뉴로 돌아가준다

			} else {//로그인을 성공한 상태! -> 본격적인 메인메뉴로 들어갈것이다.
				TeacherMainMenu tm = new TeacherMainMenu();
				tm.tMenu();
				
			}
			
		}else if(input.equals("3")) {
			
			Student st = new Student();
			st.
			s();
			roof = false;
			
		}else if(input.equals("4")) {
			
			roof = false;
			System.out.println("\t\t\t\t종료 하겠습니다.");
			
			System.exit(1);
//			while(true) {
//				
//			}
			// 4. 종료

			
		}
		
		// 유효성 검사 
		else  {
			System.out.println("\t\t\t\t────────────────────────────────");
			System.out.println("\t\t\t\t잘못 입력하셨습니다");
			System.out.println("\t\t\t\t1 ~ 4 사이의 숫자를 입력해주세요");
			System.out.println("\t\t\t\t계속 하시려면 엔터를 누르세요...");
			System.out.println("\t\t\t\t────────────────────────────────");
			String enter = scan.nextLine();
			
		} 
		
		
		} // while		
	}
}

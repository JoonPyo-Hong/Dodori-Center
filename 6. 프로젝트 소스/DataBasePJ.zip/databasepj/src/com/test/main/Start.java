package com.test.main;


public class Start {
	public static void main(String[] args) {
		
		//메인구현
		
		Main ma = new Main();
		
		ma.m();		
		
		
		
		

	}
}
